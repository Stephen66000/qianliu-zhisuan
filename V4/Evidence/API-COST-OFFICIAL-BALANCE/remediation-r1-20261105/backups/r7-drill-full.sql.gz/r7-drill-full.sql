--
-- PostgreSQL database dump
--

\restrict lqLStnMpHtrzgNvpG2DZMrtivYpXaPuNuBNUnmkDkuzMbw8TxirQXeRvTabFjmN

-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: historical_import_run_item_immutable(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.historical_import_run_item_immutable() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      RAISE EXCEPTION 'historical_import_run_item is append-only and strictly immutable: % is forbidden', TG_OP;
    END;
    $$;


ALTER FUNCTION public.historical_import_run_item_immutable() OWNER TO wp6_r7;

--
-- Name: historical_import_run_state_guard(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.historical_import_run_state_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'historical_import_run records cannot be deleted';
      END IF;

      -- 基线、身份、快照、初始时间字段完全不可篡改
      IF OLD.id <> NEW.id OR OLD.enterprise_id <> NEW.enterprise_id
         OR OLD.manifest_hash <> NEW.manifest_hash
         OR OLD.source_package_hash <> NEW.source_package_hash
         OR OLD.source_system <> NEW.source_system
         OR OLD.window_start <> NEW.window_start
         OR OLD.window_end <> NEW.window_end
         OR OLD.total_requests <> NEW.total_requests
         OR OLD.request_id_digest <> NEW.request_id_digest
         OR OLD.input_tokens <> NEW.input_tokens
         OR OLD.output_tokens <> NEW.output_tokens
         OR OLD.cache_tokens <> NEW.cache_tokens
         OR OLD.reasoning_tokens <> NEW.reasoning_tokens
         OR OLD.baseline_summary::text <> NEW.baseline_summary::text
         OR OLD.pre_cutover_snapshot::text IS DISTINCT FROM NEW.pre_cutover_snapshot::text
         OR OLD.pre_finance_snapshot::text IS DISTINCT FROM NEW.pre_finance_snapshot::text
         OR OLD.started_at <> NEW.started_at
         OR OLD.created_at <> NEW.created_at THEN
        RAISE EXCEPTION 'Baseline, identity, and pre-snapshots of historical_import_run cannot be modified';
      END IF;

      -- 状态机受控流转约束
      IF OLD.status = 'RUNNING' THEN
        IF NEW.status = 'COMPLETED' THEN
          IF NEW.completed_at IS NULL THEN
            RAISE EXCEPTION 'completed_at must be set when transitioning historical_import_run to COMPLETED';
          END IF;
          IF NEW.rolled_back_at IS NOT NULL OR NEW.rollback_summary IS NOT NULL THEN
            RAISE EXCEPTION 'rolled_back fields cannot be set when transitioning to COMPLETED';
          END IF;
        ELSIF NEW.status = 'FAILED' THEN
          -- 允许转入失败
        ELSIF NEW.status = 'RUNNING' THEN
          -- 允许保持运行
        ELSE
          RAISE EXCEPTION 'Invalid status transition from RUNNING to %', NEW.status;
        END IF;
      ELSIF OLD.status = 'COMPLETED' THEN
        IF NEW.status = 'ROLLED_BACK' THEN
          IF NEW.rolled_back_at IS NULL THEN
            RAISE EXCEPTION 'rolled_back_at must be set when transitioning historical_import_run to ROLLED_BACK';
          END IF;
          IF OLD.completed_at IS DISTINCT FROM NEW.completed_at THEN
            RAISE EXCEPTION 'completed_at cannot be altered when transitioning to ROLLED_BACK';
          END IF;
          IF OLD.post_cutover_snapshot::text IS DISTINCT FROM NEW.post_cutover_snapshot::text
             OR OLD.post_finance_snapshot::text IS DISTINCT FROM NEW.post_finance_snapshot::text THEN
            RAISE EXCEPTION 'post snapshots of historical_import_run cannot be altered when transitioning to ROLLED_BACK';
          END IF;
        ELSE
          RAISE EXCEPTION 'COMPLETED historical_import_run can only transition to ROLLED_BACK, not %', NEW.status;
        END IF;
      ELSIF OLD.status IN ('FAILED', 'ROLLED_BACK') THEN
        RAISE EXCEPTION 'Terminal state % of historical_import_run is strictly immutable', OLD.status;
      END IF;

      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.historical_import_run_state_guard() OWNER TO wp6_r7;

--
-- Name: provider_finance_explicit_cost_exclusion_applies(uuid, uuid); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_explicit_cost_exclusion_applies(tenant uuid, line_id uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
      SELECT EXISTS (
        SELECT 1 FROM provider_finance_usage_cost_disposition disposition
        JOIN ledger_line line ON line.id=disposition.ledger_line_id AND line.enterprise_id=disposition.enterprise_id
        WHERE disposition.enterprise_id=tenant AND disposition.ledger_line_id=line_id
          AND disposition.decision='EXCLUDE_NO_SERVER_COST'
          AND disposition.provider_resource_id=line.provider_resource_id AND disposition.ai_request_id=line.ai_request_id
          AND line.resource_mode='API' AND line.api_cost_status='UNKNOWN_COST'
          AND line.api_cost IS NULL AND line.api_cost_currency IS NULL
          AND disposition.original_ledger_fact=to_jsonb(line)
          AND NOT provider_finance_line_has_recorded_cost(line)
      )
    $$;


ALTER FUNCTION public.provider_finance_explicit_cost_exclusion_applies(tenant uuid, line_id uuid) OWNER TO wp6_r7;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ledger_line; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.ledger_line (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ai_request_id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    usage_event_id uuid NOT NULL,
    upstream_attempt_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    resource_mode character varying(16) NOT NULL,
    raw_input_tokens bigint NOT NULL,
    raw_output_tokens bigint NOT NULL,
    raw_cache_tokens bigint NOT NULL,
    deducted_quota bigint,
    api_cost numeric,
    usage_quality character varying(32) NOT NULL,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    billing_rule_id uuid,
    rule_version character varying(32),
    multiplier numeric,
    raw_reasoning_tokens bigint DEFAULT 0 NOT NULL,
    billing_rule_snapshot jsonb,
    api_cost_currency character varying(3),
    api_cost_status character varying(40),
    subscription_period_id uuid,
    settled_at timestamp with time zone,
    legacy_cost_resolution_id uuid,
    CONSTRAINT ledger_line_api_cost_currency_check CHECK (((api_cost_currency IS NULL) OR ((api_cost_currency)::text = ANY ((ARRAY['CNY'::character varying, 'USD'::character varying])::text[])))),
    CONSTRAINT ledger_line_api_cost_fact_shape_check CHECK (((api_cost_status IS NULL) OR (((api_cost_status)::text = 'PRICED_USAGE'::text) AND ((resource_mode)::text = 'API'::text) AND (api_cost IS NOT NULL) AND (api_cost_currency IS NOT NULL)) OR (((api_cost_status)::text = 'CONFIRMED_ZERO_NO_UPSTREAM'::text) AND ((resource_mode)::text = 'API'::text) AND (api_cost = (0)::numeric) AND (api_cost_currency IS NULL)) OR (((api_cost_status)::text = 'UNKNOWN_COST'::text) AND ((resource_mode)::text = 'API'::text) AND (api_cost IS NULL) AND (api_cost_currency IS NULL)) OR (((api_cost_status)::text = 'NOT_APPLICABLE'::text) AND ((resource_mode)::text = 'CODING_PLAN'::text) AND (api_cost IS NULL) AND (api_cost_currency IS NULL)) OR (((api_cost_status)::text = 'NOT_MIGRATED'::text) AND ((resource_mode)::text = 'API'::text) AND (api_cost IS NULL) AND (api_cost_currency IS NULL)))),
    CONSTRAINT ledger_line_api_cost_status_check CHECK (((api_cost_status IS NULL) OR ((api_cost_status)::text = ANY ((ARRAY['PRICED_USAGE'::character varying, 'CONFIRMED_ZERO_NO_UPSTREAM'::character varying, 'UNKNOWN_COST'::character varying, 'NOT_APPLICABLE'::character varying, 'NOT_MIGRATED'::character varying])::text[]))))
);


ALTER TABLE public.ledger_line OWNER TO wp6_r7;

--
-- Name: provider_finance_line_has_recorded_cost(public.ledger_line); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_line_has_recorded_cost(target public.ledger_line) RETURNS boolean
    LANGUAGE sql STABLE
    AS $_$
      WITH priced AS (
        SELECT COALESCE(SUM(api_cost),0) AS amount, COUNT(DISTINCT api_cost_currency) AS currencies
          FROM ledger_line
         WHERE enterprise_id=(target).enterprise_id AND ai_request_id=(target).ai_request_id
           AND resource_mode='API' AND api_cost_status='PRICED_USAGE'
      ), recorded AS (
        SELECT total_api_cost AS amount FROM ledger_transaction
         WHERE enterprise_id=(target).enterprise_id AND ai_request_id=(target).ai_request_id
           AND api_cost_status='PRICED_USAGE'
        UNION ALL
        SELECT actual_cost AS amount FROM dispatch_decision
         WHERE enterprise_id=(target).enterprise_id AND ai_request_id=(target).ai_request_id
      )
      SELECT COALESCE((target).api_cost>0,false)
        OR CASE WHEN (target).billing_rule_snapshot->>'apiCost' ~ '^[+]?[0-9]+([.][0-9]+)?$'
          THEN ((target).billing_rule_snapshot->>'apiCost')::numeric>0 ELSE false END
        -- Do not exclude unaccounted positive request-level costs. Costs already
        -- represented by other priced attempts remain counted by the original ledger.
        OR EXISTS (SELECT 1 FROM recorded CROSS JOIN priced
          WHERE recorded.amount>0 AND (priced.currencies>1 OR recorded.amount>priced.amount))
    $_$;


ALTER FUNCTION public.provider_finance_line_has_recorded_cost(target public.ledger_line) OWNER TO wp6_r7;

--
-- Name: provider_finance_protect_activation_attempt(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_protect_activation_attempt() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP = 'DELETE' THEN
        IF OLD.status = 'ACTIVATED' THEN
          RAISE EXCEPTION 'activated provider finance candidate is immutable' USING ERRCODE = '55000';
        END IF;
        RETURN OLD;
      END IF;
      IF OLD.status = 'ACTIVATED' THEN
        RAISE EXCEPTION 'activated provider finance candidate is immutable' USING ERRCODE = '55000';
      END IF;
      IF OLD.status <> 'PREVIEWED' THEN
        RAISE EXCEPTION 'provider finance candidate is already terminal' USING ERRCODE = '55000';
      END IF;
      IF NEW.status NOT IN ('ACTIVATED','EXPIRED','REJECTED') THEN
        RAISE EXCEPTION 'provider finance candidate must move PREVIEWED -> ACTIVATED|EXPIRED|REJECTED'
          USING ERRCODE = '55000';
      END IF;
      IF NEW.enterprise_id <> OLD.enterprise_id
         OR NEW.candidate_hash <> OLD.candidate_hash
         OR NEW.fact_watermark_hash <> OLD.fact_watermark_hash
         OR NEW.decision <> OLD.decision
         OR NEW.gap_summary::text <> OLD.gap_summary::text
         OR NEW.projection_summary::text <> OLD.projection_summary::text
         OR NEW.usage_repair_baseline::text <> OLD.usage_repair_baseline::text
         OR NEW.candidate_draft::text <> OLD.candidate_draft::text
         OR NEW.created_by_admin_user_id <> OLD.created_by_admin_user_id
         OR NEW.created_at <> OLD.created_at
         OR NEW.expires_at <> OLD.expires_at THEN
        RAISE EXCEPTION 'provider finance candidate preview facts are immutable' USING ERRCODE = '55000';
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_protect_activation_attempt() OWNER TO wp6_r7;

--
-- Name: provider_finance_protect_resolution_snapshot(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_protect_resolution_snapshot() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF EXISTS (
        SELECT 1 FROM provider_finance_legacy_cost_resolution resolution
         WHERE resolution.provider_balance_snapshot_id=OLD.id
      ) THEN
        RAISE EXCEPTION 'provider balance snapshot is sealed by a legacy cost resolution';
      END IF;
      IF TG_OP='DELETE' THEN RETURN OLD; END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_protect_resolution_snapshot() OWNER TO wp6_r7;

--
-- Name: provider_finance_protect_runtime_activation(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_protect_runtime_activation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF OLD.strict_writes_enabled THEN
        RAISE EXCEPTION 'provider finance strict write activation is irreversible';
      END IF;
      IF TG_OP='DELETE' THEN RETURN OLD; END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_protect_runtime_activation() OWNER TO wp6_r7;

--
-- Name: provider_finance_reject_event_mutation(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_reject_event_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      RAISE EXCEPTION 'provider_finance_event is append-only' USING ERRCODE = '55000';
    END;
    $$;


ALTER FUNCTION public.provider_finance_reject_event_mutation() OWNER TO wp6_r7;

--
-- Name: provider_finance_unrecorded_cancel_applies(uuid, uuid); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_unrecorded_cancel_applies(tenant uuid, line_id uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $_$
      SELECT EXISTS (
        SELECT 1 FROM ledger_line line
        JOIN provider_finance_recorded_cost_policy policy
          ON policy.enterprise_id=line.enterprise_id AND policy.provider_resource_id=line.provider_resource_id AND policy.enabled
        JOIN ai_request request ON request.enterprise_id=line.enterprise_id AND request.id=line.ai_request_id
        JOIN upstream_attempt attempt ON attempt.enterprise_id=line.enterprise_id AND attempt.id=line.upstream_attempt_id
          AND attempt.ai_request_id=request.id AND attempt.provider_resource_id=line.provider_resource_id
        JOIN usage_event usage ON usage.enterprise_id=line.enterprise_id AND usage.id=line.usage_event_id
          AND usage.ai_request_id=request.id AND usage.upstream_attempt_id=attempt.id
          AND usage.provider_resource_id=line.provider_resource_id
        JOIN ledger_transaction transaction ON transaction.enterprise_id=line.enterprise_id AND transaction.ai_request_id=request.id
        WHERE line.enterprise_id=tenant AND line.id=line_id
          AND request.status IN ('FAILED','CANCELLED') AND request.error_code='client_cancelled' AND request.finished_at IS NOT NULL
          AND attempt.error_code='client_cancelled' AND attempt.finished_at IS NOT NULL
          AND line.resource_mode='API' AND line.api_cost_status='UNKNOWN_COST'
          AND line.api_cost IS NULL AND line.api_cost_currency IS NULL AND line.legacy_cost_resolution_id IS NULL
          AND line.settled_at>=policy.created_at AND request.started_at>=policy.created_at
          AND line.raw_input_tokens=0 AND line.raw_output_tokens=0 AND line.raw_cache_tokens=0 AND line.raw_reasoning_tokens=0
          AND usage.input_tokens=0 AND usage.output_tokens=0 AND usage.cache_tokens=0 AND usage.reasoning_tokens=0
          AND usage.upstream_usage_id IS NULL
          AND transaction.status='SETTLED' AND transaction.api_cost_status='UNKNOWN_COST' AND transaction.attempt_count=1
          AND (transaction.total_api_cost IS NULL OR transaction.total_api_cost=0)
          AND transaction.total_input_tokens=0 AND transaction.total_output_tokens=0
          AND transaction.total_cache_tokens=0 AND transaction.total_reasoning_tokens=0
          AND (line.billing_rule_snapshot->>'apiCost' IS NULL OR line.billing_rule_snapshot->>'apiCost' ~ '^[+]?0+([.]0+)?$')
          AND NOT provider_finance_line_has_recorded_cost(line)
          AND NOT EXISTS (SELECT 1 FROM dispatch_decision d WHERE d.enterprise_id=tenant AND d.ai_request_id=request.id
            AND d.actual_cost IS NOT NULL AND d.actual_cost<>0)
          AND NOT EXISTS (SELECT 1 FROM upstream_attempt a WHERE a.enterprise_id=tenant AND a.ai_request_id=request.id AND a.id<>attempt.id)
          AND NOT EXISTS (SELECT 1 FROM usage_event u WHERE u.enterprise_id=tenant AND u.ai_request_id=request.id AND u.id<>usage.id)
          AND NOT EXISTS (SELECT 1 FROM ledger_line l WHERE l.enterprise_id=tenant AND l.ai_request_id=request.id AND l.id<>line.id)
      )
    $_$;


ALTER FUNCTION public.provider_finance_unrecorded_cancel_applies(tenant uuid, line_id uuid) OWNER TO wp6_r7;

--
-- Name: provider_finance_usage_cost_exclusion_applies(uuid, uuid); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_usage_cost_exclusion_applies(tenant uuid, line_id uuid) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
      SELECT provider_finance_explicit_cost_exclusion_applies(tenant,line_id)
        OR provider_finance_unrecorded_cancel_applies(tenant,line_id)
    $$;


ALTER FUNCTION public.provider_finance_usage_cost_exclusion_applies(tenant uuid, line_id uuid) OWNER TO wp6_r7;

--
-- Name: FUNCTION provider_finance_usage_cost_exclusion_applies(tenant uuid, line_id uuid); Type: COMMENT; Schema: public; Owner: wp6_r7
--

COMMENT ON FUNCTION public.provider_finance_usage_cost_exclusion_applies(tenant uuid, line_id uuid) IS 'Owner-authorized recorded-cost accounting: explicit decisions or terminal single-attempt cancellations with zero recorded usage and no recorded fees. Original facts are preserved; never a claim of zero supplier charge.';


--
-- Name: provider_finance_usage_disposition_guard(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_usage_disposition_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE original ledger_line%ROWTYPE;
    BEGIN
      IF TG_OP<>'INSERT' THEN
        RAISE EXCEPTION 'provider finance usage cost dispositions are append-only';
      END IF;
      SELECT * INTO original FROM ledger_line
        WHERE id=NEW.ledger_line_id AND enterprise_id=NEW.enterprise_id FOR UPDATE;
      IF NOT FOUND OR original.provider_resource_id<>NEW.provider_resource_id
         OR original.ai_request_id<>NEW.ai_request_id THEN
        RAISE EXCEPTION 'usage cost disposition ledger identity mismatch';
      END IF;
      IF NOT EXISTS (SELECT 1 FROM upstream_attempt attempt
        WHERE attempt.id=original.upstream_attempt_id AND attempt.enterprise_id=NEW.enterprise_id
          AND attempt.ai_request_id=NEW.ai_request_id AND attempt.provider_resource_id=NEW.provider_resource_id) THEN
        RAISE EXCEPTION 'usage cost disposition attempt identity mismatch';
      END IF;
      IF original.resource_mode<>'API' OR original.api_cost_status IS DISTINCT FROM 'UNKNOWN_COST'
         OR original.api_cost IS NOT NULL OR original.api_cost_currency IS NOT NULL THEN
        RAISE EXCEPTION 'usage cost disposition requires an unpriced API ledger row';
      END IF;
      IF NEW.original_ledger_fact IS DISTINCT FROM to_jsonb(original) THEN
        RAISE EXCEPTION 'usage cost disposition original ledger snapshot mismatch';
      END IF;
      IF provider_finance_line_has_recorded_cost(original) THEN
        RAISE EXCEPTION 'recorded server cost takes precedence over exclusion';
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_usage_disposition_guard() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_adjustment_closure(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_adjustment_closure() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE finance_case provider_finance_reconciliation_case%ROWTYPE;
    BEGIN
      IF NEW.event_type = 'API_BALANCE_RECONCILIATION' THEN
        SELECT * INTO finance_case FROM provider_finance_reconciliation_case
         WHERE id=NEW.reconciliation_case_id AND enterprise_id=NEW.enterprise_id;
        IF finance_case.id IS NULL OR finance_case.status <> 'RESOLVED'
           OR finance_case.decision <> 'CONFIRMED'
           OR finance_case.adjustment_event_id <> NEW.id THEN
          RAISE EXCEPTION 'reconciliation adjustment is not closed by its resolved case';
        END IF;
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_adjustment_closure() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_case_closure(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_case_closure() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE linked provider_finance_event%ROWTYPE;
    BEGIN
      IF NEW.status = 'RESOLVED' THEN
        SELECT * INTO linked FROM provider_finance_event
         WHERE id = NEW.adjustment_event_id AND enterprise_id = NEW.enterprise_id;
        IF linked.id IS NULL
           OR linked.event_type <> 'API_BALANCE_RECONCILIATION'
           OR linked.reconciliation_case_id <> NEW.id
           OR linked.provider_resource_id <> NEW.provider_resource_id
           OR linked.account_currency <> NEW.account_currency
           OR linked.account_amount <> NEW.difference_amount
           OR linked.occurred_at <> NEW.balance_as_of THEN
          RAISE EXCEPTION 'resolved reconciliation case is not closed by its exact adjustment event';
        END IF;
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_case_closure() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_case_terminal_mutation(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_case_terminal_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF OLD.status IN ('REJECTED','RESOLVED') AND NEW IS DISTINCT FROM OLD THEN
        RAISE EXCEPTION 'terminal reconciliation case is immutable';
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_case_terminal_mutation() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_duplicate_mutation(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_duplicate_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP='DELETE' OR OLD.status IN ('CONSUMED','EXPIRED') THEN
        RAISE EXCEPTION 'terminal duplicate candidate is immutable';
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_duplicate_mutation() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_event_contract(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_event_contract() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE resource_mode varchar(16);
    DECLARE original provider_finance_event%ROWTYPE;
    DECLARE finance_case provider_finance_reconciliation_case%ROWTYPE;
    BEGIN
      SELECT mode INTO resource_mode FROM provider_resource
       WHERE enterprise_id = NEW.enterprise_id AND id = NEW.provider_resource_id;
      IF resource_mode IS NULL THEN
        RAISE EXCEPTION 'provider finance resource is missing';
      END IF;
      IF NEW.event_type LIKE 'API_%' AND resource_mode <> 'API' THEN
        RAISE EXCEPTION 'API finance event requires API resource';
      END IF;
      IF NEW.event_type LIKE 'CODING_PLAN_%' AND resource_mode <> 'CODING_PLAN' THEN
        RAISE EXCEPTION 'Coding Plan finance event requires Coding Plan resource';
      END IF;
      IF NEW.source <> 'MIGRATION' AND NEW.occurred_at > now() THEN
        RAISE EXCEPTION 'future provider finance event is not allowed';
      END IF;
      IF NEW.source <> 'MIGRATION'
         AND NEW.event_type IN ('API_RECHARGE','CODING_PLAN_PURCHASE','CODING_PLAN_RENEWAL')
         AND NEW.occurred_at < '2026-08-31T16:00:00Z'::timestamptz THEN
        RAISE EXCEPTION 'provider finance event predates the cutover instant';
      END IF;
      -- F-P2-6（0083）：期初时点合同——
      --   MIGRATION 源（历史初始化）：仍固定为切换时点（PFH-01 口径不变）；
      --   ADMIN 源（激活后资源级）：仅企业已激活且资源处于 PENDING 时，
      --     允许 created_at <= occurred_at <= now()，且同资源多币种期初同点；
      --   期初更正：必须追随其原始期初事件的 occurred_at（两种口径一致追随）。
      IF NEW.event_type = 'API_OPENING_BALANCE' THEN
        IF NEW.source = 'MIGRATION' THEN
          IF NEW.occurred_at <> '2026-08-31T16:00:00Z'::timestamptz THEN
            RAISE EXCEPTION 'migration opening balance facts must use the cutover instant';
          END IF;
        ELSE
          IF NOT EXISTS (
            SELECT 1 FROM provider_finance_runtime_state runtime
             WHERE runtime.enterprise_id = NEW.enterprise_id
               AND runtime.strict_writes_enabled
          ) THEN
            RAISE EXCEPTION 'resource-level opening balance requires an activated enterprise';
          END IF;
          IF NOT EXISTS (
            SELECT 1 FROM provider_resource_finance_state fin_state
             WHERE fin_state.provider_resource_id = NEW.provider_resource_id
               AND fin_state.state = 'PENDING'
          ) THEN
            RAISE EXCEPTION 'resource-level opening balance requires a PENDING resource finance state';
          END IF;
          IF NEW.occurred_at < (SELECT resource.created_at FROM provider_resource resource
             WHERE resource.enterprise_id = NEW.enterprise_id
               AND resource.id = NEW.provider_resource_id) THEN
            RAISE EXCEPTION 'resource-level opening balance must not predate the resource creation';
          END IF;
          IF EXISTS (
            SELECT 1 FROM provider_finance_event other_opening
             WHERE other_opening.enterprise_id = NEW.enterprise_id
               AND other_opening.provider_resource_id = NEW.provider_resource_id
               AND other_opening.event_type = 'API_OPENING_BALANCE'
               AND other_opening.occurred_at <> NEW.occurred_at
          ) THEN
            RAISE EXCEPTION 'multi-currency opening balances must share one resource effective instant';
          END IF;
        END IF;
      END IF;
      IF NEW.event_type = 'API_OPENING_BALANCE_CORRECTION' THEN
        IF NOT EXISTS (
          SELECT 1 FROM provider_finance_event original_opening
           WHERE original_opening.enterprise_id = NEW.enterprise_id
             AND original_opening.id = NEW.correction_of_event_id
             AND original_opening.occurred_at = NEW.occurred_at
        ) THEN
          RAISE EXCEPTION 'opening correction must reuse the original opening instant';
        END IF;
      END IF;
      IF NEW.event_type = 'API_RECHARGE' AND NOT EXISTS (
        SELECT 1 FROM provider_finance_event opening
         WHERE opening.enterprise_id = NEW.enterprise_id
           AND opening.provider_resource_id = NEW.provider_resource_id
           AND opening.account_currency = NEW.account_currency
           AND opening.event_type = 'API_OPENING_BALANCE'
      ) THEN
        RAISE EXCEPTION 'API recharge requires an opening balance in the same currency';
      END IF;
      IF NEW.event_type = 'API_OPENING_BALANCE_CORRECTION' THEN
        SELECT * INTO original FROM provider_finance_event
         WHERE enterprise_id = NEW.enterprise_id AND id = NEW.correction_of_event_id;
        IF original.id IS NULL OR original.event_type <> 'API_OPENING_BALANCE'
           OR original.provider_resource_id <> NEW.provider_resource_id
           OR original.account_currency <> NEW.account_currency THEN
          RAISE EXCEPTION 'opening correction must reference the matching opening event';
        END IF;
      END IF;
      IF NEW.event_type = 'REVERSAL' THEN
        SELECT * INTO original FROM provider_finance_event
         WHERE enterprise_id = NEW.enterprise_id AND id = NEW.reversal_of_event_id;
        IF original.id IS NULL OR original.event_type NOT IN (
          'API_RECHARGE','CODING_PLAN_PURCHASE','CODING_PLAN_RENEWAL'
        ) OR original.provider_resource_id <> NEW.provider_resource_id
          OR original.account_currency <> NEW.account_currency
          OR NEW.account_amount <> -original.account_amount
          OR NEW.cash_paid_cny IS DISTINCT FROM -original.cash_paid_cny
          OR NEW.occurred_at <> original.occurred_at THEN
          RAISE EXCEPTION 'reversal must exactly negate an eligible original event';
        END IF;
      END IF;
      IF NEW.event_type = 'API_BALANCE_RECONCILIATION' THEN
        SELECT * INTO finance_case FROM provider_finance_reconciliation_case
         WHERE enterprise_id = NEW.enterprise_id AND id = NEW.reconciliation_case_id;
        IF finance_case.id IS NULL OR finance_case.status <> 'OPEN'
           OR finance_case.provider_resource_id <> NEW.provider_resource_id
           OR finance_case.account_currency <> NEW.account_currency
           OR finance_case.difference_amount <> NEW.account_amount
           OR finance_case.balance_as_of <> NEW.occurred_at THEN
          RAISE EXCEPTION 'balance reconciliation must match its open case';
        END IF;
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_event_contract() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_ledger_period_link(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_ledger_period_link() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE period provider_subscription_period%ROWTYPE;
    BEGIN
      IF NEW.resource_mode='API' AND NEW.subscription_period_id IS NOT NULL THEN
        RAISE EXCEPTION 'API ledger line cannot reference a subscription period';
      END IF;
      IF NEW.subscription_period_id IS NOT NULL THEN
        SELECT * INTO period FROM provider_subscription_period
         WHERE enterprise_id=NEW.enterprise_id
           AND provider_resource_id=NEW.provider_resource_id
           AND id=NEW.subscription_period_id;
        IF period.id IS NULL OR period.reversed_by_event_id IS NOT NULL
           OR NEW.settled_at IS NULL
           OR NEW.settled_at < period.period_start
           OR NEW.settled_at >= period.period_end_exclusive THEN
          RAISE EXCEPTION 'ledger line subscription period does not cover settlement time';
        END IF;
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_ledger_period_link() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_legacy_cost_event(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_legacy_cost_event() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE resolution provider_finance_legacy_cost_resolution%ROWTYPE;
    BEGIN
      IF NEW.event_type='API_LEGACY_COST_ADJUSTMENT' THEN
        SELECT * INTO resolution FROM provider_finance_legacy_cost_resolution
         WHERE enterprise_id=NEW.enterprise_id AND id=NEW.legacy_cost_resolution_id;
        IF NEW.source <> 'MIGRATION' OR resolution.id IS NULL OR resolution.status <> 'OPEN'
           OR resolution.provider_resource_id <> NEW.provider_resource_id
           OR resolution.account_currency <> NEW.account_currency
           OR NEW.account_amount <> -resolution.missing_api_cost
           OR NEW.occurred_at <> resolution.window_end_inclusive THEN
          RAISE EXCEPTION 'legacy cost adjustment does not match its open resolution';
        END IF;
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_legacy_cost_event() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_legacy_cost_resolution(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_legacy_cost_resolution() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE resource_mode varchar(16);
    DECLARE provider_code varchar(64);
    DECLARE snapshot provider_resource_operating_snapshot%ROWTYPE;
    BEGIN
      SELECT resource.mode, provider.code INTO resource_mode, provider_code
        FROM provider_resource resource
        JOIN provider ON provider.enterprise_id=resource.enterprise_id
         AND provider.id=resource.provider_id
       WHERE resource.enterprise_id=NEW.enterprise_id AND resource.id=NEW.provider_resource_id;
      IF resource_mode <> 'API' OR lower(provider_code) <> 'deepseek' THEN
        RAISE EXCEPTION 'legacy API cost resolution requires a DeepSeek API resource';
      END IF;
      SELECT * INTO snapshot FROM provider_resource_operating_snapshot
       WHERE enterprise_id=NEW.enterprise_id
         AND provider_resource_id=NEW.provider_resource_id
         AND id=NEW.provider_balance_snapshot_id;
      IF snapshot.id IS NULL OR snapshot.source <> 'PROVIDER_SYNC'
         OR snapshot.balance_source <> 'PROVIDER_API'
         OR snapshot.currency <> NEW.account_currency
         OR snapshot.current_balance <> NEW.provider_confirmed_balance
         OR snapshot.collected_at <> NEW.window_end_inclusive THEN
        RAISE EXCEPTION 'legacy cost resolution requires an exact provider balance snapshot';
      END IF;
      IF TG_OP='UPDATE' AND OLD.status='RESOLVED' THEN
        RAISE EXCEPTION 'resolved legacy cost resolution is immutable';
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_legacy_cost_resolution() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_legacy_event_closure(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_legacy_event_closure() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE resolution provider_finance_legacy_cost_resolution%ROWTYPE;
    BEGIN
      IF NEW.event_type='API_LEGACY_COST_ADJUSTMENT' THEN
        SELECT * INTO resolution FROM provider_finance_legacy_cost_resolution
         WHERE enterprise_id=NEW.enterprise_id AND id=NEW.legacy_cost_resolution_id;
        IF resolution.status <> 'RESOLVED' OR resolution.adjustment_event_id <> NEW.id THEN
          RAISE EXCEPTION 'legacy cost adjustment is not closed by its resolution';
        END IF;
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_legacy_event_closure() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_legacy_line_link(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_legacy_line_link() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE resolution provider_finance_legacy_cost_resolution%ROWTYPE;
    BEGIN
      IF NEW.legacy_cost_resolution_id IS NOT NULL THEN
        SELECT * INTO resolution FROM provider_finance_legacy_cost_resolution
         WHERE enterprise_id=NEW.enterprise_id AND id=NEW.legacy_cost_resolution_id;
        IF NEW.resource_mode <> 'API' OR NEW.api_cost_status <> 'UNKNOWN_COST'
           OR NEW.api_cost IS NOT NULL OR NEW.api_cost_currency IS NOT NULL
           OR resolution.id IS NULL OR resolution.provider_resource_id <> NEW.provider_resource_id
           OR NEW.settled_at < resolution.window_start
           OR NEW.settled_at > resolution.window_end_inclusive THEN
          RAISE EXCEPTION 'legacy cost resolution can only cover matching unknown API lines';
        END IF;
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_legacy_line_link() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_legacy_resolution_closure(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_legacy_resolution_closure() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE event provider_finance_event%ROWTYPE;
    DECLARE linked_count bigint;
    DECLARE remaining_count bigint;
    BEGIN
      IF NEW.status='RESOLVED' THEN
        SELECT * INTO event FROM provider_finance_event
         WHERE enterprise_id=NEW.enterprise_id AND id=NEW.adjustment_event_id;
        SELECT COUNT(*) INTO linked_count FROM ledger_line
         WHERE enterprise_id=NEW.enterprise_id
           AND legacy_cost_resolution_id=NEW.id;
        SELECT COUNT(*) INTO remaining_count FROM ledger_line
         WHERE enterprise_id=NEW.enterprise_id
           AND provider_resource_id=NEW.provider_resource_id
           AND resource_mode='API' AND api_cost_status='UNKNOWN_COST'
           AND legacy_cost_resolution_id IS NULL
           AND settled_at>=NEW.window_start AND settled_at<=NEW.window_end_inclusive;
        IF event.id IS NULL OR event.event_type <> 'API_LEGACY_COST_ADJUSTMENT'
           OR event.legacy_cost_resolution_id <> NEW.id
           OR event.account_amount <> -NEW.missing_api_cost
           OR linked_count <> NEW.unknown_line_count OR remaining_count <> 0 THEN
          RAISE EXCEPTION 'legacy cost resolution is not closed by exact event and lines';
        END IF;
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_legacy_resolution_closure() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_period_closure(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_period_closure() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE original provider_finance_event%ROWTYPE;
    DECLARE period provider_subscription_period%ROWTYPE;
    BEGIN
      IF NEW.event_type IN ('CODING_PLAN_PURCHASE','CODING_PLAN_RENEWAL') THEN
        SELECT * INTO period FROM provider_subscription_period
         WHERE enterprise_id=NEW.enterprise_id AND finance_event_id=NEW.id;
        IF period.id IS NULL OR period.provider_resource_id <> NEW.provider_resource_id THEN
          RAISE EXCEPTION 'Coding Plan finance event is missing its period';
        END IF;
      ELSIF NEW.event_type='REVERSAL' THEN
        SELECT * INTO original FROM provider_finance_event
         WHERE enterprise_id=NEW.enterprise_id AND id=NEW.reversal_of_event_id;
        IF original.event_type IN ('CODING_PLAN_PURCHASE','CODING_PLAN_RENEWAL') THEN
          SELECT * INTO period FROM provider_subscription_period
           WHERE enterprise_id=NEW.enterprise_id AND finance_event_id=original.id;
          IF period.id IS NULL OR period.reversed_by_event_id <> NEW.id THEN
            RAISE EXCEPTION 'Coding Plan reversal did not reverse its period';
          END IF;
        END IF;
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_period_closure() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_period_contract(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_period_contract() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE finance_event provider_finance_event%ROWTYPE;
    DECLARE reversal_event provider_finance_event%ROWTYPE;
    DECLARE resource_mode varchar(16);
    BEGIN
      SELECT mode INTO resource_mode FROM provider_resource
       WHERE enterprise_id=NEW.enterprise_id AND id=NEW.provider_resource_id;
      IF resource_mode <> 'CODING_PLAN' THEN
        RAISE EXCEPTION 'subscription period requires Coding Plan resource';
      END IF;
      IF NEW.finance_event_id IS NOT NULL THEN
        SELECT * INTO finance_event FROM provider_finance_event
         WHERE enterprise_id=NEW.enterprise_id AND id=NEW.finance_event_id;
        IF finance_event.id IS NULL
           OR finance_event.provider_resource_id <> NEW.provider_resource_id
           OR finance_event.event_type NOT IN ('CODING_PLAN_PURCHASE','CODING_PLAN_RENEWAL')
           OR (finance_event.occurred_at AT TIME ZONE 'Asia/Shanghai')::date
              <> (NEW.period_start AT TIME ZONE 'Asia/Shanghai')::date THEN
          RAISE EXCEPTION 'subscription period does not match its finance event';
        END IF;
      END IF;
      IF NEW.reversed_by_event_id IS NOT NULL THEN
        SELECT * INTO reversal_event FROM provider_finance_event
         WHERE enterprise_id=NEW.enterprise_id AND id=NEW.reversed_by_event_id;
        IF reversal_event.id IS NULL OR reversal_event.event_type <> 'REVERSAL'
           OR NEW.finance_event_id IS NULL
           OR reversal_event.reversal_of_event_id <> NEW.finance_event_id
           OR reversal_event.provider_resource_id <> NEW.provider_resource_id THEN
          RAISE EXCEPTION 'subscription period reversal does not match its finance event';
        END IF;
      END IF;
      IF TG_OP='UPDATE' AND OLD.reversed_by_event_id IS NOT NULL
         AND NEW.reversed_by_event_id IS DISTINCT FROM OLD.reversed_by_event_id THEN
        RAISE EXCEPTION 'subscription period reversal is immutable';
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_period_contract() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_period_mutation(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_period_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP='UPDATE' THEN
        IF NEW.enterprise_id IS DISTINCT FROM OLD.enterprise_id
           OR NEW.provider_resource_id IS DISTINCT FROM OLD.provider_resource_id
           OR NEW.product_name IS DISTINCT FROM OLD.product_name
           OR NEW.period_start IS DISTINCT FROM OLD.period_start
           OR NEW.period_end_exclusive IS DISTINCT FROM OLD.period_end_exclusive
           OR NEW.source IS DISTINCT FROM OLD.source
           OR NEW.migration_source_record_id IS DISTINCT FROM OLD.migration_source_record_id
           OR NEW.created_by_admin_user_id IS DISTINCT FROM OLD.created_by_admin_user_id
           OR NEW.created_at IS DISTINCT FROM OLD.created_at THEN
          RAISE EXCEPTION 'subscription period identity is immutable';
        END IF;
        IF NEW.finance_event_id IS DISTINCT FROM OLD.finance_event_id
           AND NOT (OLD.source='MIGRATED_PURCHASE' AND OLD.finance_event_id IS NULL
             AND NEW.finance_event_id IS NOT NULL) THEN
          RAISE EXCEPTION 'subscription period finance binding is immutable';
        END IF;
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_period_mutation() OWNER TO wp6_r7;

--
-- Name: provider_finance_validate_strict_ledger_fact(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.provider_finance_validate_strict_ledger_fact() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE strict_enabled boolean;
    DECLARE req_import_source varchar(32);
    DECLARE req_import_run_id uuid;
    DECLARE req_started_at timestamptz;
    DECLARE run_status varchar(32);
    BEGIN
      SELECT strict_writes_enabled INTO strict_enabled
        FROM provider_finance_runtime_state WHERE enterprise_id=NEW.enterprise_id;
      IF COALESCE(strict_enabled, false) THEN
        IF NEW.settled_at IS NULL OR NEW.api_cost_status IS NULL THEN
          RAISE EXCEPTION 'active provider finance ledger requires settlement and cost status';
        END IF;

        -- 检查请求是否带有导入来源
        SELECT import_source, import_run_id, started_at
          INTO req_import_source, req_import_run_id, req_started_at
          FROM ai_request WHERE id = NEW.ai_request_id AND enterprise_id = NEW.enterprise_id;

        IF req_import_source IS NOT NULL THEN
          -- 必须为 LEGACY_MAC_MINI 且挂接处于 RUNNING 状态的有效 import_run
          IF req_import_source <> 'LEGACY_MAC_MINI' THEN
            RAISE EXCEPTION 'Invalid import source % for historical ledger line', req_import_source;
          END IF;
          IF req_import_run_id IS NULL THEN
            RAISE EXCEPTION 'Historical imported ledger line requires an active import_run';
          END IF;
          SELECT status INTO run_status
            FROM historical_import_run
           WHERE id = req_import_run_id AND enterprise_id = NEW.enterprise_id;
          IF run_status IS NULL OR run_status <> 'RUNNING' THEN
            RAISE EXCEPTION 'Historical imported ledger line requires an active RUNNING import_run';
          END IF;
          IF req_started_at >= '2026-09-21T11:30:06.052+08:00'::timestamptz
             OR req_started_at < '2026-08-01T00:00:00+08:00'::timestamptz THEN
            RAISE EXCEPTION 'Historical imported request timestamp is outside the historical import window';
          END IF;
          IF NEW.legacy_cost_resolution_id IS NOT NULL THEN
            RAISE EXCEPTION 'Historical imported ledger line cannot reference legacy_cost_resolution';
          END IF;
          IF NEW.subscription_period_id IS NOT NULL THEN
            RAISE EXCEPTION 'Historical imported ledger line cannot reference a subscription period';
          END IF;

          -- 按资源模式分别强约束金额与状态
          IF NEW.resource_mode = 'API' THEN
            IF NEW.api_cost_status <> 'NOT_MIGRATED' THEN
              RAISE EXCEPTION 'Historical API ledger line must have NOT_MIGRATED api_cost_status';
            END IF;
            IF NEW.api_cost IS NOT NULL OR NEW.api_cost_currency IS NOT NULL THEN
              RAISE EXCEPTION 'NOT_MIGRATED ledger line must have NULL api_cost and api_cost_currency';
            END IF;
          ELSIF NEW.resource_mode = 'CODING_PLAN' THEN
            IF NEW.api_cost_status <> 'NOT_APPLICABLE' THEN
              RAISE EXCEPTION 'Historical Coding Plan ledger line must have NOT_APPLICABLE api_cost_status';
            END IF;
            IF NEW.api_cost IS NOT NULL OR NEW.api_cost_currency IS NOT NULL THEN
              RAISE EXCEPTION 'NOT_APPLICABLE ledger line must have NULL api_cost and api_cost_currency';
            END IF;
          ELSE
            RAISE EXCEPTION 'Unsupported resource_mode % for historical ledger line', NEW.resource_mode;
          END IF;

          -- 校验通过，直接返回，不施加运行时 period 强制约束
          RETURN NEW;
        END IF;

        -- 非导入行严禁使用 NOT_MIGRATED
        IF NEW.api_cost_status = 'NOT_MIGRATED' THEN
          RAISE EXCEPTION 'NOT_MIGRATED cost status is only valid for LEGACY_MAC_MINI imported requests';
        END IF;

        -- 运行时原有严格校验不变
        IF NEW.resource_mode='API' AND NEW.subscription_period_id IS NOT NULL THEN
          RAISE EXCEPTION 'active API ledger line cannot reference a subscription period';
        END IF;
        IF NEW.resource_mode='CODING_PLAN'
           AND (NEW.api_cost_status<>'NOT_APPLICABLE' OR NEW.subscription_period_id IS NULL) THEN
          RAISE EXCEPTION 'active Coding Plan ledger line requires an attributed period';
        END IF;
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.provider_finance_validate_strict_ledger_fact() OWNER TO wp6_r7;

--
-- Name: qianliu_identity_enterprise_guard(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.qianliu_identity_enterprise_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE resolved uuid;
    BEGIN
      SELECT enterprise_id INTO resolved FROM person WHERE id = NEW.person_id;
      IF resolved IS NULL THEN RAISE EXCEPTION 'person_external_identity references missing Person'; END IF;
      IF NEW.enterprise_id IS NOT NULL AND NEW.enterprise_id <> resolved THEN
        RAISE EXCEPTION 'person_external_identity enterprise mismatch';
      END IF;
      NEW.enterprise_id := resolved;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.qianliu_identity_enterprise_guard() OWNER TO wp6_r7;

--
-- Name: qianliu_person_enterprise_default(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.qianliu_person_enterprise_default() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE resolved uuid;
    BEGIN
      IF NEW.enterprise_id IS NULL THEN
        SELECT min(id::text)::uuid INTO resolved FROM enterprise
        HAVING count(*) = 1;
        IF resolved IS NULL THEN
          RAISE EXCEPTION 'person.enterprise_id is required when deployment has multiple enterprises';
        END IF;
        NEW.enterprise_id := resolved;
      END IF;
      RETURN NEW;
    END;
    $$;


ALTER FUNCTION public.qianliu_person_enterprise_default() OWNER TO wp6_r7;

--
-- Name: validate_bill_allocation_ref(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.validate_bill_allocation_ref() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP <> 'INSERT' THEN
        RAISE EXCEPTION 'bill allocation references are immutable';
      END IF;
      RETURN NEW;
    END $$;


ALTER FUNCTION public.validate_bill_allocation_ref() OWNER TO wp6_r7;

--
-- Name: validate_employee_allocation_policy(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.validate_employee_allocation_policy() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'allocation policy versions are immutable';
      END IF;
      IF TG_OP = 'UPDATE' THEN
        IF (to_jsonb(NEW) - 'is_current') IS DISTINCT FROM (to_jsonb(OLD) - 'is_current')
          OR NOT (OLD.is_current AND NOT NEW.is_current) THEN
          RAISE EXCEPTION 'allocation policy versions are immutable';
        END IF;
      END IF;
      IF NOT EXISTS (
        SELECT 1 FROM principal
        WHERE enterprise_id = NEW.enterprise_id AND id = NEW.employee_principal_id AND type = 'EMPLOYEE'
      ) THEN
        RAISE EXCEPTION 'allocation policy requires an EMPLOYEE principal';
      END IF;
      RETURN NEW;
    END $$;


ALTER FUNCTION public.validate_employee_allocation_policy() OWNER TO wp6_r7;

--
-- Name: validate_employee_allocation_rule(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.validate_employee_allocation_rule() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    DECLARE
      revision_row project_membership_revision%ROWTYPE;
    BEGIN
      IF TG_OP <> 'INSERT' THEN
        RAISE EXCEPTION 'published allocation rules are immutable';
      END IF;
      IF NOT EXISTS (
        SELECT 1 FROM project_membership m
        WHERE m.id = NEW.membership_id AND m.enterprise_id = NEW.enterprise_id
          AND m.employee_principal_id = NEW.employee_principal_id
          AND m.project_principal_id = NEW.project_principal_id
      ) THEN
        RAISE EXCEPTION 'allocation rule must reference its own membership';
      END IF;
      IF NOT EXISTS (
        SELECT 1 FROM employee_project_allocation_policy p
        WHERE p.id = NEW.policy_id AND p.enterprise_id = NEW.enterprise_id
          AND p.employee_principal_id = NEW.employee_principal_id
      ) THEN
        RAISE EXCEPTION 'allocation rule policy must belong to the same employee';
      END IF;
      SELECT * INTO revision_row FROM project_membership_revision
        WHERE id = NEW.membership_revision_id;
      IF revision_row.membership_id IS DISTINCT FROM NEW.membership_id
        OR revision_row.enterprise_id IS DISTINCT FROM NEW.enterprise_id
        OR revision_row.employee_principal_id IS DISTINCT FROM NEW.employee_principal_id
        OR revision_row.project_principal_id IS DISTINCT FROM NEW.project_principal_id
        OR revision_row.status IS DISTINCT FROM 'ACTIVE' THEN
        RAISE EXCEPTION 'allocation rule must reference the ACTIVE revision of its membership';
      END IF;
      IF revision_row.joined_at > NEW.valid_from
        OR (NEW.valid_until IS NULL AND revision_row.left_at IS NOT NULL)
        OR (NEW.valid_until IS NOT NULL AND revision_row.left_at IS NOT NULL
          AND NEW.valid_until > revision_row.left_at) THEN
        RAISE EXCEPTION 'allocation rule interval must be covered by its membership revision interval';
      END IF;
      RETURN NEW;
    END $$;


ALTER FUNCTION public.validate_employee_allocation_rule() OWNER TO wp6_r7;

--
-- Name: validate_principal_accounting_assignment(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.validate_principal_accounting_assignment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP='DELETE' THEN RAISE EXCEPTION 'accounting assignment history is immutable'; END IF;
      IF TG_OP='UPDATE' THEN
        IF (to_jsonb(NEW)-'valid_until') IS DISTINCT FROM (to_jsonb(OLD)-'valid_until')
          OR OLD.valid_until IS NOT NULL OR NEW.valid_until IS NULL THEN
          RAISE EXCEPTION 'accounting assignment history is immutable';
        END IF;
      END IF;
      IF NOT EXISTS(SELECT 1 FROM principal WHERE enterprise_id=NEW.enterprise_id AND id=NEW.principal_id AND type=NEW.principal_type) THEN
        RAISE EXCEPTION 'accounting principal type mismatch';
      END IF;
      IF NEW.owner_principal_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM principal WHERE enterprise_id=NEW.enterprise_id AND id=NEW.owner_principal_id AND type='EMPLOYEE') THEN
        RAISE EXCEPTION 'project owner must be an employee';
      END IF;
      RETURN NEW;
    END $$;


ALTER FUNCTION public.validate_principal_accounting_assignment() OWNER TO wp6_r7;

--
-- Name: validate_project_accounting_profile(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.validate_project_accounting_profile() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'project accounting history is immutable';
      END IF;
      IF TG_OP = 'UPDATE' THEN
        IF (to_jsonb(NEW) - 'is_current') IS DISTINCT FROM (to_jsonb(OLD) - 'is_current')
          OR NOT (OLD.is_current AND NOT NEW.is_current) THEN
          RAISE EXCEPTION 'project accounting history is immutable';
        END IF;
      END IF;
      IF NOT EXISTS (
        SELECT 1 FROM principal
        WHERE enterprise_id = NEW.enterprise_id AND id = NEW.project_principal_id AND type = 'PROJECT'
      ) THEN
        RAISE EXCEPTION 'accounting profile requires a PROJECT principal';
      END IF;
      RETURN NEW;
    END $$;


ALTER FUNCTION public.validate_project_accounting_profile() OWNER TO wp6_r7;

--
-- Name: validate_project_allocation_line(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.validate_project_allocation_line() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP <> 'INSERT' THEN
        RAISE EXCEPTION 'allocation lines are immutable within their run';
      END IF;
      IF NEW.target_type = 'PROJECT' AND NOT EXISTS (
        SELECT 1 FROM principal p
        WHERE p.enterprise_id = NEW.enterprise_id AND p.id = NEW.target_project_principal_id
          AND p.type = 'PROJECT'
      ) THEN
        RAISE EXCEPTION 'allocation line target must be a PROJECT principal of the same enterprise';
      END IF;
      RETURN NEW;
    END $$;


ALTER FUNCTION public.validate_project_allocation_line() OWNER TO wp6_r7;

--
-- Name: validate_project_allocation_resource_residual(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.validate_project_allocation_resource_residual() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP <> 'INSERT' THEN
        RAISE EXCEPTION 'resource residual rows are immutable within their run';
      END IF;
      RETURN NEW;
    END $$;


ALTER FUNCTION public.validate_project_allocation_resource_residual() OWNER TO wp6_r7;

--
-- Name: validate_project_allocation_run(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.validate_project_allocation_run() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'allocation runs are append-only';
      END IF;
      IF TG_OP = 'UPDATE' THEN
        IF OLD.status IN ('SUCCEEDED', 'FAILED') THEN
          IF (to_jsonb(NEW) - 'is_current') IS DISTINCT FROM (to_jsonb(OLD) - 'is_current')
            OR NOT (OLD.is_current AND NOT NEW.is_current) THEN
            RAISE EXCEPTION 'published allocation runs are immutable (only is_current may be closed)';
          END IF;
        ELSE
          IF (to_jsonb(NEW) - 'status' - 'input_digest' - 'rule_input_digest' - 'membership_input_digest'
                - 'manual_attribution_input_digest' - 'source_fact_digest' - 'source_snapshot_as_of'
                - 'input_dirty_generation' - 'attempt' - 'lease_owner' - 'lease_expires_at' - 'last_error'
                - 'is_current' - 'source_line_count' - 'employee_count' - 'project_count' - 'conservation'
                - 'completeness' - 'result_hash' - 'started_at' - 'finished_at' - 'duration_ms' - 'updated_at')
              IS DISTINCT FROM (to_jsonb(OLD) - 'status' - 'input_digest' - 'rule_input_digest'
                - 'membership_input_digest' - 'manual_attribution_input_digest' - 'source_fact_digest'
                - 'source_snapshot_as_of' - 'input_dirty_generation' - 'attempt' - 'lease_owner'
                - 'lease_expires_at' - 'last_error' - 'is_current' - 'source_line_count' - 'employee_count'
                - 'project_count' - 'conservation' - 'completeness' - 'result_hash' - 'started_at'
                - 'finished_at' - 'duration_ms' - 'updated_at') THEN
            RAISE EXCEPTION 'allocation run identity is immutable';
          END IF;
          IF NOT (
            (OLD.status = 'QUEUED' AND NEW.status IN ('QUEUED', 'RUNNING', 'SUCCEEDED', 'FAILED'))
            OR (OLD.status = 'RUNNING' AND NEW.status IN ('RUNNING', 'SUCCEEDED', 'FAILED'))
          ) THEN
            RAISE EXCEPTION 'allocation run status must move forward';
          END IF;
        END IF;
      END IF;
      RETURN NEW;
    END $$;


ALTER FUNCTION public.validate_project_allocation_run() OWNER TO wp6_r7;

--
-- Name: validate_project_membership(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.validate_project_membership() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP <> 'INSERT' THEN
        RAISE EXCEPTION 'membership identities are immutable';
      END IF;
      IF NOT EXISTS (
        SELECT 1 FROM principal
        WHERE enterprise_id = NEW.enterprise_id AND id = NEW.project_principal_id AND type = 'PROJECT'
      ) OR NOT EXISTS (
        SELECT 1 FROM principal
        WHERE enterprise_id = NEW.enterprise_id AND id = NEW.employee_principal_id AND type = 'EMPLOYEE'
      ) THEN
        RAISE EXCEPTION 'membership requires a PROJECT project principal and an EMPLOYEE employee principal';
      END IF;
      RETURN NEW;
    END $$;


ALTER FUNCTION public.validate_project_membership() OWNER TO wp6_r7;

--
-- Name: validate_project_membership_revision(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.validate_project_membership_revision() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'membership history is immutable';
      END IF;
      IF TG_OP = 'UPDATE' THEN
        IF (to_jsonb(NEW) - 'status') IS DISTINCT FROM (to_jsonb(OLD) - 'status')
          OR NOT (OLD.status = 'ACTIVE' AND NEW.status IN ('SUPERSEDED', 'VOID')) THEN
          RAISE EXCEPTION 'membership history is immutable';
        END IF;
      END IF;
      IF NOT EXISTS (
        SELECT 1 FROM project_membership m
        JOIN principal emp ON emp.enterprise_id = m.enterprise_id AND emp.id = m.employee_principal_id
        WHERE m.id = NEW.membership_id AND m.enterprise_id = NEW.enterprise_id
          AND m.project_principal_id = NEW.project_principal_id
          AND m.employee_principal_id = NEW.employee_principal_id
          AND emp.type = 'EMPLOYEE'
      ) THEN
        RAISE EXCEPTION 'membership revision must match an EMPLOYEE membership of the same enterprise';
      END IF;
      RETURN NEW;
    END $$;


ALTER FUNCTION public.validate_project_membership_revision() OWNER TO wp6_r7;

--
-- Name: w20_reject_immutable_mutation(); Type: FUNCTION; Schema: public; Owner: wp6_r7
--

CREATE FUNCTION public.w20_reject_immutable_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    BEGIN
      RAISE EXCEPTION '% is append-only', TG_TABLE_NAME USING ERRCODE = '55000';
    END;
    $$;


ALTER FUNCTION public.w20_reject_immutable_mutation() OWNER TO wp6_r7;

--
-- Name: _migration_0045_pool046_backup; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public._migration_0045_pool046_backup (
    row_type character varying(32) NOT NULL,
    row_id uuid NOT NULL,
    original_alias character varying(64),
    original_days_of_week jsonb,
    original_time_windows jsonb,
    original_updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public._migration_0045_pool046_backup OWNER TO wp6_r7;

--
-- Name: _w01_baseline_probe; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public._w01_baseline_probe (
    id integer NOT NULL,
    note character varying(255),
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL
);


ALTER TABLE public._w01_baseline_probe OWNER TO wp6_r7;

--
-- Name: _w01_baseline_probe_id_seq; Type: SEQUENCE; Schema: public; Owner: wp6_r7
--

CREATE SEQUENCE public._w01_baseline_probe_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public._w01_baseline_probe_id_seq OWNER TO wp6_r7;

--
-- Name: _w01_baseline_probe_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wp6_r7
--

ALTER SEQUENCE public._w01_baseline_probe_id_seq OWNED BY public._w01_baseline_probe.id;


--
-- Name: admin_role; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.admin_role (
    enterprise_id uuid NOT NULL,
    name character varying(128) NOT NULL,
    permissions jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT admin_role_name_check CHECK ((length(TRIM(BOTH FROM name)) > 0))
);


ALTER TABLE public.admin_role OWNER TO wp6_r7;

--
-- Name: admin_session; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.admin_session (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_user_id uuid NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    user_agent character varying(512),
    ip_address character varying(64),
    last_seen_at timestamp with time zone
);


ALTER TABLE public.admin_session OWNER TO wp6_r7;

--
-- Name: admin_user; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.admin_user (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    username character varying(128) NOT NULL,
    password_hash text NOT NULL,
    status character varying(32) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    display_name character varying(128) DEFAULT '管理员'::character varying NOT NULL,
    must_change_password boolean DEFAULT false NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    archived_at timestamp with time zone,
    role_code text DEFAULT 'SUPER_ADMIN'::text NOT NULL,
    CONSTRAINT admin_user_role_code_check CHECK ((role_code = ANY (ARRAY['SUPER_ADMIN'::text, 'CUSTOM'::text])))
);


ALTER TABLE public.admin_user OWNER TO wp6_r7;

--
-- Name: ai_request; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.ai_request (
    id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    principal_key_id uuid NOT NULL,
    idempotency_key character varying(128),
    protocol character varying(32) NOT NULL,
    unified_model character varying(64) NOT NULL,
    stream boolean DEFAULT false NOT NULL,
    status character varying(16) DEFAULT 'PENDING'::character varying NOT NULL,
    client_id character varying(64),
    started_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    finished_at timestamp with time zone,
    error_classification character varying(64),
    error_code character varying(64),
    client_request_id character varying(128),
    request_fingerprint character(64),
    agent_family character varying(32) DEFAULT 'UNKNOWN'::character varying NOT NULL,
    agent_version character varying(32),
    agent_identity_source character varying(32) DEFAULT 'NONE'::character varying NOT NULL,
    agent_identity_confidence character varying(24) DEFAULT 'UNKNOWN'::character varying NOT NULL,
    client_identity_rule_version character varying(32) DEFAULT 'legacy'::character varying NOT NULL,
    unified_model_id uuid,
    import_source character varying(32),
    import_run_id uuid,
    CONSTRAINT ai_request_agent_family_check CHECK (((agent_family)::text = ANY ((ARRAY['WORKBUDDY'::character varying, 'CODEX'::character varying, 'ZCODE'::character varying, 'CLAUDE_CODE'::character varying, 'QIANLIU_IDE'::character varying, 'OTHER'::character varying, 'UNKNOWN'::character varying])::text[]))),
    CONSTRAINT ai_request_import_source_check CHECK ((((import_source IS NULL) AND (import_run_id IS NULL)) OR (((import_source)::text = 'LEGACY_MAC_MINI'::text) AND (import_run_id IS NOT NULL)))),
    CONSTRAINT ai_request_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying, 'SUCCEEDED'::character varying, 'FAILED'::character varying, 'CANCELLED'::character varying])::text[])))
);


ALTER TABLE public.ai_request OWNER TO wp6_r7;

--
-- Name: alert_event; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.alert_event (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    alert_key character varying(255) NOT NULL,
    domain character varying(32) NOT NULL,
    signal character varying(64) NOT NULL,
    severity character varying(16) DEFAULT 'MEDIUM'::character varying NOT NULL,
    title character varying(255) NOT NULL,
    detail text,
    resource_id uuid,
    principal_id uuid,
    ai_request_id uuid,
    status character varying(16) DEFAULT 'OPEN'::character varying NOT NULL,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone,
    resolution_note text,
    resolved_by uuid,
    source_cleared_at timestamp with time zone,
    availability_event_id uuid,
    recovery_evidence jsonb,
    CONSTRAINT alert_event_domain_check CHECK (((domain)::text = ANY ((ARRAY['RESOURCE_UNAVAILABLE'::character varying, 'USAGE_SPIKE'::character varying, 'QUOTA_ANOMALY'::character varying, 'CREDENTIAL_INVALID'::character varying])::text[]))),
    CONSTRAINT alert_event_severity_check CHECK (((severity)::text = ANY ((ARRAY['HIGH'::character varying, 'MEDIUM'::character varying, 'LOW'::character varying])::text[]))),
    CONSTRAINT alert_event_status_check CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'INVESTIGATING'::character varying, 'RESOLVED'::character varying, 'IGNORED'::character varying, 'AUTO_RESOLVED'::character varying])::text[])))
);


ALTER TABLE public.alert_event OWNER TO wp6_r7;

--
-- Name: availability_event; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.availability_event (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    event_number character varying(32) NOT NULL,
    availability_rule_id uuid NOT NULL,
    rule_version_id uuid NOT NULL,
    rule_version integer NOT NULL,
    provider_id uuid,
    provider_resource_id uuid,
    unified_model_id uuid,
    upstream_model character varying(128),
    unified_signal character varying(64) NOT NULL,
    upstream_code character varying(64),
    sanitized_summary character varying(255),
    availability_decision character varying(32) NOT NULL,
    trigger_ai_request_id uuid,
    trigger_principal_id uuid,
    recovery_method character varying(32) NOT NULL,
    dedup_key character varying(255) NOT NULL,
    status character varying(32) DEFAULT 'OPEN'::character varying NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    recover_at timestamp with time zone,
    recovered_at timestamp with time zone,
    recovery_reason character varying(255),
    affected_request_count integer DEFAULT 0 NOT NULL,
    affected_person_count integer DEFAULT 0 NOT NULL,
    notification_summary jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    quota_block_incident_id uuid,
    CONSTRAINT availability_event_counts_nonnegative_check CHECK (((affected_request_count >= 0) AND (affected_person_count >= 0))),
    CONSTRAINT availability_event_decision_check CHECK (((availability_decision)::text = ANY ((ARRAY['BLOCKED_UPSTREAM'::character varying, 'BLOCKED_SCHEDULE'::character varying])::text[]))),
    CONSTRAINT availability_event_recovery_check CHECK (((recovery_method)::text = ANY ((ARRAY['RETRY_AFTER'::character varying, 'UPSTREAM_RESET_TIME'::character varying, 'FIXED_DURATION'::character varying, 'SCHEDULE_END'::character varying, 'MANUAL'::character varying])::text[]))),
    CONSTRAINT availability_event_signal_check CHECK (((unified_signal)::text = ANY ((ARRAY['RATE_LIMIT_RETRY_AFTER'::character varying, 'QUOTA_EXHAUSTED'::character varying, 'PLAN_EXPIRED'::character varying, 'MODEL_UNAUTHORIZED'::character varying, 'UPSTREAM_MAINTENANCE'::character varying, 'CONFIGURATION_ERROR'::character varying, 'TECHNICAL_FAILURE'::character varying])::text[]))),
    CONSTRAINT availability_event_status_check CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'RECOVERED'::character varying, 'MANUALLY_RECOVERED'::character varying, 'CANCELLED'::character varying])::text[])))
);


ALTER TABLE public.availability_event OWNER TO wp6_r7;

--
-- Name: availability_rule; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.availability_rule (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(128) NOT NULL,
    rule_type character varying(32) NOT NULL,
    description text,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT availability_rule_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'ARCHIVED'::character varying])::text[]))),
    CONSTRAINT availability_rule_type_check CHECK (((rule_type)::text = ANY ((ARRAY['UPSTREAM_SIGNAL'::character varying, 'SCHEDULE_BLOCK'::character varying, 'OBSERVATION_ALERT'::character varying])::text[]))),
    CONSTRAINT availability_rule_version_positive_check CHECK ((version > 0))
);


ALTER TABLE public.availability_rule OWNER TO wp6_r7;

--
-- Name: availability_rule_version; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.availability_rule_version (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    availability_rule_id uuid NOT NULL,
    rule_version integer NOT NULL,
    status character varying(16) DEFAULT 'DRAFT'::character varying NOT NULL,
    provider_id uuid,
    provider_resource_id uuid,
    unified_model_id uuid,
    upstream_model character varying(128),
    unified_signal character varying(64),
    action character varying(16) NOT NULL,
    recovery_method character varying(32),
    fallback_duration_seconds integer,
    schedule_timezone character varying(64),
    schedule_days_of_week jsonb,
    schedule_start_time time without time zone,
    schedule_end_time time without time zone,
    priority integer DEFAULT 100 NOT NULL,
    effective_from timestamp with time zone,
    effective_to timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    created_by uuid,
    published_by uuid,
    published_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT availability_rule_version_action_check CHECK (((action)::text = ANY ((ARRAY['WARN_ONLY'::character varying, 'BLOCK'::character varying])::text[]))),
    CONSTRAINT availability_rule_version_block_recovery_check CHECK ((((action)::text <> 'BLOCK'::text) OR (recovery_method IS NOT NULL))),
    CONSTRAINT availability_rule_version_effective_range_check CHECK (((effective_to IS NULL) OR (effective_from IS NULL) OR (effective_to > effective_from))),
    CONSTRAINT availability_rule_version_fallback_duration_check CHECK (((fallback_duration_seconds IS NULL) OR (fallback_duration_seconds > 0))),
    CONSTRAINT availability_rule_version_lock_positive_check CHECK ((version > 0)),
    CONSTRAINT availability_rule_version_number_check CHECK ((rule_version > 0)),
    CONSTRAINT availability_rule_version_recovery_check CHECK (((recovery_method IS NULL) OR ((recovery_method)::text = ANY ((ARRAY['RETRY_AFTER'::character varying, 'UPSTREAM_RESET_TIME'::character varying, 'FIXED_DURATION'::character varying, 'SCHEDULE_END'::character varying, 'MANUAL'::character varying])::text[])))),
    CONSTRAINT availability_rule_version_signal_check CHECK (((unified_signal IS NULL) OR ((unified_signal)::text = ANY ((ARRAY['RATE_LIMIT_RETRY_AFTER'::character varying, 'QUOTA_EXHAUSTED'::character varying, 'PLAN_EXPIRED'::character varying, 'MODEL_UNAUTHORIZED'::character varying, 'UPSTREAM_MAINTENANCE'::character varying, 'CONFIGURATION_ERROR'::character varying, 'TECHNICAL_FAILURE'::character varying])::text[])))),
    CONSTRAINT availability_rule_version_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'PUBLISHED'::character varying, 'SUPERSEDED'::character varying, 'DISABLED'::character varying])::text[])))
);


ALTER TABLE public.availability_rule_version OWNER TO wp6_r7;

--
-- Name: billing_rule; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.billing_rule (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid,
    upstream_model character varying(128),
    rule_type character varying(32) NOT NULL,
    rule_version character varying(32) NOT NULL,
    effective_from timestamp with time zone NOT NULL,
    effective_to timestamp with time zone,
    timezone character varying(64),
    days_of_week jsonb,
    start_time character varying(8),
    end_time character varying(8),
    multiplier numeric,
    cache_hit_price numeric,
    cache_miss_price numeric,
    output_price numeric,
    currency character varying(8) DEFAULT 'CNY'::character varying NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    source character varying(255),
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    time_windows jsonb,
    archived_at timestamp with time zone,
    archived_by_admin_id uuid,
    pricing_mode text DEFAULT 'ABSOLUTE'::text NOT NULL,
    source_status character varying(16) DEFAULT 'UNVERIFIED'::character varying NOT NULL,
    CONSTRAINT billing_pricing_mode_check CHECK (((pricing_mode = 'ABSOLUTE'::text) OR ((pricing_mode = 'MULTIPLIER'::text) AND ((rule_type)::text = 'API_PRICE'::text) AND (multiplier IS NOT NULL) AND (multiplier > (0)::numeric) AND (cache_hit_price IS NOT NULL) AND (cache_miss_price IS NOT NULL) AND (output_price IS NOT NULL)))),
    CONSTRAINT billing_rule_source_status_check CHECK (((source_status)::text = ANY ((ARRAY['VERIFIED'::character varying, 'UNVERIFIED'::character varying])::text[]))),
    CONSTRAINT billing_rule_time_windows_array_check CHECK (((time_windows IS NULL) OR ((jsonb_typeof(time_windows) = 'array'::text) AND (jsonb_array_length(time_windows) > 0)))),
    CONSTRAINT billing_rule_type_check CHECK (((rule_type)::text = ANY ((ARRAY['TIME_WINDOW'::character varying, 'MODEL_TIER'::character varying, 'CACHE_STATE'::character varying, 'API_PRICE'::character varying])::text[])))
);


ALTER TABLE public.billing_rule OWNER TO wp6_r7;

--
-- Name: concurrency_lease; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.concurrency_lease (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    ai_request_id uuid,
    acquired_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    released_at timestamp with time zone
);


ALTER TABLE public.concurrency_lease OWNER TO wp6_r7;

--
-- Name: credential_chat_probe; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.credential_chat_probe (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    actor_admin_id uuid NOT NULL,
    idempotency_key uuid NOT NULL,
    failure_id uuid NOT NULL,
    upstream_model text NOT NULL,
    credential_version integer,
    credential_digest text NOT NULL,
    config_hash text NOT NULL,
    status text NOT NULL,
    http_status integer,
    error_code text,
    evidence jsonb,
    usage jsonb,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    retry_at timestamp with time zone NOT NULL,
    CONSTRAINT credential_chat_probe_evidence_check CHECK (((evidence IS NULL) OR ((jsonb_typeof(evidence) = 'object'::text) AND (pg_column_size(evidence) <= 4096)))),
    CONSTRAINT credential_chat_probe_status_check CHECK ((status = ANY (ARRAY['RUNNING'::text, 'RECOVERED'::text, 'FAILED'::text, 'STALE'::text, 'CANCELLED'::text, 'EXPIRED'::text])))
);


ALTER TABLE public.credential_chat_probe OWNER TO wp6_r7;

--
-- Name: department_budget; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.department_budget (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    organization_unit_id uuid NOT NULL,
    month date NOT NULL,
    currency character varying(8) NOT NULL,
    amount numeric(24,8) NOT NULL,
    warning_threshold numeric(9,8) DEFAULT 0.80000000 NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT department_budget_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT department_budget_month_check CHECK ((month = (date_trunc('month'::text, (month)::timestamp with time zone))::date)),
    CONSTRAINT department_budget_threshold_check CHECK (((warning_threshold > (0)::numeric) AND (warning_threshold <= (1)::numeric))),
    CONSTRAINT department_budget_version_check CHECK ((version > 0))
);


ALTER TABLE public.department_budget OWNER TO wp6_r7;

--
-- Name: department_budget_idempotency; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.department_budget_idempotency (
    enterprise_id uuid NOT NULL,
    organization_unit_id uuid NOT NULL,
    month date NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    request_hash character(64) NOT NULL,
    response_snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.department_budget_idempotency OWNER TO wp6_r7;

--
-- Name: deployment_log; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.deployment_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    deployment_id character varying(128) NOT NULL,
    started_at timestamp with time zone NOT NULL,
    finished_at timestamp with time zone,
    status character varying(24) NOT NULL,
    from_version character varying(128),
    to_version character varying(128),
    git_commit character varying(64),
    artifact_sha256 character varying(64),
    migration_from character varying(128),
    migration_to character varying(128),
    release_id character varying(128),
    actor character varying(128) NOT NULL,
    summary text NOT NULL,
    pool_refs jsonb DEFAULT '[]'::jsonb NOT NULL,
    backup_ref character varying(256),
    rollback_target character varying(128),
    health_summary jsonb,
    smoke_summary jsonb,
    evidence_refs jsonb DEFAULT '[]'::jsonb NOT NULL,
    failure_classification character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT deployment_log_status_check CHECK (((status)::text = ANY ((ARRAY['IN_PROGRESS'::character varying, 'SUCCEEDED'::character varying, 'FAILED'::character varying, 'ROLLED_BACK'::character varying])::text[])))
);


ALTER TABLE public.deployment_log OWNER TO wp6_r7;

--
-- Name: deployment_log_event; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.deployment_log_event (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    deployment_log_id uuid NOT NULL,
    event_key character varying(128) NOT NULL,
    event_type character varying(32) NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    actor character varying(128) NOT NULL,
    note text,
    payload jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.deployment_log_event OWNER TO wp6_r7;

--
-- Name: directory_import_item; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.directory_import_item (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    run_id uuid NOT NULL,
    row_number integer NOT NULL,
    external_member_id character varying(128),
    employee_number character varying(64),
    normalized_name character varying(128),
    normalized_department_path character varying(512),
    normalized_email character varying(254),
    normalized_mobile character varying(32),
    external_department_id character varying(255),
    existing_principal_id uuid,
    status character varying(16) DEFAULT 'STAGED'::character varying NOT NULL,
    reason_code character varying(64),
    person_id uuid,
    principal_id uuid,
    organization_unit_id uuid,
    attempt integer DEFAULT 0 NOT NULL,
    lease_until timestamp with time zone,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT directory_import_item_row_check CHECK (((row_number > 0) AND (attempt >= 0))),
    CONSTRAINT directory_import_item_status_check CHECK (((status)::text = ANY ((ARRAY['STAGED'::character varying, 'PROCESSING'::character varying, 'MATCHED'::character varying, 'CREATED'::character varying, 'UPDATED'::character varying, 'CONFLICT'::character varying, 'SKIPPED'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public.directory_import_item OWNER TO wp6_r7;

--
-- Name: directory_import_run; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.directory_import_run (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    directory_source_id uuid,
    mode character varying(16) NOT NULL,
    job_type character varying(32) NOT NULL,
    template_version character varying(32),
    connector_version character varying(32),
    source_snapshot_id character varying(255),
    content_sha256 character varying(64),
    request_hash character varying(64) NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    created_by_admin_user_id uuid NOT NULL,
    status character varying(16) DEFAULT 'QUEUED'::character varying NOT NULL,
    total_count integer DEFAULT 0 NOT NULL,
    matched_count integer DEFAULT 0 NOT NULL,
    created_count integer DEFAULT 0 NOT NULL,
    updated_count integer DEFAULT 0 NOT NULL,
    conflict_count integer DEFAULT 0 NOT NULL,
    skipped_count integer DEFAULT 0 NOT NULL,
    failed_count integer DEFAULT 0 NOT NULL,
    failure_reason_code character varying(64),
    source_data_at timestamp with time zone,
    attempt integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone,
    lease_until timestamp with time zone,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT directory_import_run_count_check CHECK (((total_count >= 0) AND (matched_count >= 0) AND (created_count >= 0) AND (updated_count >= 0) AND (conflict_count >= 0) AND (skipped_count >= 0) AND (failed_count >= 0) AND (attempt >= 0))),
    CONSTRAINT directory_import_run_job_check CHECK (((job_type)::text = ANY ((ARRAY['DIRECTORY_SYNC'::character varying, 'DIRECTORY_IMPORT_APPLY'::character varying])::text[]))),
    CONSTRAINT directory_import_run_mode_check CHECK (((mode)::text = ANY ((ARRAY['SYNC'::character varying, 'EXCEL'::character varying])::text[]))),
    CONSTRAINT directory_import_run_source_mode_check CHECK (((((mode)::text = 'SYNC'::text) AND (directory_source_id IS NOT NULL) AND (connector_version IS NOT NULL)) OR (((mode)::text = 'EXCEL'::text) AND (directory_source_id IS NULL) AND (template_version IS NOT NULL) AND (content_sha256 IS NOT NULL)))),
    CONSTRAINT directory_import_run_status_check CHECK (((status)::text = ANY ((ARRAY['QUEUED'::character varying, 'RUNNING'::character varying, 'SUCCEEDED'::character varying, 'PARTIAL'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public.directory_import_run OWNER TO wp6_r7;

--
-- Name: directory_source; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.directory_source (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    type character varying(16) NOT NULL,
    config_ciphertext text NOT NULL,
    config_fingerprint character varying(128) NOT NULL,
    config_key_version integer DEFAULT 1 NOT NULL,
    connector_version character varying(32) DEFAULT 'v1'::character varying NOT NULL,
    cursor text,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    last_successful_sync_at timestamp with time zone,
    last_error_code character varying(64),
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT directory_source_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'DISABLED'::character varying])::text[]))),
    CONSTRAINT directory_source_type_check CHECK (((type)::text = ANY ((ARRAY['WECOM'::character varying, 'FEISHU'::character varying])::text[]))),
    CONSTRAINT directory_source_version_check CHECK (((version > 0) AND (config_key_version > 0)))
);


ALTER TABLE public.directory_source OWNER TO wp6_r7;

--
-- Name: dispatch_decision; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.dispatch_decision (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    ai_request_id uuid NOT NULL,
    dispatch_input jsonb,
    matched_policy_id uuid,
    matched_policy_version character varying(32),
    matched_policy_action character varying(20),
    final_action character varying(20) NOT NULL,
    reason_code character varying(64) NOT NULL,
    reason_detail text,
    switch_target_resource_id uuid,
    counterfactual_cost numeric,
    actual_cost numeric,
    dispatch_saving numeric,
    saving_calculable boolean DEFAULT true NOT NULL,
    not_calculable_reason character varying(64),
    decided_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    CONSTRAINT dispatch_decision_final_action_check CHECK (((final_action)::text = ANY ((ARRAY['ALLOW'::character varying, 'SWITCH'::character varying, 'RATE_LIMIT'::character varying, 'REJECT'::character varying, 'ALLOW_OVERAGE'::character varying])::text[]))),
    CONSTRAINT dispatch_decision_matched_action_check CHECK (((matched_policy_action IS NULL) OR ((matched_policy_action)::text = ANY ((ARRAY['ALLOW'::character varying, 'SWITCH'::character varying, 'RATE_LIMIT'::character varying, 'REJECT'::character varying, 'ALLOW_OVERAGE'::character varying])::text[]))))
);


ALTER TABLE public.dispatch_decision OWNER TO wp6_r7;

--
-- Name: dispatch_policy; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.dispatch_policy (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    status character varying(16) DEFAULT 'DRAFT'::character varying NOT NULL,
    match_unified_model character varying(64),
    match_resource_mode character varying(16),
    match_provider_resource_id uuid,
    match_timezone character varying(32),
    match_days_of_week jsonb,
    match_start_time character varying(8),
    match_end_time character varying(8),
    match_price_multiplier_min numeric,
    match_remaining_quota_ratio_max numeric,
    match_forecast_exhaust_risk boolean,
    match_principal_scope jsonb,
    action character varying(20) NOT NULL,
    switch_equivalent_group jsonb,
    rate_limit_per_minute integer,
    policy_version character varying(32) NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    description text,
    source character varying(128),
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    copied_from_policy_id uuid,
    created_by_admin_id uuid,
    validated_at timestamp with time zone,
    validated_by_admin_id uuid,
    published_at timestamp with time zone,
    published_by_admin_id uuid,
    effective_at timestamp with time zone,
    retired_at timestamp with time zone,
    retired_by_admin_id uuid,
    restore_source_policy_id uuid,
    archived_at timestamp with time zone,
    archived_by_admin_id uuid,
    version integer DEFAULT 1 NOT NULL,
    CONSTRAINT dispatch_policy_action_check CHECK (((action)::text = ANY ((ARRAY['ALLOW'::character varying, 'SWITCH'::character varying, 'RATE_LIMIT'::character varying, 'REJECT'::character varying, 'ALLOW_OVERAGE'::character varying])::text[]))),
    CONSTRAINT dispatch_policy_resource_mode_check CHECK (((match_resource_mode IS NULL) OR ((match_resource_mode)::text = ANY ((ARRAY['API'::character varying, 'CODING_PLAN'::character varying])::text[])))),
    CONSTRAINT dispatch_policy_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'VALIDATED'::character varying, 'PUBLISHED'::character varying, 'RETIRED'::character varying])::text[]))),
    CONSTRAINT retired_policy_archive_check CHECK (((archived_at IS NULL) OR ((status)::text = 'RETIRED'::text)))
);


ALTER TABLE public.dispatch_policy OWNER TO wp6_r7;

--
-- Name: employee_login; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.employee_login (
    principal_id uuid NOT NULL,
    username character varying(128) NOT NULL,
    password_hash text NOT NULL,
    must_change_password boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL
);


ALTER TABLE public.employee_login OWNER TO wp6_r7;

--
-- Name: employee_model_rule_assignment; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.employee_model_rule_assignment (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    rule_version_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    unified_model_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    grant_id uuid NOT NULL,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    disabled_at timestamp with time zone,
    CONSTRAINT employee_model_rule_assignment_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'DISABLED'::character varying])::text[])))
);


ALTER TABLE public.employee_model_rule_assignment OWNER TO wp6_r7;

--
-- Name: employee_model_rule_version; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.employee_model_rule_version (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    rule_id uuid NOT NULL,
    version integer NOT NULL,
    name character varying(128) NOT NULL,
    status character varying(24) DEFAULT 'DRAFT'::character varying NOT NULL,
    employee_scope character varying(16) NOT NULL,
    principal_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    model_scope character varying(16) NOT NULL,
    model_targets jsonb DEFAULT '[]'::jsonb NOT NULL,
    quota_value bigint,
    allow_overage boolean DEFAULT false NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_until timestamp with time zone,
    lock_version integer DEFAULT 1 NOT NULL,
    validation_snapshot jsonb,
    publish_idempotency_key character varying(128),
    published_at timestamp with time zone,
    disabled_at timestamp with time zone,
    created_by_admin_user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    owner_principal_id uuid,
    pool_quotas jsonb DEFAULT '[]'::jsonb,
    publish_request_hash character varying(64),
    CONSTRAINT employee_model_rule_employee_scope_check CHECK (((employee_scope)::text = ANY ((ARRAY['SELECTED'::character varying, 'ALL'::character varying])::text[]))),
    CONSTRAINT employee_model_rule_model_scope_check CHECK (((model_scope)::text = ANY ((ARRAY['SELECTED'::character varying, 'ALL'::character varying])::text[]))),
    CONSTRAINT employee_model_rule_quota_check CHECK (((quota_value IS NULL) OR (quota_value >= 0))),
    CONSTRAINT employee_model_rule_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'VALIDATED'::character varying, 'PUBLISHED'::character varying, 'DISABLED'::character varying])::text[]))),
    CONSTRAINT employee_model_rule_validity_check CHECK (((valid_until IS NULL) OR (valid_until > valid_from)))
);


ALTER TABLE public.employee_model_rule_version OWNER TO wp6_r7;

--
-- Name: employee_project_allocation_policy; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.employee_project_allocation_policy (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    employee_principal_id uuid NOT NULL,
    version integer NOT NULL,
    is_current boolean DEFAULT true NOT NULL,
    input_hash text NOT NULL,
    idempotency_key text,
    reason text NOT NULL,
    published_by uuid NOT NULL,
    published_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT employee_project_allocation_policy_version_check CHECK ((version > 0))
);


ALTER TABLE public.employee_project_allocation_policy OWNER TO wp6_r7;

--
-- Name: employee_project_allocation_rule; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.employee_project_allocation_rule (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    policy_id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    employee_principal_id uuid NOT NULL,
    project_principal_id uuid NOT NULL,
    membership_id uuid NOT NULL,
    membership_revision_id uuid NOT NULL,
    weight_bps integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_until timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT employee_project_allocation_rule_check CHECK (((valid_until IS NULL) OR (valid_until > valid_from))),
    CONSTRAINT employee_project_allocation_rule_weight_bps_check CHECK (((weight_bps >= 0) AND (weight_bps <= 10000)))
);


ALTER TABLE public.employee_project_allocation_rule OWNER TO wp6_r7;

--
-- Name: enterprise; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.enterprise (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(255) NOT NULL,
    status character varying(32) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    timezone character varying(64) DEFAULT 'Asia/Shanghai'::character varying NOT NULL,
    default_currency character varying(3) DEFAULT 'CNY'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    management_contact character varying(128),
    contact_email character varying(320),
    session_minutes integer DEFAULT 480 NOT NULL,
    login_max_failures integer DEFAULT 5 NOT NULL,
    login_lock_minutes integer DEFAULT 5 NOT NULL,
    force_initial_password_change boolean DEFAULT true NOT NULL,
    security_version integer DEFAULT 1 NOT NULL,
    employee_quota_monthly_from timestamp with time zone,
    CONSTRAINT enterprise_currency_format_check CHECK (((default_currency)::text ~ '^[A-Z]{3}$'::text)),
    CONSTRAINT enterprise_login_lock_minutes_check CHECK (((login_lock_minutes >= 5) AND (login_lock_minutes <= 60))),
    CONSTRAINT enterprise_login_max_failures_check CHECK (((login_max_failures >= 3) AND (login_max_failures <= 10))),
    CONSTRAINT enterprise_session_minutes_check CHECK (((session_minutes >= 15) AND (session_minutes <= 1440))),
    CONSTRAINT enterprise_version_positive_check CHECK ((version > 0))
);


ALTER TABLE public.enterprise OWNER TO wp6_r7;

--
-- Name: historical_import_run; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.historical_import_run (
    id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    manifest_hash character varying(64) NOT NULL,
    source_package_hash character varying(64) NOT NULL,
    source_system character varying(32) DEFAULT 'LEGACY_MAC_MINI'::character varying NOT NULL,
    window_start timestamp with time zone NOT NULL,
    window_end timestamp with time zone NOT NULL,
    total_requests integer NOT NULL,
    request_id_digest character varying(64) NOT NULL,
    input_tokens bigint NOT NULL,
    output_tokens bigint NOT NULL,
    cache_tokens bigint NOT NULL,
    reasoning_tokens bigint NOT NULL,
    status character varying(32) NOT NULL,
    pre_cutover_snapshot jsonb,
    post_cutover_snapshot jsonb,
    pre_finance_snapshot jsonb,
    post_finance_snapshot jsonb,
    baseline_summary jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    rolled_back_at timestamp with time zone,
    rollback_summary jsonb,
    CONSTRAINT historical_import_run_status_check CHECK (((status)::text = ANY ((ARRAY['RUNNING'::character varying, 'COMPLETED'::character varying, 'FAILED'::character varying, 'ROLLED_BACK'::character varying])::text[])))
);


ALTER TABLE public.historical_import_run OWNER TO wp6_r7;

--
-- Name: historical_import_run_item; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.historical_import_run_item (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    entity_type character varying(64) NOT NULL,
    entity_id character varying(128) NOT NULL,
    canonical_digest character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.historical_import_run_item OWNER TO wp6_r7;

--
-- Name: kysely_migration; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.kysely_migration (
    name character varying(255) NOT NULL,
    "timestamp" character varying(255) NOT NULL
);


ALTER TABLE public.kysely_migration OWNER TO wp6_r7;

--
-- Name: kysely_migration_lock; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.kysely_migration_lock (
    id character varying(255) NOT NULL,
    is_locked integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.kysely_migration_lock OWNER TO wp6_r7;

--
-- Name: ledger_transaction; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.ledger_transaction (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ai_request_id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    total_input_tokens bigint DEFAULT 0 NOT NULL,
    total_output_tokens bigint DEFAULT 0 NOT NULL,
    total_cache_tokens bigint DEFAULT 0 NOT NULL,
    total_deducted_quota bigint DEFAULT 0 NOT NULL,
    total_api_cost numeric DEFAULT 0,
    usage_quality character varying(64) NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    status character varying(16) DEFAULT 'SETTLED'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    total_reasoning_tokens bigint DEFAULT 0 NOT NULL,
    overage boolean,
    api_cost_status character varying(40) NOT NULL,
    CONSTRAINT ledger_transaction_api_cost_shape_check CHECK (((((api_cost_status)::text = 'PRICED_USAGE'::text) AND (total_api_cost IS NOT NULL)) OR (((api_cost_status)::text = 'CONFIRMED_ZERO_NO_UPSTREAM'::text) AND (total_api_cost = (0)::numeric)) OR (((api_cost_status)::text = 'UNKNOWN_COST'::text) AND ((total_api_cost IS NULL) OR (total_api_cost = (0)::numeric))) OR (((api_cost_status)::text = 'NOT_APPLICABLE'::text) AND ((total_api_cost IS NULL) OR (total_api_cost = (0)::numeric))) OR (((api_cost_status)::text = 'NOT_MIGRATED'::text) AND (total_api_cost IS NULL)))),
    CONSTRAINT ledger_transaction_api_cost_status_check CHECK (((api_cost_status)::text = ANY ((ARRAY['PRICED_USAGE'::character varying, 'CONFIRMED_ZERO_NO_UPSTREAM'::character varying, 'UNKNOWN_COST'::character varying, 'NOT_APPLICABLE'::character varying, 'NOT_MIGRATED'::character varying])::text[])))
);


ALTER TABLE public.ledger_transaction OWNER TO wp6_r7;

--
-- Name: model_route; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.model_route (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    unified_model_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    upstream_model character varying(128) NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    weight integer DEFAULT 1 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    fallback_policy character varying(32),
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    archived_at timestamp with time zone,
    archived_by_admin_id uuid,
    CONSTRAINT model_route_weight_check CHECK ((weight > 0))
);


ALTER TABLE public.model_route OWNER TO wp6_r7;

--
-- Name: notification_delivery; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.notification_delivery (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    availability_event_id uuid,
    notification_endpoint_id uuid NOT NULL,
    recipient_person_id uuid NOT NULL,
    recipient_identity_id uuid,
    delivery_type character varying(16) NOT NULL,
    idempotency_key character varying(255) NOT NULL,
    payload_version character varying(32) DEFAULT 'v1'::character varying NOT NULL,
    status character varying(32) DEFAULT 'PENDING'::character varying NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone,
    sent_at timestamp with time zone,
    provider_message_id character varying(128),
    provider_error_code character varying(64),
    last_error_classification character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT notification_delivery_attempt_nonnegative_check CHECK ((attempt_count >= 0)),
    CONSTRAINT notification_delivery_event_required_check CHECK ((((delivery_type)::text = 'TEST'::text) OR (availability_event_id IS NOT NULL))),
    CONSTRAINT notification_delivery_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'IN_PROGRESS'::character varying, 'SENT'::character varying, 'RETRYABLE_FAILED'::character varying, 'PERMANENT_FAILED'::character varying, 'SKIPPED'::character varying])::text[]))),
    CONSTRAINT notification_delivery_type_check CHECK (((delivery_type)::text = ANY ((ARRAY['TRIGGER'::character varying, 'RECOVERY'::character varying, 'TEST'::character varying])::text[])))
);


ALTER TABLE public.notification_delivery OWNER TO wp6_r7;

--
-- Name: notification_endpoint; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.notification_endpoint (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    provider character varying(32) NOT NULL,
    corp_id character varying(128) NOT NULL,
    agent_id character varying(64) NOT NULL,
    secret_ciphertext text NOT NULL,
    secret_fingerprint character varying(128) NOT NULL,
    status character varying(16) DEFAULT 'DISABLED'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT notification_endpoint_provider_check CHECK (((provider)::text = 'WECOM_APP'::text)),
    CONSTRAINT notification_endpoint_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'DISABLED'::character varying])::text[]))),
    CONSTRAINT notification_endpoint_version_positive_check CHECK ((version > 0))
);


ALTER TABLE public.notification_endpoint OWNER TO wp6_r7;

--
-- Name: operating_bill_event; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.operating_bill_event (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    period_id uuid NOT NULL,
    action character varying(32) NOT NULL,
    version integer,
    reason text,
    actor_admin_id uuid NOT NULL,
    metadata jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT operating_bill_event_action_check CHECK (((action)::text = ANY ((ARRAY['CREATED'::character varying, 'VALUE_CREATED'::character varying, 'VALUE_CONFIRMED'::character varying, 'CLOSED'::character varying, 'REOPENED'::character varying])::text[])))
);


ALTER TABLE public.operating_bill_event OWNER TO wp6_r7;

--
-- Name: operating_bill_opening_balance; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.operating_bill_opening_balance (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    period_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    version integer NOT NULL,
    amount numeric(24,8) NOT NULL,
    currency character varying(8) NOT NULL,
    source character varying(24) DEFAULT 'MANUAL'::character varying NOT NULL,
    reason character varying(1000),
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT operating_bill_opening_balance_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT operating_bill_opening_balance_source_check CHECK (((source)::text = 'MANUAL'::text)),
    CONSTRAINT operating_bill_opening_balance_version_check CHECK ((version > 0))
);


ALTER TABLE public.operating_bill_opening_balance OWNER TO wp6_r7;

--
-- Name: operating_bill_period; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.operating_bill_period (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    period_month date NOT NULL,
    status character varying(16) DEFAULT 'DRAFT'::character varying NOT NULL,
    current_version integer DEFAULT 0 NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT operating_bill_period_status_check CHECK (((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'CLOSED'::character varying])::text[]))),
    CONSTRAINT operating_bill_period_version_check CHECK ((current_version >= 0))
);


ALTER TABLE public.operating_bill_period OWNER TO wp6_r7;

--
-- Name: operating_bill_project_allocation_ref; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.operating_bill_project_allocation_ref (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    bill_version_id uuid NOT NULL,
    run_id uuid NOT NULL,
    frozen jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.operating_bill_project_allocation_ref OWNER TO wp6_r7;

--
-- Name: operating_bill_request_project_assignment; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.operating_bill_request_project_assignment (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    ai_request_id uuid NOT NULL,
    project_principal_id uuid NOT NULL,
    assigned_by uuid NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.operating_bill_request_project_assignment OWNER TO wp6_r7;

--
-- Name: operating_bill_resource_confirmation; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.operating_bill_resource_confirmation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    period_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    status character varying(24) DEFAULT 'PENDING'::character varying NOT NULL,
    fact_fingerprint character(64) NOT NULL,
    operating_snapshot_id uuid,
    request_range_from timestamp with time zone,
    request_range_to timestamp with time zone,
    request_count integer DEFAULT 0 NOT NULL,
    note character varying(1000),
    confirmed_by uuid NOT NULL,
    confirmed_at timestamp with time zone DEFAULT now() NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT operating_bill_resource_confirmation_note_check CHECK ((((status)::text <> ALL ((ARRAY['ANOMALY'::character varying, 'NOT_APPLICABLE'::character varying])::text[])) OR (length(TRIM(BOTH FROM note)) > 0))),
    CONSTRAINT operating_bill_resource_confirmation_status_check CHECK (((status)::text = ANY ((ARRAY['CONFIRMED'::character varying, 'PENDING'::character varying, 'NOT_APPLICABLE'::character varying, 'ANOMALY'::character varying])::text[]))),
    CONSTRAINT operating_bill_resource_confirmation_version_check CHECK ((version > 0))
);


ALTER TABLE public.operating_bill_resource_confirmation OWNER TO wp6_r7;

--
-- Name: operating_bill_value_item; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.operating_bill_value_item (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    period_id uuid NOT NULL,
    title character varying(255) NOT NULL,
    value_type character varying(24) NOT NULL,
    amount numeric(24,8),
    metric_value character varying(255),
    metric_unit character varying(64),
    description text,
    evidence_ref text,
    related_principal_id uuid,
    status character varying(16) DEFAULT 'PENDING'::character varying NOT NULL,
    submitted_by uuid NOT NULL,
    confirmed_by uuid,
    confirmed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT operating_bill_value_payload_check CHECK (((((value_type)::text = 'MONETARY'::text) AND (amount IS NOT NULL) AND (amount >= (0)::numeric)) OR (((value_type)::text = 'NON_MONETARY'::text) AND (metric_value IS NOT NULL) AND (length(TRIM(BOTH FROM metric_value)) > 0)))),
    CONSTRAINT operating_bill_value_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'CONFIRMED'::character varying])::text[]))),
    CONSTRAINT operating_bill_value_type_check CHECK (((value_type)::text = ANY ((ARRAY['MONETARY'::character varying, 'NON_MONETARY'::character varying])::text[])))
);


ALTER TABLE public.operating_bill_value_item OWNER TO wp6_r7;

--
-- Name: operating_bill_version; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.operating_bill_version (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    period_id uuid NOT NULL,
    version integer NOT NULL,
    snapshot jsonb NOT NULL,
    close_note text,
    exceptions jsonb DEFAULT '[]'::jsonb NOT NULL,
    closed_by uuid NOT NULL,
    closed_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.operating_bill_version OWNER TO wp6_r7;

--
-- Name: operation_log; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.operation_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    admin_user_id uuid NOT NULL,
    action character varying(64) NOT NULL,
    target_type character varying(64) NOT NULL,
    target_id uuid,
    change_summary jsonb,
    result character varying(16) NOT NULL,
    failure_reason text,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    actor_source text DEFAULT 'UNKNOWN'::text NOT NULL,
    CONSTRAINT operation_log_actor_source_check CHECK ((actor_source = ANY (ARRAY['ADMIN'::text, 'SYSTEM'::text, 'UNKNOWN'::text])))
);


ALTER TABLE public.operation_log OWNER TO wp6_r7;

--
-- Name: organization_membership; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.organization_membership (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    person_id uuid NOT NULL,
    organization_unit_id uuid NOT NULL,
    is_primary boolean DEFAULT true NOT NULL,
    valid_from timestamp with time zone DEFAULT now() NOT NULL,
    valid_until timestamp with time zone,
    source character varying(16) NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT organization_membership_period_check CHECK (((valid_until IS NULL) OR (valid_until > valid_from))),
    CONSTRAINT organization_membership_source_check CHECK (((source)::text = ANY ((ARRAY['WECOM'::character varying, 'FEISHU'::character varying, 'EXCEL'::character varying])::text[]))),
    CONSTRAINT organization_membership_version_positive_check CHECK ((version > 0))
);


ALTER TABLE public.organization_membership OWNER TO wp6_r7;

--
-- Name: organization_unit; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.organization_unit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    parent_id uuid,
    name character varying(128) NOT NULL,
    external_source_id uuid,
    external_unit_id character varying(255),
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT organization_unit_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'INACTIVE'::character varying])::text[]))),
    CONSTRAINT organization_unit_version_positive_check CHECK ((version > 0))
);


ALTER TABLE public.organization_unit OWNER TO wp6_r7;

--
-- Name: person; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.person (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(128) NOT NULL,
    department_label character varying(128),
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    enterprise_id uuid NOT NULL,
    employee_number character varying(64),
    email character varying(254),
    mobile character varying(32),
    CONSTRAINT person_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'DISABLED'::character varying])::text[]))),
    CONSTRAINT person_version_positive_check CHECK ((version > 0))
);


ALTER TABLE public.person OWNER TO wp6_r7;

--
-- Name: person_external_identity; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.person_external_identity (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    person_id uuid NOT NULL,
    provider character varying(16) NOT NULL,
    provider_user_id character varying(128) NOT NULL,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    verified_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    enterprise_id uuid NOT NULL,
    directory_source_id uuid,
    CONSTRAINT person_external_identity_provider_check CHECK (((provider)::text = ANY ((ARRAY['WECOM'::character varying, 'FEISHU'::character varying])::text[]))),
    CONSTRAINT person_external_identity_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'DISABLED'::character varying])::text[]))),
    CONSTRAINT person_external_identity_version_positive_check CHECK ((version > 0))
);


ALTER TABLE public.person_external_identity OWNER TO wp6_r7;

--
-- Name: principal; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.principal (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    type character varying(16) NOT NULL,
    name character varying(255) NOT NULL,
    department_label character varying(255),
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    archived_at timestamp with time zone,
    person_id uuid,
    owner_person_id uuid,
    version integer DEFAULT 1 NOT NULL,
    CONSTRAINT principal_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'DISABLED'::character varying])::text[]))),
    CONSTRAINT principal_type_check CHECK (((type)::text = ANY ((ARRAY['EMPLOYEE'::character varying, 'PROJECT'::character varying])::text[]))),
    CONSTRAINT principal_version_positive_check CHECK ((version > 0))
);


ALTER TABLE public.principal OWNER TO wp6_r7;

--
-- Name: principal_access_config_state; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.principal_access_config_state (
    enterprise_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    config_version integer DEFAULT 1 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.principal_access_config_state OWNER TO wp6_r7;

--
-- Name: principal_access_idempotency; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.principal_access_idempotency (
    enterprise_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    request_hash character varying(64) NOT NULL,
    response_snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.principal_access_idempotency OWNER TO wp6_r7;

--
-- Name: principal_accounting_assignment; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.principal_accounting_assignment (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    principal_type text NOT NULL,
    department_id uuid,
    owner_principal_id uuid,
    version integer NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_until timestamp with time zone,
    created_by uuid NOT NULL,
    CONSTRAINT principal_accounting_assignment_check CHECK (((valid_until IS NULL) OR (valid_until > valid_from))),
    CONSTRAINT principal_accounting_assignment_check1 CHECK ((((principal_type = 'EMPLOYEE'::text) AND (department_id IS NOT NULL) AND (owner_principal_id IS NULL)) OR ((principal_type = 'PROJECT'::text) AND (department_id IS NULL) AND (owner_principal_id IS NOT NULL)))),
    CONSTRAINT principal_accounting_assignment_principal_type_check CHECK ((principal_type = ANY (ARRAY['EMPLOYEE'::text, 'PROJECT'::text]))),
    CONSTRAINT principal_accounting_assignment_version_check CHECK ((version > 0))
);


ALTER TABLE public.principal_accounting_assignment OWNER TO wp6_r7;

--
-- Name: principal_agent_expectation; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.principal_agent_expectation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    agent_family character varying(32) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.principal_agent_expectation OWNER TO wp6_r7;

--
-- Name: principal_grant; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.principal_grant (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    provider character varying(32) NOT NULL,
    model_alias character varying(64) NOT NULL,
    quota_unit character varying(16) DEFAULT 'TOKEN'::character varying NOT NULL,
    quota_value bigint NOT NULL,
    allow_overage boolean DEFAULT false NOT NULL,
    valid_from timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    valid_until timestamp with time zone,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    authorization_rule_version_id uuid,
    pool_model_alias character varying(64),
    quota_basis text,
    CONSTRAINT principal_grant_quota_basis_check CHECK ((quota_basis = ANY (ARRAY['RAW_TOKEN'::text, 'PLAN_QUOTA'::text]))),
    CONSTRAINT principal_grant_quota_unit_check CHECK (((quota_unit)::text = 'TOKEN'::text)),
    CONSTRAINT principal_grant_quota_value_nonneg CHECK ((quota_value >= 0)),
    CONSTRAINT principal_grant_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'EXPIRED'::character varying, 'DISABLED'::character varying, 'ARCHIVED'::character varying])::text[])))
);


ALTER TABLE public.principal_grant OWNER TO wp6_r7;

--
-- Name: principal_key; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.principal_key (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    key_prefix character varying(32) NOT NULL,
    key_digest text NOT NULL,
    allowed_model_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    ip_allowlist jsonb,
    expires_at timestamp with time zone,
    quota_limit bigint,
    concurrency_limit integer,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    last_used_at timestamp with time zone,
    revoked_at timestamp with time zone,
    used_tokens bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.principal_key OWNER TO wp6_r7;

--
-- Name: principal_model_manual_authorization; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.principal_model_manual_authorization (
    enterprise_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    unified_model_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.principal_model_manual_authorization OWNER TO wp6_r7;

--
-- Name: principal_provider_disabled_model; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.principal_provider_disabled_model (
    enterprise_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    provider character varying(32) NOT NULL,
    unified_model_id uuid NOT NULL,
    disabled_at timestamp with time zone DEFAULT now() NOT NULL,
    disable_rule_version_id uuid
);


ALTER TABLE public.principal_provider_disabled_model OWNER TO wp6_r7;

--
-- Name: principal_quota_period; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.principal_quota_period (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    principal_id uuid NOT NULL,
    provider text NOT NULL,
    period_key text NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    timezone text NOT NULL,
    quota_basis text NOT NULL,
    limit_value bigint NOT NULL,
    allow_overage boolean NOT NULL,
    used_value bigint DEFAULT 0 NOT NULL,
    reserved_value bigint DEFAULT 0 NOT NULL,
    quality text DEFAULT 'COMPLETE'::text NOT NULL,
    open_grant_version integer NOT NULL,
    limit_updated_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT principal_quota_period_check CHECK ((period_end > period_start)),
    CONSTRAINT principal_quota_period_limit_value_check CHECK ((limit_value >= 0)),
    CONSTRAINT principal_quota_period_period_key_check CHECK ((period_key ~ '^[0-9]{4}-[0-9]{2}$'::text)),
    CONSTRAINT principal_quota_period_quality_check CHECK ((quality = ANY (ARRAY['COMPLETE'::text, 'UNKNOWN'::text]))),
    CONSTRAINT principal_quota_period_quota_basis_check CHECK ((quota_basis = ANY (ARRAY['RAW_TOKEN'::text, 'PLAN_QUOTA'::text]))),
    CONSTRAINT principal_quota_period_reserved_value_check CHECK ((reserved_value >= 0)),
    CONSTRAINT principal_quota_period_used_value_check CHECK ((used_value >= 0))
);


ALTER TABLE public.principal_quota_period OWNER TO wp6_r7;

--
-- Name: principal_quota_usage; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.principal_quota_usage (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    request_id uuid NOT NULL,
    attempt_no integer NOT NULL,
    upstream_attempt_id uuid,
    period_id uuid NOT NULL,
    grant_id uuid NOT NULL,
    grant_version integer NOT NULL,
    quota_basis text NOT NULL,
    estimate bigint NOT NULL,
    actual bigint,
    status text DEFAULT 'RESERVED'::text NOT NULL,
    usage_quality text DEFAULT 'UNKNOWN'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    settled_at timestamp with time zone,
    CONSTRAINT principal_quota_usage_actual_check CHECK ((actual >= 0)),
    CONSTRAINT principal_quota_usage_attempt_no_check CHECK ((attempt_no > 0)),
    CONSTRAINT principal_quota_usage_check CHECK ((((status = ANY (ARRAY['SETTLED'::text, 'RELEASED'::text])) AND (actual IS NOT NULL) AND (settled_at IS NOT NULL)) OR ((status = ANY (ARRAY['RESERVED'::text, 'UNKNOWN'::text])) AND (actual IS NULL) AND (settled_at IS NULL)))),
    CONSTRAINT principal_quota_usage_estimate_check CHECK ((estimate >= 0)),
    CONSTRAINT principal_quota_usage_quota_basis_check CHECK ((quota_basis = ANY (ARRAY['RAW_TOKEN'::text, 'PLAN_QUOTA'::text]))),
    CONSTRAINT principal_quota_usage_status_check CHECK ((status = ANY (ARRAY['RESERVED'::text, 'SETTLED'::text, 'RELEASED'::text, 'UNKNOWN'::text])))
);


ALTER TABLE public.principal_quota_usage OWNER TO wp6_r7;

--
-- Name: procurement_review_note; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.procurement_review_note (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    month date NOT NULL,
    note text NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    updated_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT procurement_review_note_length_check CHECK ((char_length(note) <= 4000)),
    CONSTRAINT procurement_review_note_month_check CHECK ((month = (date_trunc('month'::text, (month)::timestamp with time zone))::date)),
    CONSTRAINT procurement_review_note_version_check CHECK ((version > 0))
);


ALTER TABLE public.procurement_review_note OWNER TO wp6_r7;

--
-- Name: procurement_review_note_idempotency; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.procurement_review_note_idempotency (
    enterprise_id uuid NOT NULL,
    month date NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    request_hash character(64) NOT NULL,
    response_snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.procurement_review_note_idempotency OWNER TO wp6_r7;

--
-- Name: project_accounting_profile_version; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.project_accounting_profile_version (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    project_principal_id uuid NOT NULL,
    accounting_started_at timestamp with time zone NOT NULL,
    accounting_ended_at timestamp with time zone,
    version integer NOT NULL,
    is_current boolean DEFAULT true NOT NULL,
    reason text NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_accounting_profile_version_check CHECK (((accounting_ended_at IS NULL) OR (accounting_ended_at > accounting_started_at))),
    CONSTRAINT project_accounting_profile_version_version_check CHECK ((version > 0))
);


ALTER TABLE public.project_accounting_profile_version OWNER TO wp6_r7;

--
-- Name: project_allocation_dirty; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.project_allocation_dirty (
    enterprise_id uuid NOT NULL,
    period_month date NOT NULL,
    generation bigint DEFAULT 0 NOT NULL,
    dirty boolean DEFAULT false NOT NULL,
    last_marked_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_allocation_dirty OWNER TO wp6_r7;

--
-- Name: project_allocation_line; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.project_allocation_line (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    ledger_line_id uuid NOT NULL,
    ai_request_id uuid NOT NULL,
    upstream_attempt_id uuid NOT NULL,
    provider_resource_id uuid,
    unified_model_id uuid,
    request_started_at timestamp with time zone NOT NULL,
    accounted_at timestamp with time zone NOT NULL,
    source_principal_id uuid NOT NULL,
    target_type text NOT NULL,
    target_project_principal_id uuid DEFAULT '00000000-0000-0000-0000-000000000000'::uuid NOT NULL,
    allocation_source text NOT NULL,
    weight_bps integer,
    policy_id uuid,
    membership_id uuid,
    membership_revision_id uuid,
    segment_from timestamp with time zone,
    segment_until timestamp with time zone,
    unallocated_reason text,
    source_input_tokens bigint NOT NULL,
    source_output_tokens bigint NOT NULL,
    source_cache_tokens bigint,
    source_reasoning_tokens bigint,
    share_input_tokens numeric(24,4) NOT NULL,
    share_output_tokens numeric(24,4) NOT NULL,
    share_cache_tokens numeric(24,4),
    share_reasoning_tokens numeric(24,4),
    source_api_cost numeric,
    share_api_cost numeric,
    api_cost_currency text,
    source_package_cost numeric,
    share_package_cost numeric,
    package_cost_currency character varying(3) DEFAULT 'CNY'::character varying NOT NULL,
    usage_quality text NOT NULL,
    resource_mode text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_allocation_line_allocation_source_check CHECK ((allocation_source = ANY (ARRAY['PROJECT_DIRECT'::text, 'MANUAL_ASSIGNMENT'::text, 'MEMBERSHIP_RULE'::text, 'UNALLOCATED'::text]))),
    CONSTRAINT project_allocation_line_check CHECK (((target_type = 'UNALLOCATED'::text) = (allocation_source = 'UNALLOCATED'::text))),
    CONSTRAINT project_allocation_line_check1 CHECK (((allocation_source = 'MEMBERSHIP_RULE'::text) = (weight_bps IS NOT NULL))),
    CONSTRAINT project_allocation_line_check2 CHECK ((((target_type = 'PROJECT'::text) AND (target_project_principal_id <> '00000000-0000-0000-0000-000000000000'::uuid)) OR ((target_type = 'UNALLOCATED'::text) AND (target_project_principal_id = '00000000-0000-0000-0000-000000000000'::uuid)))),
    CONSTRAINT project_allocation_line_package_cost_currency_check CHECK (((package_cost_currency)::text = 'CNY'::text)),
    CONSTRAINT project_allocation_line_target_type_check CHECK ((target_type = ANY (ARRAY['PROJECT'::text, 'UNALLOCATED'::text]))),
    CONSTRAINT project_allocation_line_unallocated_reason_check CHECK (((unallocated_reason IS NULL) OR (unallocated_reason = ANY (ARRAY['HISTORICAL_UNKNOWN'::text, 'NO_MEMBERSHIP'::text, 'NO_EFFECTIVE_RULE'::text, 'WEIGHT_REMAINDER'::text, 'RULE_PENDING_REPAIR'::text]))))
);


ALTER TABLE public.project_allocation_line OWNER TO wp6_r7;

--
-- Name: project_allocation_period; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.project_allocation_period (
    enterprise_id uuid NOT NULL,
    period_month date NOT NULL,
    enabled_by uuid NOT NULL,
    enabled_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_allocation_period OWNER TO wp6_r7;

--
-- Name: project_allocation_resource_residual; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.project_allocation_resource_residual (
    run_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    amount numeric(24,8) NOT NULL,
    currency character varying(3) DEFAULT 'CNY'::character varying NOT NULL,
    note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_allocation_resource_residual_currency_check CHECK (((currency)::text = 'CNY'::text))
);


ALTER TABLE public.project_allocation_resource_residual OWNER TO wp6_r7;

--
-- Name: project_allocation_run; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.project_allocation_run (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    period_month date NOT NULL,
    schema_version text NOT NULL,
    algorithm_version text NOT NULL,
    status text NOT NULL,
    generation bigint NOT NULL,
    input_digest text,
    rule_input_digest text,
    membership_input_digest text,
    manual_attribution_input_digest text,
    source_fact_digest text,
    source_snapshot_as_of timestamp with time zone,
    input_dirty_generation bigint,
    actor_type text NOT NULL,
    actor_admin_id uuid,
    attempt integer DEFAULT 0 NOT NULL,
    lease_owner text,
    lease_expires_at timestamp with time zone,
    last_error text,
    is_current boolean DEFAULT false NOT NULL,
    source_line_count integer,
    employee_count integer,
    project_count integer,
    conservation jsonb,
    completeness jsonb,
    result_hash text,
    started_at timestamp with time zone,
    finished_at timestamp with time zone,
    duration_ms integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_allocation_run_actor_type_check CHECK ((actor_type = ANY (ARRAY['SYSTEM'::text, 'ADMIN'::text]))),
    CONSTRAINT project_allocation_run_check CHECK (((NOT is_current) OR (status = 'SUCCEEDED'::text))),
    CONSTRAINT project_allocation_run_generation_check CHECK ((generation >= 0)),
    CONSTRAINT project_allocation_run_status_check CHECK ((status = ANY (ARRAY['QUEUED'::text, 'RUNNING'::text, 'SUCCEEDED'::text, 'FAILED'::text])))
);


ALTER TABLE public.project_allocation_run OWNER TO wp6_r7;

--
-- Name: project_allocation_scan_watermark; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.project_allocation_scan_watermark (
    enterprise_id uuid NOT NULL,
    ledger_line_watermark timestamp with time zone DEFAULT '1970-01-01 00:00:00+00'::timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.project_allocation_scan_watermark OWNER TO wp6_r7;

--
-- Name: project_department_assignment; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.project_department_assignment (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    project_principal_id uuid NOT NULL,
    organization_unit_id uuid NOT NULL,
    valid_from timestamp with time zone NOT NULL,
    valid_until timestamp with time zone,
    source character varying(40) NOT NULL,
    owner_person_id_at_assignment uuid,
    version integer DEFAULT 1 NOT NULL,
    created_by uuid,
    reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_department_assignment_range_check CHECK (((valid_until IS NULL) OR (valid_until > valid_from))),
    CONSTRAINT project_department_assignment_source_check CHECK (((source)::text = ANY ((ARRAY['EXPLICIT'::character varying, 'OWNER_DEPARTMENT_DEFAULT'::character varying])::text[]))),
    CONSTRAINT project_department_assignment_version_check CHECK ((version > 0))
);


ALTER TABLE public.project_department_assignment OWNER TO wp6_r7;

--
-- Name: project_membership; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.project_membership (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    project_principal_id uuid NOT NULL,
    employee_principal_id uuid NOT NULL,
    stint_index integer NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_membership_stint_index_check CHECK ((stint_index > 0))
);


ALTER TABLE public.project_membership OWNER TO wp6_r7;

--
-- Name: project_membership_revision; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.project_membership_revision (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    membership_id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    project_principal_id uuid NOT NULL,
    employee_principal_id uuid NOT NULL,
    revision integer NOT NULL,
    status text NOT NULL,
    joined_at timestamp with time zone NOT NULL,
    left_at timestamp with time zone,
    idempotency_key text,
    reason text NOT NULL,
    supersedes_id uuid,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_membership_revision_check CHECK (((left_at IS NULL) OR (left_at > joined_at))),
    CONSTRAINT project_membership_revision_check1 CHECK ((((revision = 1) AND (supersedes_id IS NULL)) OR ((revision > 1) AND (supersedes_id IS NOT NULL)))),
    CONSTRAINT project_membership_revision_revision_check CHECK ((revision > 0)),
    CONSTRAINT project_membership_revision_status_check CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'SUPERSEDED'::text, 'VOID'::text])))
);


ALTER TABLE public.project_membership_revision OWNER TO wp6_r7;

--
-- Name: provider; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    code character varying(32) NOT NULL,
    name character varying(128) NOT NULL,
    adapter_type character varying(32) NOT NULL,
    supported_protocols jsonb,
    capability_set jsonb,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    config_schema_version character varying(32),
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    archived_at timestamp with time zone
);


ALTER TABLE public.provider OWNER TO wp6_r7;

--
-- Name: provider_finance_activation_attempt; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_finance_activation_attempt (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    candidate_hash character(64) NOT NULL,
    fact_watermark_hash character(64) NOT NULL,
    decision character varying(16) NOT NULL,
    status character varying(16) DEFAULT 'PREVIEWED'::character varying NOT NULL,
    gap_summary jsonb NOT NULL,
    projection_summary jsonb NOT NULL,
    usage_repair_baseline jsonb NOT NULL,
    created_by_admin_user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    activation_idempotency_key character varying(128),
    activation_result jsonb,
    activated_by_admin_user_id uuid,
    activated_at timestamp with time zone,
    candidate_draft jsonb NOT NULL,
    CONSTRAINT provider_finance_attempt_decision_check CHECK (((decision)::text = ANY ((ARRAY['GO_CANDIDATE'::character varying, 'NO_GO'::character varying])::text[]))),
    CONSTRAINT provider_finance_attempt_draft_shape_check CHECK (((jsonb_typeof(candidate_draft) = 'object'::text) AND (candidate_draft ? 'schema_version'::text))),
    CONSTRAINT provider_finance_attempt_hash_check CHECK (((candidate_hash ~ '^[0-9a-f]{64}$'::text) AND (fact_watermark_hash ~ '^[0-9a-f]{64}$'::text))),
    CONSTRAINT provider_finance_attempt_state_shape_check CHECK (((((status)::text = 'PREVIEWED'::text) AND (activation_idempotency_key IS NULL) AND (activation_result IS NULL) AND (activated_by_admin_user_id IS NULL) AND (activated_at IS NULL)) OR (((status)::text = 'ACTIVATED'::text) AND (activation_idempotency_key IS NOT NULL) AND (activation_result IS NOT NULL) AND (activated_by_admin_user_id IS NOT NULL) AND (activated_at IS NOT NULL)) OR (((status)::text = ANY ((ARRAY['EXPIRED'::character varying, 'REJECTED'::character varying])::text[])) AND (activation_idempotency_key IS NULL) AND (activation_result IS NULL) AND (activated_by_admin_user_id IS NULL) AND (activated_at IS NULL)))),
    CONSTRAINT provider_finance_attempt_status_check CHECK (((status)::text = ANY ((ARRAY['PREVIEWED'::character varying, 'ACTIVATED'::character varying, 'EXPIRED'::character varying, 'REJECTED'::character varying])::text[]))),
    CONSTRAINT provider_finance_attempt_ttl_check CHECK ((expires_at = (created_at + '00:30:00'::interval)))
);


ALTER TABLE public.provider_finance_activation_attempt OWNER TO wp6_r7;

--
-- Name: provider_finance_activation_quiescence; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_finance_activation_quiescence (
    enterprise_id uuid NOT NULL,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    started_by_admin_user_id uuid NOT NULL,
    started_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    released_at timestamp with time zone,
    release_reason character varying(500),
    CONSTRAINT provider_finance_quiescence_state_shape_check CHECK (((((status)::text = 'ACTIVE'::text) AND (released_at IS NULL) AND (release_reason IS NULL)) OR (((status)::text = 'RELEASED'::text) AND (released_at IS NOT NULL) AND (release_reason IS NOT NULL)) OR (((status)::text = 'EXPIRED'::text) AND (released_at IS NULL) AND (release_reason IS NULL)))),
    CONSTRAINT provider_finance_quiescence_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'RELEASED'::character varying, 'EXPIRED'::character varying])::text[]))),
    CONSTRAINT provider_finance_quiescence_window_check CHECK (((expires_at > started_at) AND (expires_at <= (started_at + '01:00:00'::interval))))
);


ALTER TABLE public.provider_finance_activation_quiescence OWNER TO wp6_r7;

--
-- Name: provider_finance_duplicate_candidate; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_finance_duplicate_candidate (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    event_type character varying(48) NOT NULL,
    request_hash character(64) NOT NULL,
    request_payload jsonb NOT NULL,
    confirmation_token_hash character(64) NOT NULL,
    status character varying(16) DEFAULT 'PENDING'::character varying NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_by_admin_user_id uuid NOT NULL,
    consumed_event_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    consumed_at timestamp with time zone,
    CONSTRAINT provider_finance_duplicate_state_check CHECK (((((status)::text = 'PENDING'::text) AND (consumed_event_id IS NULL) AND (consumed_at IS NULL)) OR (((status)::text = 'CONSUMED'::text) AND (consumed_event_id IS NOT NULL) AND (consumed_at IS NOT NULL)) OR (((status)::text = 'EXPIRED'::text) AND (consumed_event_id IS NULL) AND (consumed_at IS NULL)))),
    CONSTRAINT provider_finance_duplicate_status_check CHECK (((status)::text = ANY ((ARRAY['PENDING'::character varying, 'CONSUMED'::character varying, 'EXPIRED'::character varying])::text[])))
);


ALTER TABLE public.provider_finance_duplicate_candidate OWNER TO wp6_r7;

--
-- Name: provider_finance_event; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_finance_event (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    event_type character varying(48) NOT NULL,
    account_amount numeric(24,8) NOT NULL,
    account_currency character varying(3) NOT NULL,
    cash_paid_cny numeric(24,8),
    occurred_at timestamp with time zone NOT NULL,
    external_reference character varying(255),
    reversal_of_event_id uuid,
    correction_of_event_id uuid,
    reconciliation_case_id uuid,
    description character varying(1000),
    evidence_ref text,
    source character varying(32) NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    created_by_admin_user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    legacy_cost_resolution_id uuid,
    CONSTRAINT provider_finance_event_actor_check CHECK ((((source)::text = 'MIGRATION'::text) OR (((source)::text = 'SYSTEM_RENEWAL'::text) AND ((event_type)::text = 'CODING_PLAN_RENEWAL'::text) AND (created_by_admin_user_id IS NULL)) OR (((source)::text <> 'SYSTEM_RENEWAL'::text) AND (created_by_admin_user_id IS NOT NULL)))),
    CONSTRAINT provider_finance_event_cash_precision_check CHECK (((cash_paid_cny IS NULL) OR (cash_paid_cny = trunc(cash_paid_cny, 2)))),
    CONSTRAINT provider_finance_event_currency_check CHECK (((account_currency)::text = ANY ((ARRAY['CNY'::character varying, 'USD'::character varying])::text[]))),
    CONSTRAINT provider_finance_event_shape_check CHECK (((((event_type)::text = 'API_OPENING_BALANCE'::text) AND (account_amount >= (0)::numeric) AND (cash_paid_cny IS NULL) AND (reversal_of_event_id IS NULL) AND (correction_of_event_id IS NULL) AND (reconciliation_case_id IS NULL) AND (legacy_cost_resolution_id IS NULL)) OR (((event_type)::text = 'API_OPENING_BALANCE_CORRECTION'::text) AND (account_amount <> (0)::numeric) AND (cash_paid_cny IS NULL) AND (reversal_of_event_id IS NULL) AND (correction_of_event_id IS NOT NULL) AND (reconciliation_case_id IS NULL) AND (legacy_cost_resolution_id IS NULL)) OR (((event_type)::text = 'API_RECHARGE'::text) AND (account_amount > (0)::numeric) AND (cash_paid_cny > (0)::numeric) AND (reversal_of_event_id IS NULL) AND (correction_of_event_id IS NULL) AND (reconciliation_case_id IS NULL) AND (legacy_cost_resolution_id IS NULL)) OR (((event_type)::text = 'API_BALANCE_RECONCILIATION'::text) AND (account_amount <> (0)::numeric) AND (cash_paid_cny IS NULL) AND (reversal_of_event_id IS NULL) AND (correction_of_event_id IS NULL) AND (reconciliation_case_id IS NOT NULL) AND (legacy_cost_resolution_id IS NULL)) OR (((event_type)::text = 'API_LEGACY_COST_ADJUSTMENT'::text) AND (account_amount < (0)::numeric) AND (cash_paid_cny IS NULL) AND (reversal_of_event_id IS NULL) AND (correction_of_event_id IS NULL) AND (reconciliation_case_id IS NULL) AND (legacy_cost_resolution_id IS NOT NULL)) OR (((event_type)::text = 'API_HISTORICAL_USAGE_COST'::text) AND (account_amount < (0)::numeric) AND (cash_paid_cny IS NULL) AND (reversal_of_event_id IS NULL) AND (correction_of_event_id IS NULL) AND (reconciliation_case_id IS NULL) AND (legacy_cost_resolution_id IS NULL)) OR (((event_type)::text = ANY ((ARRAY['CODING_PLAN_PURCHASE'::character varying, 'CODING_PLAN_RENEWAL'::character varying])::text[])) AND (account_amount > (0)::numeric) AND (cash_paid_cny > (0)::numeric) AND (reversal_of_event_id IS NULL) AND (correction_of_event_id IS NULL) AND (reconciliation_case_id IS NULL) AND (legacy_cost_resolution_id IS NULL)) OR (((event_type)::text = 'REVERSAL'::text) AND (account_amount <> (0)::numeric) AND (reversal_of_event_id IS NOT NULL) AND (correction_of_event_id IS NULL) AND (reconciliation_case_id IS NULL) AND (legacy_cost_resolution_id IS NULL)))),
    CONSTRAINT provider_finance_event_source_check CHECK (((source)::text = ANY ((ARRAY['ADMIN'::character varying, 'MIGRATION'::character varying, 'RECONCILIATION'::character varying, 'SYSTEM_REVERSAL'::character varying, 'SYSTEM_RENEWAL'::character varying])::text[]))),
    CONSTRAINT provider_finance_event_type_check CHECK (((event_type)::text = ANY ((ARRAY['API_OPENING_BALANCE'::character varying, 'API_OPENING_BALANCE_CORRECTION'::character varying, 'API_RECHARGE'::character varying, 'API_BALANCE_RECONCILIATION'::character varying, 'API_LEGACY_COST_ADJUSTMENT'::character varying, 'API_HISTORICAL_USAGE_COST'::character varying, 'CODING_PLAN_PURCHASE'::character varying, 'CODING_PLAN_RENEWAL'::character varying, 'REVERSAL'::character varying])::text[])))
);


ALTER TABLE public.provider_finance_event OWNER TO wp6_r7;

--
-- Name: provider_finance_idempotency; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_finance_idempotency (
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    request_hash character(64) NOT NULL,
    response_snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.provider_finance_idempotency OWNER TO wp6_r7;

--
-- Name: provider_finance_legacy_cost_resolution; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_finance_legacy_cost_resolution (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    account_currency character varying(3) NOT NULL,
    window_start timestamp with time zone NOT NULL,
    window_end_inclusive timestamp with time zone NOT NULL,
    provider_balance_snapshot_id uuid NOT NULL,
    provider_confirmed_balance numeric(24,8) NOT NULL,
    local_balance_before_adjustment numeric(24,8) NOT NULL,
    known_api_cost numeric(24,8) NOT NULL,
    missing_api_cost numeric(24,8) NOT NULL,
    unknown_line_count bigint NOT NULL,
    status character varying(16) DEFAULT 'OPEN'::character varying NOT NULL,
    adjustment_event_id uuid,
    evidence_ref text NOT NULL,
    created_by_admin_user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    resolved_at timestamp with time zone,
    CONSTRAINT provider_finance_legacy_resolution_amount_check CHECK (((provider_confirmed_balance >= (0)::numeric) AND (known_api_cost >= (0)::numeric) AND (missing_api_cost > (0)::numeric) AND (unknown_line_count > 0) AND ((local_balance_before_adjustment - missing_api_cost) = provider_confirmed_balance))),
    CONSTRAINT provider_finance_legacy_resolution_currency_check CHECK (((account_currency)::text = ANY ((ARRAY['CNY'::character varying, 'USD'::character varying])::text[]))),
    CONSTRAINT provider_finance_legacy_resolution_fixed_cutoff_check CHECK ((window_end_inclusive = '2026-09-03 06:56:18.54+00'::timestamp with time zone)),
    CONSTRAINT provider_finance_legacy_resolution_state_check CHECK (((((status)::text = 'OPEN'::text) AND (adjustment_event_id IS NULL) AND (resolved_at IS NULL)) OR (((status)::text = 'RESOLVED'::text) AND (adjustment_event_id IS NOT NULL) AND (resolved_at IS NOT NULL)))),
    CONSTRAINT provider_finance_legacy_resolution_window_check CHECK (((window_start = '2026-08-31 16:00:00+00'::timestamp with time zone) AND (window_end_inclusive >= window_start)))
);


ALTER TABLE public.provider_finance_legacy_cost_resolution OWNER TO wp6_r7;

--
-- Name: provider_finance_reconciliation_case; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_finance_reconciliation_case (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    account_currency character varying(3) NOT NULL,
    local_balance numeric(24,8) NOT NULL,
    provider_confirmed_balance numeric(24,8) NOT NULL,
    difference_amount numeric(24,8) NOT NULL,
    balance_as_of timestamp with time zone NOT NULL,
    fact_watermark jsonb NOT NULL,
    status character varying(16) DEFAULT 'OPEN'::character varying NOT NULL,
    decision character varying(16),
    evidence_ref text NOT NULL,
    opened_by_admin_user_id uuid,
    decided_by_admin_user_id uuid,
    adjustment_event_id uuid,
    decision_note character varying(2000),
    decision_idempotency_key character varying(128),
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    decided_at timestamp with time zone,
    resolved_at timestamp with time zone,
    CONSTRAINT provider_finance_case_currency_check CHECK (((account_currency)::text = ANY ((ARRAY['CNY'::character varying, 'USD'::character varying])::text[]))),
    CONSTRAINT provider_finance_case_difference_check CHECK (((provider_confirmed_balance >= (0)::numeric) AND (difference_amount <> (0)::numeric) AND (difference_amount = (provider_confirmed_balance - local_balance)))),
    CONSTRAINT provider_finance_case_state_check CHECK (((((status)::text = 'OPEN'::text) AND (decision IS NULL) AND (adjustment_event_id IS NULL) AND (decided_at IS NULL) AND (resolved_at IS NULL)) OR (((status)::text = 'REJECTED'::text) AND ((decision)::text = 'REJECTED'::text) AND (adjustment_event_id IS NULL) AND (decided_by_admin_user_id IS NOT NULL) AND (decided_at IS NOT NULL) AND (resolved_at IS NULL)) OR (((status)::text = 'RESOLVED'::text) AND ((decision)::text = 'CONFIRMED'::text) AND (adjustment_event_id IS NOT NULL) AND (decided_by_admin_user_id IS NOT NULL) AND (decided_at IS NOT NULL) AND (resolved_at IS NOT NULL)))),
    CONSTRAINT provider_finance_case_version_check CHECK ((version > 0))
);


ALTER TABLE public.provider_finance_reconciliation_case OWNER TO wp6_r7;

--
-- Name: provider_finance_recorded_cost_policy; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_finance_recorded_cost_policy (
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    authorized_by_admin_user_id uuid NOT NULL,
    reason text NOT NULL,
    evidence_ref text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_finance_recorded_cost_policy_evidence_ref_check CHECK ((length(btrim(evidence_ref)) > 0)),
    CONSTRAINT provider_finance_recorded_cost_policy_reason_check CHECK ((length(btrim(reason)) > 0))
);


ALTER TABLE public.provider_finance_recorded_cost_policy OWNER TO wp6_r7;

--
-- Name: provider_finance_runtime_state; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_finance_runtime_state (
    enterprise_id uuid NOT NULL,
    strict_writes_enabled boolean DEFAULT false NOT NULL,
    activated_at timestamp with time zone,
    activated_by_admin_user_id uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_finance_runtime_state_shape_check CHECK ((((strict_writes_enabled = false) AND (activated_at IS NULL) AND (activated_by_admin_user_id IS NULL)) OR ((strict_writes_enabled = true) AND (activated_at IS NOT NULL) AND (activated_by_admin_user_id IS NOT NULL))))
);


ALTER TABLE public.provider_finance_runtime_state OWNER TO wp6_r7;

--
-- Name: provider_finance_usage_cost_disposition; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_finance_usage_cost_disposition (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    ledger_line_id uuid NOT NULL,
    ai_request_id uuid NOT NULL,
    decision character varying(40) NOT NULL,
    original_ledger_fact jsonb NOT NULL,
    server_cost_evidence jsonb NOT NULL,
    reason text NOT NULL,
    evidence_ref text NOT NULL,
    decided_by_admin_user_id uuid NOT NULL,
    idempotency_key character varying(200) NOT NULL,
    request_hash character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_finance_usage_cost_disposit_original_ledger_fact_check CHECK ((jsonb_typeof(original_ledger_fact) = 'object'::text)),
    CONSTRAINT provider_finance_usage_cost_disposit_server_cost_evidence_check CHECK ((jsonb_typeof(server_cost_evidence) = 'object'::text)),
    CONSTRAINT provider_finance_usage_cost_disposition_decision_check CHECK (((decision)::text = 'EXCLUDE_NO_SERVER_COST'::text)),
    CONSTRAINT provider_finance_usage_cost_disposition_evidence_ref_check CHECK ((length(btrim(evidence_ref)) > 0)),
    CONSTRAINT provider_finance_usage_cost_disposition_idempotency_key_check CHECK ((length(btrim((idempotency_key)::text)) > 0)),
    CONSTRAINT provider_finance_usage_cost_disposition_reason_check CHECK ((length(btrim(reason)) > 0)),
    CONSTRAINT provider_finance_usage_cost_disposition_request_hash_check CHECK (((request_hash)::text ~ '^[a-f0-9]{64}$'::text))
);


ALTER TABLE public.provider_finance_usage_cost_disposition OWNER TO wp6_r7;

--
-- Name: provider_model_discovery; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_model_discovery (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    source character varying(32) NOT NULL,
    source_version character varying(128) NOT NULL,
    status character varying(24) NOT NULL,
    discovered_at timestamp with time zone NOT NULL,
    failure_code character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    parser_version character varying(64),
    source_url text,
    source_etag character varying(255),
    source_last_modified character varying(255),
    source_content_hash character varying(80),
    source_checked_at timestamp with time zone,
    stale boolean DEFAULT false NOT NULL,
    CONSTRAINT provider_model_discovery_status_check CHECK (((status)::text = ANY ((ARRAY['SUCCEEDED'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public.provider_model_discovery OWNER TO wp6_r7;

--
-- Name: provider_model_discovery_item; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_model_discovery_item (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    discovery_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    upstream_model character varying(128) NOT NULL,
    display_name character varying(128) NOT NULL,
    model_type character varying(32) NOT NULL,
    capabilities jsonb DEFAULT '[]'::jsonb NOT NULL,
    source character varying(32) NOT NULL,
    compatible boolean NOT NULL,
    unavailable_reason character varying(255),
    availability_status character varying(24) DEFAULT 'AVAILABLE'::character varying NOT NULL,
    first_discovered_at timestamp with time zone NOT NULL,
    last_discovered_at timestamp with time zone NOT NULL,
    last_validated_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    facts jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.provider_model_discovery_item OWNER TO wp6_r7;

--
-- Name: provider_model_onboarding; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_model_onboarding (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    request_fingerprint character varying(64) NOT NULL,
    provider_resource_id uuid NOT NULL,
    result jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.provider_model_onboarding OWNER TO wp6_r7;

--
-- Name: provider_model_probe_item; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_model_probe_item (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    probe_run_id uuid NOT NULL,
    upstream_model text NOT NULL,
    validation_status text NOT NULL,
    http_status integer,
    error_code text,
    error_category text,
    retryable boolean DEFAULT false NOT NULL,
    diagnostic_hash text,
    checked_at timestamp with time zone,
    CONSTRAINT provider_model_probe_item_validation_status_check CHECK ((validation_status = ANY (ARRAY['NOT_RUN'::text, 'READY'::text, 'AUTH_FAILED'::text, 'PLAN_NOT_ENTITLED'::text, 'REQUEST_REJECTED'::text, 'RATE_LIMITED'::text, 'UPSTREAM_UNAVAILABLE'::text, 'NETWORK_FAILED'::text])))
);


ALTER TABLE public.provider_model_probe_item OWNER TO wp6_r7;

--
-- Name: provider_model_probe_run; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_model_probe_run (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_id uuid,
    provider_resource_id uuid,
    provider_code text NOT NULL,
    resource_mode text NOT NULL,
    credential_fingerprint text NOT NULL,
    endpoint_scope text NOT NULL,
    endpoint_host text NOT NULL,
    discovery_source text,
    discovery_source_hash text,
    parser_version text,
    status text NOT NULL,
    idempotency_key text NOT NULL,
    request_hash text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    CONSTRAINT provider_model_probe_run_endpoint_scope_check CHECK ((endpoint_scope = ANY (ARRAY['MODE_SCOPED_CONFIG'::text, 'ENV'::text, 'LEGACY_BASE_URL'::text, 'MODE_DEFAULT'::text, 'ENDPOINT_SCOPE_AMBIGUOUS'::text]))),
    CONSTRAINT provider_model_probe_run_resource_mode_check CHECK ((resource_mode = ANY (ARRAY['API'::text, 'CODING_PLAN'::text]))),
    CONSTRAINT provider_model_probe_run_status_check CHECK ((status = ANY (ARRAY['COMPLETED'::text, 'FAILED'::text])))
);


ALTER TABLE public.provider_model_probe_run OWNER TO wp6_r7;

--
-- Name: provider_model_validation; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_model_validation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    unified_model_id uuid NOT NULL,
    upstream_model character varying(128) NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    request_fingerprint character varying(64) NOT NULL,
    status character varying(24) NOT NULL,
    result jsonb DEFAULT '{}'::jsonb NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    credential_fingerprint character varying(128),
    caller_config_hash character varying(64),
    CONSTRAINT provider_model_validation_status_check CHECK (((status)::text = ANY ((ARRAY['IN_PROGRESS'::character varying, 'SUCCEEDED'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public.provider_model_validation OWNER TO wp6_r7;

--
-- Name: provider_quota_window; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_quota_window (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    window_type character varying(16) NOT NULL,
    is_current boolean DEFAULT true NOT NULL,
    limit_value numeric(30,8),
    used_value numeric(30,8),
    remaining_value numeric(30,8),
    unit character varying(16),
    ratio numeric(8,6),
    reset_at timestamp with time zone,
    provider_data_at timestamp with time zone,
    collected_at timestamp with time zone NOT NULL,
    source character varying(16) NOT NULL,
    adapter_version character varying(32) NOT NULL,
    sync_status character varying(16) NOT NULL,
    sync_error_code character varying(64),
    last_success_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_quota_window_nonnegative_check CHECK ((((limit_value IS NULL) OR (limit_value >= (0)::numeric)) AND ((used_value IS NULL) OR (used_value >= (0)::numeric)) AND ((remaining_value IS NULL) OR (remaining_value >= (0)::numeric)) AND ((ratio IS NULL) OR ((ratio >= (0)::numeric) AND (ratio <= (1)::numeric))))),
    CONSTRAINT provider_quota_window_source_check CHECK (((source)::text = ANY ((ARRAY['PROVIDER_SYNC'::character varying, 'MANUAL_SYNC'::character varying])::text[]))),
    CONSTRAINT provider_quota_window_sync_status_check CHECK (((sync_status)::text = ANY ((ARRAY['SUCCESS'::character varying, 'STALE'::character varying, 'FAILED'::character varying, 'UNSUPPORTED'::character varying])::text[]))),
    CONSTRAINT provider_quota_window_unit_check CHECK (((unit IS NULL) OR ((unit)::text = ANY ((ARRAY['PERCENT'::character varying, 'POINT'::character varying])::text[])))),
    CONSTRAINT provider_quota_window_window_type_check CHECK (((window_type)::text = ANY ((ARRAY['FIVE_HOUR'::character varying, 'WEEKLY'::character varying])::text[])))
);


ALTER TABLE public.provider_quota_window OWNER TO wp6_r7;

--
-- Name: provider_resource; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_resource (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    name character varying(255) NOT NULL,
    mode character varying(16) NOT NULL,
    credential_type character varying(32) NOT NULL,
    credential_ciphertext text,
    credential_fingerprint character varying(64),
    credential_version integer,
    upstream_models jsonb,
    concurrency_limit integer,
    status character varying(32) DEFAULT 'ACTIVE'::character varying NOT NULL,
    api_fallback_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    resource_pool_id character varying(64),
    credential_expires_at timestamp with time zone,
    credential_refresh_status character varying(16) DEFAULT 'OK'::character varying NOT NULL,
    last_refresh_at timestamp with time zone,
    refresh_error_classification character varying(48),
    consecutive_failures integer DEFAULT 0 NOT NULL,
    cooldown_until timestamp with time zone,
    last_probe_at timestamp with time zone,
    version integer DEFAULT 1 NOT NULL,
    monthly_budget_amount numeric(24,8),
    monthly_budget_currency character varying(8),
    subscription_auto_renew_enabled boolean DEFAULT true NOT NULL,
    auth_failure_id uuid,
    auth_failure_model text,
    auth_failure_config_hash text,
    archived_at timestamp with time zone,
    quota_state_revision bigint DEFAULT 0 NOT NULL,
    quota_block_state jsonb,
    CONSTRAINT provider_resource_credential_type_check CHECK (((credential_type)::text = ANY ((ARRAY['API_KEY'::character varying, 'OAUTH'::character varying, 'SUBSCRIPTION_SESSION'::character varying])::text[]))),
    CONSTRAINT provider_resource_failures_nonneg CHECK ((consecutive_failures >= 0)),
    CONSTRAINT provider_resource_mode_check CHECK (((mode)::text = ANY ((ARRAY['API'::character varying, 'CODING_PLAN'::character varying])::text[]))),
    CONSTRAINT provider_resource_monthly_budget_check CHECK ((((monthly_budget_amount IS NULL) AND (monthly_budget_currency IS NULL)) OR ((monthly_budget_amount > (0)::numeric) AND (monthly_budget_currency IS NOT NULL)))),
    CONSTRAINT provider_resource_refresh_status_check CHECK (((credential_refresh_status)::text = ANY ((ARRAY['OK'::character varying, 'REFRESHING'::character varying, 'FAILED'::character varying])::text[]))),
    CONSTRAINT provider_resource_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'DEGRADED'::character varying, 'EXHAUSTED'::character varying, 'EXPIRED'::character varying, 'CREDENTIAL_INVALID'::character varying, 'RATE_LIMITED'::character varying, 'UNAVAILABLE'::character varying])::text[])))
);


ALTER TABLE public.provider_resource OWNER TO wp6_r7;

--
-- Name: provider_resource_balance_refresh; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_resource_balance_refresh (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    actor_admin_id uuid NOT NULL,
    idempotency_key uuid NOT NULL,
    status character varying(16) NOT NULL,
    error_code character varying(80),
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_resource_balance_refresh_status_check CHECK (((status)::text = ANY ((ARRAY['RUNNING'::character varying, 'SUCCEEDED'::character varying, 'FAILED'::character varying])::text[])))
);


ALTER TABLE public.provider_resource_balance_refresh OWNER TO wp6_r7;

--
-- Name: provider_resource_finance_state; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_resource_finance_state (
    provider_resource_id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    state character varying(16) DEFAULT 'PENDING'::character varying NOT NULL,
    required_currencies jsonb DEFAULT '[]'::jsonb NOT NULL,
    ready_at timestamp with time zone,
    ready_by_admin_user_id uuid,
    version integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_resource_finance_state_currencies_check CHECK ((jsonb_typeof(required_currencies) = 'array'::text)),
    CONSTRAINT provider_resource_finance_state_shape_check CHECK (((((state)::text = 'PENDING'::text) AND (ready_at IS NULL) AND (ready_by_admin_user_id IS NULL)) OR (((state)::text = 'READY'::text) AND (ready_at IS NOT NULL) AND (ready_by_admin_user_id IS NOT NULL)))),
    CONSTRAINT provider_resource_finance_state_state_check CHECK (((state)::text = ANY ((ARRAY['PENDING'::character varying, 'READY'::character varying])::text[]))),
    CONSTRAINT provider_resource_finance_state_version_check CHECK ((version > 0))
);


ALTER TABLE public.provider_resource_finance_state OWNER TO wp6_r7;

--
-- Name: provider_resource_monthly_budget; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_resource_monthly_budget (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    month date NOT NULL,
    version integer NOT NULL,
    status character varying(16) NOT NULL,
    amount numeric(24,8),
    currency character varying(8),
    is_current boolean DEFAULT true NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    request_hash character(64) NOT NULL,
    response_snapshot jsonb NOT NULL,
    CONSTRAINT provider_resource_monthly_budget_month_check CHECK ((month = (date_trunc('month'::text, (month)::timestamp with time zone))::date)),
    CONSTRAINT provider_resource_monthly_budget_status_check CHECK (((status)::text = ANY ((ARRAY['ACTIVE'::character varying, 'CLEARED'::character varying])::text[]))),
    CONSTRAINT provider_resource_monthly_budget_value_check CHECK (((((status)::text = 'ACTIVE'::text) AND (amount > (0)::numeric) AND (currency IS NOT NULL)) OR (((status)::text = 'CLEARED'::text) AND (amount IS NULL) AND (currency IS NULL)))),
    CONSTRAINT provider_resource_monthly_budget_version_check CHECK ((version > 0))
);


ALTER TABLE public.provider_resource_monthly_budget OWNER TO wp6_r7;

--
-- Name: provider_resource_operating_snapshot; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_resource_operating_snapshot (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    version integer NOT NULL,
    source character varying(32) NOT NULL,
    collected_at timestamp with time zone NOT NULL,
    currency character varying(8),
    recharge_amount numeric(24,8),
    current_balance numeric(24,8),
    cumulative_cost numeric(24,8),
    current_period_cost numeric(24,8),
    cost_period_start timestamp with time zone,
    cost_period_end timestamp with time zone,
    balance_updated_at timestamp with time zone,
    package_name character varying(255),
    package_cost numeric(24,8),
    total_quota numeric(30,8),
    quota_unit character varying(32),
    used_quota numeric(30,8),
    remaining_quota numeric(30,8),
    effective_from timestamp with time zone,
    effective_until timestamp with time zone,
    reset_cycle character varying(32),
    next_reset_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    reset_anchor_at timestamp with time zone,
    reset_timezone character varying(64),
    usage_calculation character varying(32) DEFAULT 'MANUAL_SNAPSHOT'::character varying NOT NULL,
    granted_balance numeric(24,8),
    topped_up_balance numeric(24,8),
    provider_balance_available boolean,
    balance_source character varying(24),
    cost_source character varying(24),
    subscription_period_id uuid,
    CONSTRAINT provider_resource_operating_snapshot_balance_parts_check CHECK ((((granted_balance IS NULL) OR (granted_balance >= (0)::numeric)) AND ((topped_up_balance IS NULL) OR (topped_up_balance >= (0)::numeric)))),
    CONSTRAINT provider_resource_operating_snapshot_cost_range_check CHECK (((cost_period_start IS NULL) OR (cost_period_end IS NULL) OR (cost_period_end > cost_period_start))),
    CONSTRAINT provider_resource_operating_snapshot_effective_range_check CHECK (((effective_from IS NULL) OR (effective_until IS NULL) OR (effective_until > effective_from))),
    CONSTRAINT provider_resource_operating_snapshot_fact_source_check CHECK ((((balance_source IS NULL) OR ((balance_source)::text = ANY ((ARRAY['ADMIN'::character varying, 'PROVIDER_API'::character varying, 'BILL_RECONCILIATION'::character varying])::text[]))) AND ((cost_source IS NULL) OR ((cost_source)::text = ANY ((ARRAY['ADMIN'::character varying, 'LOCAL_LEDGER'::character varying, 'BILL_RECONCILIATION'::character varying, 'NOT_SUPPORTED'::character varying])::text[]))))),
    CONSTRAINT provider_resource_operating_snapshot_nonnegative_check CHECK ((((recharge_amount IS NULL) OR (recharge_amount >= (0)::numeric)) AND ((current_balance IS NULL) OR (current_balance >= (0)::numeric)) AND ((cumulative_cost IS NULL) OR (cumulative_cost >= (0)::numeric)) AND ((current_period_cost IS NULL) OR (current_period_cost >= (0)::numeric)) AND ((package_cost IS NULL) OR (package_cost >= (0)::numeric)) AND ((total_quota IS NULL) OR (total_quota >= (0)::numeric)) AND ((used_quota IS NULL) OR (used_quota >= (0)::numeric)) AND ((remaining_quota IS NULL) OR (remaining_quota >= (0)::numeric)))),
    CONSTRAINT provider_resource_operating_snapshot_quota_consistency_check CHECK (((total_quota IS NULL) OR (used_quota IS NULL) OR (remaining_quota IS NULL) OR (total_quota = (used_quota + remaining_quota)))),
    CONSTRAINT provider_resource_operating_snapshot_source_check CHECK (((source)::text = ANY ((ARRAY['ADMIN'::character varying, 'PROVIDER_SYNC'::character varying, 'BILL_RECONCILIATION'::character varying])::text[]))),
    CONSTRAINT provider_resource_operating_snapshot_usage_calculation_check CHECK (((usage_calculation)::text = ANY ((ARRAY['MANUAL_SNAPSHOT'::character varying, 'SYSTEM_LEDGER'::character varying])::text[])))
);


ALTER TABLE public.provider_resource_operating_snapshot OWNER TO wp6_r7;

--
-- Name: provider_resource_operating_sync_attempt; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_resource_operating_sync_attempt (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    sync_day date NOT NULL,
    balance_status character varying(24) NOT NULL,
    cost_status character varying(24) NOT NULL,
    snapshot_id uuid,
    provider_data_at timestamp with time zone,
    started_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone NOT NULL,
    next_sync_at timestamp with time zone NOT NULL,
    error_code character varying(80),
    failure_reason character varying(500),
    adapter_version character varying(64) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_resource_operating_sync_attempt_balance_status_check CHECK (((balance_status)::text = ANY ((ARRAY['SUCCESS'::character varying, 'FAILED'::character varying, 'NOT_SUPPORTED'::character varying])::text[]))),
    CONSTRAINT provider_resource_operating_sync_attempt_cost_status_check CHECK (((cost_status)::text = ANY ((ARRAY['SUCCESS'::character varying, 'FAILED'::character varying, 'NOT_SUPPORTED'::character varying])::text[]))),
    CONSTRAINT provider_resource_operating_sync_attempt_time_check CHECK (((completed_at >= started_at) AND (next_sync_at > started_at)))
);


ALTER TABLE public.provider_resource_operating_sync_attempt OWNER TO wp6_r7;

--
-- Name: provider_subscription_period; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.provider_subscription_period (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    finance_event_id uuid,
    product_name character varying(255) NOT NULL,
    period_start timestamp with time zone NOT NULL,
    period_end_exclusive timestamp with time zone NOT NULL,
    source character varying(32) NOT NULL,
    migration_source_record_id uuid,
    reversed_by_event_id uuid,
    created_by_admin_user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_subscription_period_range_check CHECK (((period_end_exclusive > period_start) AND (((period_start AT TIME ZONE 'Asia/Shanghai'::text))::time without time zone = '00:00:00'::time without time zone) AND (((period_end_exclusive AT TIME ZONE 'Asia/Shanghai'::text))::time without time zone = '00:00:00'::time without time zone))),
    CONSTRAINT provider_subscription_period_source_check CHECK (((source)::text = ANY ((ARRAY['PURCHASE'::character varying, 'RENEWAL'::character varying, 'MIGRATED_CARRYOVER'::character varying, 'MIGRATED_PURCHASE'::character varying])::text[]))),
    CONSTRAINT provider_subscription_period_source_shape_check CHECK (((((source)::text = ANY ((ARRAY['PURCHASE'::character varying, 'RENEWAL'::character varying])::text[])) AND (finance_event_id IS NOT NULL) AND (migration_source_record_id IS NULL)) OR (((source)::text = 'MIGRATED_CARRYOVER'::text) AND (finance_event_id IS NULL) AND ((migration_source_record_id IS NOT NULL) OR (created_by_admin_user_id IS NOT NULL))) OR (((source)::text = 'MIGRATED_PURCHASE'::text) AND (migration_source_record_id IS NOT NULL))))
);


ALTER TABLE public.provider_subscription_period OWNER TO wp6_r7;

--
-- Name: quota_counter; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.quota_counter (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    grant_id uuid NOT NULL,
    used_value bigint DEFAULT 0 NOT NULL,
    overage_value bigint DEFAULT 0 NOT NULL,
    period_anchor timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    next_reset_at timestamp with time zone,
    reset_marker character varying(64),
    updated_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL
);


ALTER TABLE public.quota_counter OWNER TO wp6_r7;

--
-- Name: reconciliation_discrepancy; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.reconciliation_discrepancy (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    reconciliation_run_id uuid NOT NULL,
    discrepancy_type character varying(32) NOT NULL,
    ai_request_id uuid,
    usage_event_id uuid,
    ledger_line_id uuid,
    ledger_transaction_id uuid,
    detail jsonb,
    severity character varying(16) DEFAULT 'HIGH'::character varying NOT NULL,
    status character varying(16) DEFAULT 'OPEN'::character varying NOT NULL,
    resolution_note text,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    resolved_at timestamp with time zone,
    CONSTRAINT reconciliation_discrepancy_severity_check CHECK (((severity)::text = ANY ((ARRAY['HIGH'::character varying, 'MEDIUM'::character varying, 'LOW'::character varying])::text[]))),
    CONSTRAINT reconciliation_discrepancy_status_check CHECK (((status)::text = ANY ((ARRAY['OPEN'::character varying, 'INVESTIGATING'::character varying, 'RESOLVED'::character varying, 'IGNORED'::character varying])::text[]))),
    CONSTRAINT reconciliation_discrepancy_type_check CHECK (((discrepancy_type)::text = ANY ((ARRAY['DUPLICATE_USAGE'::character varying, 'MISSING_LEDGER_LINE'::character varying, 'MISSING_USAGE'::character varying, 'ORPHAN_LEDGER_LINE'::character varying, 'SETTLEMENT_MISMATCH'::character varying, 'RESOURCE_UNAVAILABLE'::character varying, 'USAGE_SPIKE'::character varying, 'QUOTA_ANOMALY'::character varying, 'CREDENTIAL_INVALID'::character varying])::text[])))
);


ALTER TABLE public.reconciliation_discrepancy OWNER TO wp6_r7;

--
-- Name: reconciliation_run; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.reconciliation_run (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    range_from timestamp with time zone NOT NULL,
    range_to timestamp with time zone NOT NULL,
    requests_scanned integer DEFAULT 0 NOT NULL,
    usage_events_scanned integer DEFAULT 0 NOT NULL,
    ledger_lines_scanned integer DEFAULT 0 NOT NULL,
    transactions_scanned integer DEFAULT 0 NOT NULL,
    duplicate_count integer DEFAULT 0 NOT NULL,
    missing_count integer DEFAULT 0 NOT NULL,
    mismatch_count integer DEFAULT 0 NOT NULL,
    total_discrepancies integer DEFAULT 0 NOT NULL,
    result character varying(16) NOT NULL,
    duplicate_rate numeric,
    missing_rate numeric,
    summary jsonb,
    algorithm_version character varying(32) NOT NULL,
    started_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    finished_at timestamp with time zone,
    CONSTRAINT reconciliation_run_result_check CHECK (((result)::text = ANY ((ARRAY['PASS'::character varying, 'FAIL'::character varying, 'REVIEW'::character varying])::text[])))
);


ALTER TABLE public.reconciliation_run OWNER TO wp6_r7;

--
-- Name: report_delivery_action; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.report_delivery_action (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    bundle_id uuid NOT NULL,
    message_id uuid NOT NULL,
    action text NOT NULL,
    reason text NOT NULL,
    previous_status text NOT NULL,
    previous_version integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.report_delivery_action OWNER TO wp6_r7;

--
-- Name: report_delivery_attempt; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.report_delivery_attempt (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    message_id uuid NOT NULL,
    version integer NOT NULL,
    started_at timestamp with time zone NOT NULL,
    finished_at timestamp with time zone,
    status text NOT NULL,
    provider_message_id text,
    error_code text,
    classification text,
    token_requests integer DEFAULT 0 NOT NULL,
    media_requests integer DEFAULT 0 NOT NULL,
    preparation_requests integer DEFAULT 0 NOT NULL,
    message_requests integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.report_delivery_attempt OWNER TO wp6_r7;

--
-- Name: report_delivery_bundle; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.report_delivery_bundle (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    report_type text NOT NULL,
    period_key text NOT NULL,
    recipient_ref text NOT NULL,
    target_user_id text,
    endpoint_id uuid,
    period_start timestamp with time zone NOT NULL,
    period_end timestamp with time zone NOT NULL,
    window_start timestamp with time zone NOT NULL,
    window_end timestamp with time zone NOT NULL,
    snapshot jsonb NOT NULL,
    content_hash text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT report_delivery_bundle_check CHECK ((period_end > period_start)),
    CONSTRAINT report_delivery_bundle_check1 CHECK ((window_end > window_start)),
    CONSTRAINT report_delivery_bundle_report_type_check CHECK ((report_type = ANY (ARRAY['DAILY'::text, 'COMPANY_WEEKLY'::text, 'PERSONAL_WEEKLY'::text, 'COMPANY_MONTHLY'::text, 'PERSONAL_MONTHLY'::text, 'TOP1'::text, 'OVER50'::text])))
);


ALTER TABLE public.report_delivery_bundle OWNER TO wp6_r7;

--
-- Name: report_delivery_claim; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.report_delivery_claim (
    enterprise_id uuid NOT NULL,
    scope text NOT NULL,
    bundle_id uuid NOT NULL
);


ALTER TABLE public.report_delivery_claim OWNER TO wp6_r7;

--
-- Name: report_delivery_message; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.report_delivery_message (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    bundle_id uuid NOT NULL,
    kind text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    version integer DEFAULT 0 NOT NULL,
    lease_until timestamp with time zone,
    next_attempt_at timestamp with time zone,
    last_attempt_at timestamp with time zone,
    provider_message_id text,
    error_code text,
    classification text,
    CONSTRAINT report_delivery_message_attempt_count_check CHECK ((attempt_count >= 0)),
    CONSTRAINT report_delivery_message_kind_check CHECK ((kind = ANY (ARRAY['IMAGE'::text, 'TEXT'::text]))),
    CONSTRAINT report_delivery_message_status_check CHECK ((status = ANY (ARRAY['PENDING'::text, 'SENDING'::text, 'SENT'::text, 'RETRYABLE_FAILED'::text, 'PERMANENT_FAILED'::text, 'UNKNOWN'::text, 'SKIPPED'::text])))
);


ALTER TABLE public.report_delivery_message OWNER TO wp6_r7;

--
-- Name: report_delivery_schedule; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.report_delivery_schedule (
    enterprise_id uuid NOT NULL,
    report_type text NOT NULL,
    schedule_date text NOT NULL,
    status text NOT NULL,
    classification text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.report_delivery_schedule OWNER TO wp6_r7;

--
-- Name: request_attribution_snapshot; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.request_attribution_snapshot (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    ai_request_id uuid NOT NULL,
    source_principal_id uuid NOT NULL,
    employee_person_id uuid,
    project_principal_id uuid,
    organization_unit_id uuid,
    cost_category character varying(24) NOT NULL,
    attribution_source character varying(40) NOT NULL,
    request_occurred_at timestamp with time zone NOT NULL,
    version integer NOT NULL,
    supersedes_id uuid,
    snapshot_origin character varying(32) DEFAULT 'RUNTIME'::character varying NOT NULL,
    reason_code character varying(64),
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT request_attribution_snapshot_category_check CHECK (((cost_category)::text = ANY ((ARRAY['EMPLOYEE_DIRECT'::character varying, 'PROJECT'::character varying, 'UNASSIGNED'::character varying])::text[]))),
    CONSTRAINT request_attribution_snapshot_origin_check CHECK (((snapshot_origin)::text = ANY ((ARRAY['MIGRATION_BACKFILL'::character varying, 'RUNTIME'::character varying, 'CORRECTION'::character varying])::text[]))),
    CONSTRAINT request_attribution_snapshot_source_check CHECK (((attribution_source)::text = ANY ((ARRAY['PROJECT_DIRECT'::character varying, 'EMPLOYEE_PROJECT'::character varying, 'EMPLOYEE_MEMBERSHIP'::character varying, 'UNASSIGNED'::character varying])::text[]))),
    CONSTRAINT request_attribution_snapshot_v1_chain_check CHECK ((((version = 1) AND (supersedes_id IS NULL)) OR ((version > 1) AND (supersedes_id IS NOT NULL)))),
    CONSTRAINT request_attribution_snapshot_version_check CHECK ((version > 0))
);


ALTER TABLE public.request_attribution_snapshot OWNER TO wp6_r7;

--
-- Name: resource_purchase_idempotency; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.resource_purchase_idempotency (
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    request_hash character(64) NOT NULL,
    response_snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.resource_purchase_idempotency OWNER TO wp6_r7;

--
-- Name: resource_purchase_record; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.resource_purchase_record (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    purchase_type character varying(32) NOT NULL,
    description character varying(255),
    amount numeric(24,8) NOT NULL,
    currency character varying(8) NOT NULL,
    purchased_at timestamp with time zone NOT NULL,
    service_period_start date,
    service_period_end date,
    source character varying(24) DEFAULT 'ADMIN'::character varying NOT NULL,
    evidence_ref text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT resource_purchase_record_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT resource_purchase_record_period_check CHECK ((((service_period_start IS NULL) AND (service_period_end IS NULL)) OR ((service_period_start IS NOT NULL) AND (service_period_end IS NOT NULL) AND (service_period_end >= service_period_start)))),
    CONSTRAINT resource_purchase_record_source_check CHECK (((source)::text = ANY ((ARRAY['ADMIN'::character varying, 'IMPORT'::character varying, 'PROVIDER_SYNC'::character varying])::text[]))),
    CONSTRAINT resource_purchase_record_type_check CHECK (((purchase_type)::text = ANY ((ARRAY['API_RECHARGE'::character varying, 'PACKAGE_PURCHASE'::character varying])::text[])))
);


ALTER TABLE public.resource_purchase_record OWNER TO wp6_r7;

--
-- Name: resource_status_event; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.resource_status_event (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    from_status character varying(32),
    to_status character varying(32) NOT NULL,
    reason character varying(64) NOT NULL,
    error_classification character varying(48),
    consecutive_failures integer,
    cooldown_until timestamp with time zone,
    actor character varying(32) DEFAULT 'system'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    time_reliable boolean DEFAULT true NOT NULL
);


ALTER TABLE public.resource_status_event OWNER TO wp6_r7;

--
-- Name: route_candidate; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.route_candidate (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ai_request_id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    upstream_model character varying(128) NOT NULL,
    priority integer NOT NULL,
    weight integer NOT NULL,
    selected boolean DEFAULT false NOT NULL,
    score_factors jsonb,
    total_score numeric,
    reason_code character varying(64),
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL
);


ALTER TABLE public.route_candidate OWNER TO wp6_r7;

--
-- Name: runtime_notification_recipient; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.runtime_notification_recipient (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    category text NOT NULL,
    person_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT runtime_notification_recipient_category_check CHECK ((category = ANY (ARRAY['SYSTEM_FAILURE'::text, 'UPSTREAM_RESOURCE'::text, 'FINANCE_SECURITY'::text, 'PERSONNEL_ACCOUNT'::text])))
);


ALTER TABLE public.runtime_notification_recipient OWNER TO wp6_r7;

--
-- Name: supply_forecast; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.supply_forecast (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    rate_1h numeric,
    rate_24h numeric,
    rate_7d numeric,
    forecast_exhaust_at timestamp with time zone,
    next_recover_at timestamp with time zone,
    coverage_hours numeric,
    remaining_quota numeric,
    confidence character varying(16) NOT NULL,
    data_points integer DEFAULT 0 NOT NULL,
    not_calculable_reason character varying(64),
    algorithm_version character varying(32) NOT NULL,
    snapshot_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    consumption_unit character varying(24),
    forecast_key character varying(160),
    CONSTRAINT supply_forecast_confidence_check CHECK (((confidence)::text = ANY ((ARRAY['HIGH'::character varying, 'MEDIUM'::character varying, 'LOW'::character varying, 'NOT_CALCULABLE'::character varying])::text[]))),
    CONSTRAINT supply_forecast_consumption_unit_check CHECK (((consumption_unit IS NULL) OR ((consumption_unit)::text = ANY ((ARRAY['CURRENCY_PER_HOUR'::character varying, 'QUOTA_PER_HOUR'::character varying])::text[]))))
);


ALTER TABLE public.supply_forecast OWNER TO wp6_r7;

--
-- Name: unified_model; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.unified_model (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    alias character varying(64) NOT NULL,
    display_name character varying(128) NOT NULL,
    required_capabilities jsonb,
    status character varying(16) DEFAULT 'ACTIVE'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    updated_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    archived_at timestamp with time zone,
    archived_by_admin_id uuid
);


ALTER TABLE public.unified_model OWNER TO wp6_r7;

--
-- Name: upstream_attempt; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.upstream_attempt (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ai_request_id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    attempt_no integer NOT NULL,
    provider_resource_id uuid NOT NULL,
    upstream_model character varying(128) NOT NULL,
    started_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    first_byte_at timestamp with time zone,
    finished_at timestamp with time zone,
    http_status integer,
    error_classification character varying(64),
    error_code character varying(64),
    response_committed boolean DEFAULT false NOT NULL,
    switch_reason character varying(64),
    failure_layer character varying(32),
    upstream_error_evidence jsonb,
    request_shape_summary jsonb,
    dispatch_check jsonb
);


ALTER TABLE public.upstream_attempt OWNER TO wp6_r7;

--
-- Name: usage_aggregate_bucket_state; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.usage_aggregate_bucket_state (
    enterprise_id uuid NOT NULL,
    bucket_granularity character varying(8) NOT NULL,
    bucket_start timestamp with time zone NOT NULL,
    timezone character varying(64) NOT NULL,
    fact_watermark timestamp with time zone,
    max_fact_at timestamp with time zone,
    generated_at timestamp with time zone NOT NULL,
    CONSTRAINT usage_aggregate_state_granularity_check CHECK (((bucket_granularity)::text = ANY ((ARRAY['HOUR'::character varying, 'DAY'::character varying])::text[])))
);


ALTER TABLE public.usage_aggregate_bucket_state OWNER TO wp6_r7;

--
-- Name: usage_aggregate_dirty_bucket; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.usage_aggregate_dirty_bucket (
    enterprise_id uuid NOT NULL,
    bucket_granularity character varying(8) NOT NULL,
    bucket_start timestamp with time zone NOT NULL,
    timezone character varying(64) NOT NULL,
    marked_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT usage_aggregate_dirty_granularity_check CHECK (((bucket_granularity)::text = ANY ((ARRAY['HOUR'::character varying, 'DAY'::character varying])::text[])))
);


ALTER TABLE public.usage_aggregate_dirty_bucket OWNER TO wp6_r7;

--
-- Name: usage_bucket_aggregate; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.usage_bucket_aggregate (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    enterprise_id uuid NOT NULL,
    bucket_granularity character varying(8) NOT NULL,
    bucket_start timestamp with time zone NOT NULL,
    timezone character varying(64) NOT NULL,
    source_principal_id uuid NOT NULL,
    project_principal_id uuid,
    provider_resource_id uuid,
    unified_model_id uuid,
    request_count bigint DEFAULT 0 NOT NULL,
    input_tokens bigint DEFAULT 0 NOT NULL,
    output_tokens bigint DEFAULT 0 NOT NULL,
    cache_tokens bigint DEFAULT 0 NOT NULL,
    reasoning_tokens bigint DEFAULT 0 NOT NULL,
    deducted_quota bigint DEFAULT 0 NOT NULL,
    api_cost numeric(30,8) DEFAULT 0,
    fact_watermark timestamp with time zone,
    max_fact_at timestamp with time zone,
    dirty boolean DEFAULT false NOT NULL,
    generated_at timestamp with time zone DEFAULT now() NOT NULL,
    provider_reported_count bigint DEFAULT 0 NOT NULL,
    estimated_count bigint DEFAULT 0 NOT NULL,
    account_aggregated_count bigint DEFAULT 0 NOT NULL,
    mixed_count bigint DEFAULT 0 NOT NULL,
    unknown_count bigint DEFAULT 0 NOT NULL,
    api_cost_status character varying(40) NOT NULL,
    CONSTRAINT usage_bucket_aggregate_api_cost_shape_check CHECK (((((api_cost_status)::text = 'PRICED_USAGE'::text) AND (api_cost IS NOT NULL) AND (api_cost >= (0)::numeric)) OR (((api_cost_status)::text = 'CONFIRMED_ZERO_NO_UPSTREAM'::text) AND (api_cost = (0)::numeric)) OR (((api_cost_status)::text = 'UNKNOWN_COST'::text) AND (api_cost IS NULL)) OR (((api_cost_status)::text = 'NOT_APPLICABLE'::text) AND ((api_cost IS NULL) OR (api_cost = (0)::numeric))) OR (((api_cost_status)::text = 'NOT_MIGRATED'::text) AND (api_cost IS NULL)))),
    CONSTRAINT usage_bucket_aggregate_api_cost_status_check CHECK (((api_cost_status)::text = ANY ((ARRAY['PRICED_USAGE'::character varying, 'CONFIRMED_ZERO_NO_UPSTREAM'::character varying, 'UNKNOWN_COST'::character varying, 'NOT_APPLICABLE'::character varying, 'NOT_MIGRATED'::character varying])::text[]))),
    CONSTRAINT usage_bucket_granularity_check CHECK (((bucket_granularity)::text = ANY ((ARRAY['HOUR'::character varying, 'DAY'::character varying])::text[]))),
    CONSTRAINT usage_bucket_values_nonnegative_check CHECK (((request_count >= 0) AND (input_tokens >= 0) AND (output_tokens >= 0) AND (cache_tokens >= 0) AND (reasoning_tokens >= 0) AND (deducted_quota >= 0) AND (api_cost >= (0)::numeric)))
);


ALTER TABLE public.usage_bucket_aggregate OWNER TO wp6_r7;

--
-- Name: usage_event; Type: TABLE; Schema: public; Owner: wp6_r7
--

CREATE TABLE public.usage_event (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    ai_request_id uuid NOT NULL,
    enterprise_id uuid NOT NULL,
    upstream_attempt_id uuid NOT NULL,
    provider_resource_id uuid NOT NULL,
    input_tokens bigint DEFAULT 0 NOT NULL,
    output_tokens bigint DEFAULT 0 NOT NULL,
    cache_tokens bigint DEFAULT 0 NOT NULL,
    usage_quality character varying(32) NOT NULL,
    upstream_usage_id character varying(128),
    dedup_key character varying(128) NOT NULL,
    created_at timestamp with time zone DEFAULT '2026-11-05 07:21:11.611924+00'::timestamp with time zone NOT NULL,
    reasoning_tokens bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public.usage_event OWNER TO wp6_r7;

--
-- Name: _w01_baseline_probe id; Type: DEFAULT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public._w01_baseline_probe ALTER COLUMN id SET DEFAULT nextval('public._w01_baseline_probe_id_seq'::regclass);


--
-- Data for Name: _migration_0045_pool046_backup; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public._migration_0045_pool046_backup (row_type, row_id, original_alias, original_days_of_week, original_time_windows, original_updated_at) FROM stdin;
\.


--
-- Data for Name: _w01_baseline_probe; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public._w01_baseline_probe (id, note, created_at) FROM stdin;
\.


--
-- Data for Name: admin_role; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.admin_role (enterprise_id, name, permissions, version, updated_at) FROM stdin;
\.


--
-- Data for Name: admin_session; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.admin_session (id, admin_user_id, token_hash, expires_at, revoked_at, created_at, user_agent, ip_address, last_seen_at) FROM stdin;
\.


--
-- Data for Name: admin_user; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.admin_user (id, enterprise_id, username, password_hash, status, created_at, updated_at, display_name, must_change_password, version, archived_at, role_code) FROM stdin;
e7e103dc-d14a-4a79-8e1b-aaa2183aef67	f01d5faa-0d54-449c-8d68-500c4395f923	r7-restore-admin	test	ACTIVE	2026-11-05 07:21:11.611924+00	2026-11-05 07:21:11.611924+00	R7 恢复演练管理员	f	1	\N	SUPER_ADMIN
\.


--
-- Data for Name: ai_request; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.ai_request (id, enterprise_id, principal_id, principal_key_id, idempotency_key, protocol, unified_model, stream, status, client_id, started_at, finished_at, error_classification, error_code, client_request_id, request_fingerprint, agent_family, agent_version, agent_identity_source, agent_identity_confidence, client_identity_rule_version, unified_model_id, import_source, import_run_id) FROM stdin;
b5308447-cf8f-4b96-8d53-29e29335ddef	f01d5faa-0d54-449c-8d68-500c4395f923	7051f4ae-d781-457d-af35-69b803258d8e	4060d874-2c51-4c64-bb28-b82bb06c2dfc	\N	chat	deepseek-chat	f	SUCCEEDED	\N	2026-11-04 08:00:00+00	2026-11-04 08:00:01+00	\N	\N	\N	\N	UNKNOWN	\N	NONE	UNKNOWN	legacy	\N	\N	\N
\.


--
-- Data for Name: alert_event; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.alert_event (id, enterprise_id, alert_key, domain, signal, severity, title, detail, resource_id, principal_id, ai_request_id, status, first_seen_at, last_seen_at, resolved_at, resolution_note, resolved_by, source_cleared_at, availability_event_id, recovery_evidence) FROM stdin;
\.


--
-- Data for Name: availability_event; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.availability_event (id, event_number, availability_rule_id, rule_version_id, rule_version, provider_id, provider_resource_id, unified_model_id, upstream_model, unified_signal, upstream_code, sanitized_summary, availability_decision, trigger_ai_request_id, trigger_principal_id, recovery_method, dedup_key, status, started_at, recover_at, recovered_at, recovery_reason, affected_request_count, affected_person_count, notification_summary, created_at, updated_at, quota_block_incident_id) FROM stdin;
\.


--
-- Data for Name: availability_rule; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.availability_rule (id, name, rule_type, description, status, version, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: availability_rule_version; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.availability_rule_version (id, availability_rule_id, rule_version, status, provider_id, provider_resource_id, unified_model_id, upstream_model, unified_signal, action, recovery_method, fallback_duration_seconds, schedule_timezone, schedule_days_of_week, schedule_start_time, schedule_end_time, priority, effective_from, effective_to, version, created_by, published_by, published_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: billing_rule; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.billing_rule (id, enterprise_id, provider_resource_id, upstream_model, rule_type, rule_version, effective_from, effective_to, timezone, days_of_week, start_time, end_time, multiplier, cache_hit_price, cache_miss_price, output_price, currency, priority, enabled, source, created_at, updated_at, version, time_windows, archived_at, archived_by_admin_id, pricing_mode, source_status) FROM stdin;
\.


--
-- Data for Name: concurrency_lease; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.concurrency_lease (id, enterprise_id, provider_resource_id, ai_request_id, acquired_at, expires_at, released_at) FROM stdin;
\.


--
-- Data for Name: credential_chat_probe; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.credential_chat_probe (id, enterprise_id, provider_resource_id, actor_admin_id, idempotency_key, failure_id, upstream_model, credential_version, credential_digest, config_hash, status, http_status, error_code, evidence, usage, started_at, finished_at, expires_at, retry_at) FROM stdin;
\.


--
-- Data for Name: department_budget; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.department_budget (id, enterprise_id, organization_unit_id, month, currency, amount, warning_threshold, version, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: department_budget_idempotency; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.department_budget_idempotency (enterprise_id, organization_unit_id, month, idempotency_key, request_hash, response_snapshot, created_at) FROM stdin;
\.


--
-- Data for Name: deployment_log; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.deployment_log (id, enterprise_id, deployment_id, started_at, finished_at, status, from_version, to_version, git_commit, artifact_sha256, migration_from, migration_to, release_id, actor, summary, pool_refs, backup_ref, rollback_target, health_summary, smoke_summary, evidence_refs, failure_classification, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: deployment_log_event; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.deployment_log_event (id, enterprise_id, deployment_log_id, event_key, event_type, occurred_at, actor, note, payload, created_at) FROM stdin;
\.


--
-- Data for Name: directory_import_item; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.directory_import_item (id, enterprise_id, run_id, row_number, external_member_id, employee_number, normalized_name, normalized_department_path, normalized_email, normalized_mobile, external_department_id, existing_principal_id, status, reason_code, person_id, principal_id, organization_unit_id, attempt, lease_until, processed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: directory_import_run; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.directory_import_run (id, enterprise_id, directory_source_id, mode, job_type, template_version, connector_version, source_snapshot_id, content_sha256, request_hash, idempotency_key, created_by_admin_user_id, status, total_count, matched_count, created_count, updated_count, conflict_count, skipped_count, failed_count, failure_reason_code, source_data_at, attempt, next_attempt_at, lease_until, started_at, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: directory_source; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.directory_source (id, enterprise_id, type, config_ciphertext, config_fingerprint, config_key_version, connector_version, cursor, status, last_successful_sync_at, last_error_code, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dispatch_decision; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.dispatch_decision (id, enterprise_id, ai_request_id, dispatch_input, matched_policy_id, matched_policy_version, matched_policy_action, final_action, reason_code, reason_detail, switch_target_resource_id, counterfactual_cost, actual_cost, dispatch_saving, saving_calculable, not_calculable_reason, decided_at) FROM stdin;
\.


--
-- Data for Name: dispatch_policy; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.dispatch_policy (id, enterprise_id, status, match_unified_model, match_resource_mode, match_provider_resource_id, match_timezone, match_days_of_week, match_start_time, match_end_time, match_price_multiplier_min, match_remaining_quota_ratio_max, match_forecast_exhaust_risk, match_principal_scope, action, switch_equivalent_group, rate_limit_per_minute, policy_version, priority, description, source, created_at, updated_at, copied_from_policy_id, created_by_admin_id, validated_at, validated_by_admin_id, published_at, published_by_admin_id, effective_at, retired_at, retired_by_admin_id, restore_source_policy_id, archived_at, archived_by_admin_id, version) FROM stdin;
\.


--
-- Data for Name: employee_login; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.employee_login (principal_id, username, password_hash, must_change_password, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: employee_model_rule_assignment; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.employee_model_rule_assignment (id, enterprise_id, rule_version_id, principal_id, unified_model_id, provider_resource_id, grant_id, status, created_at, disabled_at) FROM stdin;
\.


--
-- Data for Name: employee_model_rule_version; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.employee_model_rule_version (id, enterprise_id, rule_id, version, name, status, employee_scope, principal_ids, model_scope, model_targets, quota_value, allow_overage, valid_from, valid_until, lock_version, validation_snapshot, publish_idempotency_key, published_at, disabled_at, created_by_admin_user_id, created_at, updated_at, owner_principal_id, pool_quotas, publish_request_hash) FROM stdin;
\.


--
-- Data for Name: employee_project_allocation_policy; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.employee_project_allocation_policy (id, enterprise_id, employee_principal_id, version, is_current, input_hash, idempotency_key, reason, published_by, published_at) FROM stdin;
\.


--
-- Data for Name: employee_project_allocation_rule; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.employee_project_allocation_rule (id, policy_id, enterprise_id, employee_principal_id, project_principal_id, membership_id, membership_revision_id, weight_bps, valid_from, valid_until, created_at) FROM stdin;
\.


--
-- Data for Name: enterprise; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.enterprise (id, name, status, created_at, updated_at, timezone, default_currency, version, management_contact, contact_email, session_minutes, login_max_failures, login_lock_minutes, force_initial_password_change, security_version, employee_quota_monthly_from) FROM stdin;
f01d5faa-0d54-449c-8d68-500c4395f923	R7 备份恢复演练企业	ACTIVE	2026-11-05 07:21:11.611924+00	2026-11-05 07:21:11.611924+00	Asia/Shanghai	CNY	1	\N	\N	480	5	5	t	1	\N
\.


--
-- Data for Name: historical_import_run; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.historical_import_run (id, enterprise_id, manifest_hash, source_package_hash, source_system, window_start, window_end, total_requests, request_id_digest, input_tokens, output_tokens, cache_tokens, reasoning_tokens, status, pre_cutover_snapshot, post_cutover_snapshot, pre_finance_snapshot, post_finance_snapshot, baseline_summary, created_at, started_at, completed_at, rolled_back_at, rollback_summary) FROM stdin;
\.


--
-- Data for Name: historical_import_run_item; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.historical_import_run_item (id, run_id, enterprise_id, entity_type, entity_id, canonical_digest, created_at) FROM stdin;
\.


--
-- Data for Name: kysely_migration; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.kysely_migration (name, "timestamp") FROM stdin;
0000_baseline_probe	2026-11-05T07:21:11.738Z
0001_enterprise_admin_session	2026-11-05T07:21:11.760Z
0002_principal	2026-11-05T07:21:11.772Z
0003_principal_key	2026-11-05T07:21:11.779Z
0004_principal_grant	2026-11-05T07:21:11.795Z
0005_provider_resource_route	2026-11-05T07:21:11.814Z
0006_operation_log	2026-11-05T07:21:11.822Z
0007_gateway_request	2026-11-05T07:21:11.835Z
0008_attempt_usage	2026-11-05T07:21:11.845Z
0009_ledger	2026-11-05T07:21:11.858Z
0010_resource_credential_lifecycle	2026-11-05T07:21:11.869Z
0011_billing_rule	2026-11-05T07:21:11.878Z
0012_concurrency_lease	2026-11-05T07:21:11.887Z
0013_supply_forecast	2026-11-05T07:21:11.897Z
0014_dispatch_policy	2026-11-05T07:21:11.921Z
0015_reconciliation	2026-11-05T07:21:11.941Z
0016_alert_disposition_type	2026-11-05T07:21:11.944Z
0017_alert_event_and_version	2026-11-05T07:21:11.965Z
0018_billing_rule_version	2026-11-05T07:21:11.967Z
0019_alert_source_clear	2026-11-05T07:21:11.969Z
0020_p0_billing_snapshot_and_reasoning_usage	2026-11-05T07:21:11.971Z
0021_billing_rule_multi_windows	2026-11-05T07:21:11.976Z
0022_principal_key_minimum_model_permissions	2026-11-05T07:21:11.979Z
0023_principal_key_single_active	2026-11-05T07:21:11.983Z
0024_gateway_request_idempotency	2026-11-05T07:21:11.990Z
0025_principal_archive	2026-11-05T07:21:11.993Z
0026_provider_resource_operating_snapshot	2026-11-05T07:21:12.002Z
0027_usage_ledger_filters	2026-11-05T07:21:12.023Z
0028_enterprise_reference_guards	2026-11-05T07:21:12.053Z
0029_provider_quota_auto_calculation	2026-11-05T07:21:12.062Z
0030_runtime_assurance_foundation	2026-11-05T07:21:12.145Z
0031_gateway_stream_resilience	2026-11-05T07:21:12.148Z
0032_admin_lifecycle	2026-11-05T07:21:12.153Z
0033_operating_bill	2026-11-05T07:21:12.188Z
0034_supply_forecast_production	2026-11-05T07:21:12.195Z
0035_deployment_log	2026-11-05T07:21:12.212Z
0036_provider_model_discovery	2026-11-05T07:21:12.235Z
0037_client_identity	2026-11-05T07:21:12.248Z
0038_employee_model_authorization_rule	2026-11-05T07:21:12.280Z
0039_principal_provider_pool	2026-11-05T07:21:12.304Z
0040_employee_model_rule_pool_quotas	2026-11-05T07:21:12.306Z
0041_provider_quota_window	2026-11-05T07:21:12.314Z
0042_alias_ql_format	2026-11-05T07:21:12.330Z
0043_single_owner_rule_history	2026-11-05T07:21:12.338Z
0044_operating_bill_model_identity	2026-11-05T07:21:12.361Z
0045_zhipu_weekday_window_alias	2026-11-05T07:21:12.369Z
0046_directory_import_foundation	2026-11-05T07:21:12.476Z
0047_usage_bucket_aggregate	2026-11-05T07:21:12.522Z
0048_department_cost_budget_and_purchase	2026-11-05T07:21:12.596Z
0049_resource_utilization_and_procurement_review	2026-11-05T07:21:12.609Z
0050_group2_policy_lifecycle	2026-11-05T07:21:12.625Z
0051_pool20_operating_sync_and_closing_confirmation	2026-11-05T07:21:12.652Z
0052_dispatch_restore_and_resource_utilization	2026-11-05T07:21:12.659Z
0053_operating_bill_opening_balance	2026-11-05T07:21:12.671Z
0054_usage_aggregate_settlement_time	2026-11-05T07:21:12.687Z
0055_upstream_error_evidence	2026-11-05T07:21:12.690Z
0056_resource_monthly_budget	2026-11-05T07:21:12.702Z
0057_model_discovery_v12	2026-11-05T07:21:12.712Z
0058_principal_grant_archive	2026-11-05T07:21:12.715Z
0059_provider_finance_ledger	2026-11-05T07:21:12.777Z
0060_provider_finance_legacy_cost_resolution	2026-11-05T07:21:12.803Z
0061_provider_finance_audit_hardening	2026-11-05T07:21:12.820Z
0062_resource_fact_reconciliation	2026-11-05T07:21:12.827Z
0063_operating_snapshot_subscription_period	2026-11-05T07:21:12.837Z
0064_quota_pricing_and_policy_archive	2026-11-05T07:21:12.846Z
0065_principal_accounting_assignment	2026-11-05T07:21:12.858Z
0066_subscription_auto_renewal	2026-11-05T07:21:12.862Z
0067_admin_cleanup	2026-11-05T07:21:12.865Z
0068_alert_resource_context	2026-11-05T07:21:12.867Z
0069_auth_error_evidence	2026-11-05T07:21:12.869Z
0070_alert_recovery_evidence	2026-11-05T07:21:12.870Z
0071_enterprise_contact_details	2026-11-05T07:21:12.873Z
0072_admin_roles_security	2026-11-05T07:21:12.887Z
0073_credential_chat_probe	2026-11-05T07:21:12.897Z
0074_runtime_notification_recipients	2026-11-05T07:21:12.901Z
0075_provider_resource_archive	2026-11-05T07:21:12.909Z
0076_provider_model_probe	2026-11-05T07:21:12.922Z
0077_provider_model_probe_run_identity	2026-11-05T07:21:12.926Z
0078_provider_model_probe_enum_checks	2026-11-05T07:21:12.931Z
0079_project_allocation_relations	2026-11-05T07:21:13.023Z
0080_project_allocation_compute	2026-11-05T07:21:13.119Z
0081_provider_finance_activation	2026-11-05T07:21:13.162Z
0082_provider_finance_candidate_draft	2026-11-05T07:21:13.168Z
0083_provider_finance_resource_opening_trigger	2026-11-05T07:21:13.170Z
0084_provider_finance_historical_usage_cost	2026-11-05T07:21:13.175Z
0085_historical_usage_not_migrated	2026-11-05T07:21:13.203Z
0086_provider_finance_usage_cost_disposition	2026-11-05T07:21:13.217Z
0087_coding_plan_quota_block_state	2026-11-05T07:21:13.226Z
0088_principal_key_limit_enforcement	2026-11-05T07:21:13.230Z
0089_model_validation_binding	2026-11-05T07:21:13.234Z
0090_report_delivery	2026-11-05T07:21:13.269Z
0091_recorded_cost_accounting_policy	2026-11-05T07:21:13.274Z
0092_employee_monthly_quota	2026-11-05T07:21:13.288Z
0093_billing_rule_source_status	2026-11-05T07:21:13.291Z
0094_retire_api_finance_pending_admission	2026-11-05T07:21:13.294Z
0095_official_balance_sync_decouple	2026-11-05T07:21:13.297Z
0096_official_balance_refresh_request	2026-11-05T07:21:13.306Z
\.


--
-- Data for Name: kysely_migration_lock; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.kysely_migration_lock (id, is_locked) FROM stdin;
migration_lock	0
\.


--
-- Data for Name: ledger_line; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.ledger_line (id, ai_request_id, enterprise_id, usage_event_id, upstream_attempt_id, provider_resource_id, principal_id, resource_mode, raw_input_tokens, raw_output_tokens, raw_cache_tokens, deducted_quota, api_cost, usage_quality, created_at, billing_rule_id, rule_version, multiplier, raw_reasoning_tokens, billing_rule_snapshot, api_cost_currency, api_cost_status, subscription_period_id, settled_at, legacy_cost_resolution_id) FROM stdin;
2adee79b-34ff-4cd2-af10-82fdb05bc344	b5308447-cf8f-4b96-8d53-29e29335ddef	f01d5faa-0d54-449c-8d68-500c4395f923	99a4fdca-e1e3-4971-a2a8-11ab6dcdc8fa	0af9c89e-9d9d-4e59-9d0b-a452029c8be5	f6b15893-9207-4899-8950-b48e04e90c60	7051f4ae-d781-457d-af35-69b803258d8e	API	1000	200	0	\N	0.00104000	PROVIDER_REPORTED	2026-11-04 08:00:01+00	\N	\N	\N	0	{"sourceStatus": "VERIFIED"}	CNY	PRICED_USAGE	\N	2026-11-04 08:00:01+00	\N
\.


--
-- Data for Name: ledger_transaction; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.ledger_transaction (id, ai_request_id, enterprise_id, principal_id, total_input_tokens, total_output_tokens, total_cache_tokens, total_deducted_quota, total_api_cost, usage_quality, attempt_count, status, created_at, total_reasoning_tokens, overage, api_cost_status) FROM stdin;
29148f89-740d-4a99-894f-46ca84c0bd5c	b5308447-cf8f-4b96-8d53-29e29335ddef	f01d5faa-0d54-449c-8d68-500c4395f923	7051f4ae-d781-457d-af35-69b803258d8e	1000	200	0	0	0.00104000	PROVIDER_REPORTED	1	SETTLED	2026-11-04 08:00:01+00	0	f	PRICED_USAGE
\.


--
-- Data for Name: model_route; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.model_route (id, enterprise_id, unified_model_id, provider_resource_id, upstream_model, priority, weight, enabled, fallback_policy, created_at, updated_at, version, archived_at, archived_by_admin_id) FROM stdin;
\.


--
-- Data for Name: notification_delivery; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.notification_delivery (id, availability_event_id, notification_endpoint_id, recipient_person_id, recipient_identity_id, delivery_type, idempotency_key, payload_version, status, attempt_count, next_attempt_at, sent_at, provider_message_id, provider_error_code, last_error_classification, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: notification_endpoint; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.notification_endpoint (id, provider, corp_id, agent_id, secret_ciphertext, secret_fingerprint, status, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: operating_bill_event; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.operating_bill_event (id, enterprise_id, period_id, action, version, reason, actor_admin_id, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: operating_bill_opening_balance; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.operating_bill_opening_balance (id, enterprise_id, period_id, provider_resource_id, version, amount, currency, source, reason, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: operating_bill_period; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.operating_bill_period (id, enterprise_id, period_month, status, current_version, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: operating_bill_project_allocation_ref; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.operating_bill_project_allocation_ref (id, enterprise_id, bill_version_id, run_id, frozen, created_at) FROM stdin;
\.


--
-- Data for Name: operating_bill_request_project_assignment; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.operating_bill_request_project_assignment (id, enterprise_id, ai_request_id, project_principal_id, assigned_by, reason, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: operating_bill_resource_confirmation; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.operating_bill_resource_confirmation (id, enterprise_id, period_id, provider_resource_id, status, fact_fingerprint, operating_snapshot_id, request_range_from, request_range_to, request_count, note, confirmed_by, confirmed_at, version, created_at) FROM stdin;
\.


--
-- Data for Name: operating_bill_value_item; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.operating_bill_value_item (id, enterprise_id, period_id, title, value_type, amount, metric_value, metric_unit, description, evidence_ref, related_principal_id, status, submitted_by, confirmed_by, confirmed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: operating_bill_version; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.operating_bill_version (id, enterprise_id, period_id, version, snapshot, close_note, exceptions, closed_by, closed_at) FROM stdin;
\.


--
-- Data for Name: operation_log; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.operation_log (id, enterprise_id, admin_user_id, action, target_type, target_id, change_summary, result, failure_reason, created_at, actor_source) FROM stdin;
\.


--
-- Data for Name: organization_membership; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.organization_membership (id, enterprise_id, person_id, organization_unit_id, is_primary, valid_from, valid_until, source, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: organization_unit; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.organization_unit (id, enterprise_id, parent_id, name, external_source_id, external_unit_id, status, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: person; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.person (id, name, department_label, status, version, created_at, updated_at, enterprise_id, employee_number, email, mobile) FROM stdin;
\.


--
-- Data for Name: person_external_identity; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.person_external_identity (id, person_id, provider, provider_user_id, status, verified_at, version, created_at, updated_at, enterprise_id, directory_source_id) FROM stdin;
\.


--
-- Data for Name: principal; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.principal (id, enterprise_id, type, name, department_label, status, created_at, updated_at, archived_at, person_id, owner_person_id, version) FROM stdin;
7051f4ae-d781-457d-af35-69b803258d8e	f01d5faa-0d54-449c-8d68-500c4395f923	EMPLOYEE	R7 员工	\N	ACTIVE	2026-11-05 07:21:11.611924+00	2026-11-05 07:21:11.611924+00	\N	\N	\N	1
\.


--
-- Data for Name: principal_access_config_state; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.principal_access_config_state (enterprise_id, principal_id, config_version, updated_at) FROM stdin;
\.


--
-- Data for Name: principal_access_idempotency; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.principal_access_idempotency (enterprise_id, principal_id, idempotency_key, request_hash, response_snapshot, created_at) FROM stdin;
\.


--
-- Data for Name: principal_accounting_assignment; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.principal_accounting_assignment (id, enterprise_id, principal_id, principal_type, department_id, owner_principal_id, version, valid_from, valid_until, created_by) FROM stdin;
\.


--
-- Data for Name: principal_agent_expectation; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.principal_agent_expectation (id, enterprise_id, principal_id, agent_family, created_at) FROM stdin;
\.


--
-- Data for Name: principal_grant; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.principal_grant (id, enterprise_id, principal_id, provider, model_alias, quota_unit, quota_value, allow_overage, valid_from, valid_until, status, created_at, updated_at, version, authorization_rule_version_id, pool_model_alias, quota_basis) FROM stdin;
6210175e-5efa-45f9-9a8b-7f4a0bff6209	f01d5faa-0d54-449c-8d68-500c4395f923	7051f4ae-d781-457d-af35-69b803258d8e	deepseek	deepseek-chat	TOKEN	1000000	f	2026-11-05 07:21:11.611924+00	\N	ACTIVE	2026-11-05 07:21:11.611924+00	2026-11-05 07:21:11.611924+00	1	\N	\N	RAW_TOKEN
\.


--
-- Data for Name: principal_key; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.principal_key (id, enterprise_id, principal_id, key_prefix, key_digest, allowed_model_ids, ip_allowlist, expires_at, quota_limit, concurrency_limit, status, created_at, last_used_at, revoked_at, used_tokens) FROM stdin;
4060d874-2c51-4c64-bb28-b82bb06c2dfc	f01d5faa-0d54-449c-8d68-500c4395f923	7051f4ae-d781-457d-af35-69b803258d8e	ql_r7	aef254fe-8593-42dd-ae33-7524365d6e7a	{}	\N	\N	\N	\N	ACTIVE	2026-11-05 07:21:11.611924+00	\N	\N	0
\.


--
-- Data for Name: principal_model_manual_authorization; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.principal_model_manual_authorization (enterprise_id, principal_id, unified_model_id, created_at) FROM stdin;
\.


--
-- Data for Name: principal_provider_disabled_model; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.principal_provider_disabled_model (enterprise_id, principal_id, provider, unified_model_id, disabled_at, disable_rule_version_id) FROM stdin;
\.


--
-- Data for Name: principal_quota_period; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.principal_quota_period (id, enterprise_id, principal_id, provider, period_key, period_start, period_end, timezone, quota_basis, limit_value, allow_overage, used_value, reserved_value, quality, open_grant_version, limit_updated_at, created_at, updated_at) FROM stdin;
ddd454c4-c1b4-442f-8c68-80f19d7c7cfc	f01d5faa-0d54-449c-8d68-500c4395f923	7051f4ae-d781-457d-af35-69b803258d8e	deepseek	2026-11	2026-10-31 16:00:00+00	2026-11-30 16:00:00+00	Asia/Shanghai	RAW_TOKEN	1000000	t	1200	0	COMPLETE	1	2026-11-05 07:21:13.373436+00	2026-11-05 07:21:13.373436+00	2026-11-05 07:21:13.373436+00
\.


--
-- Data for Name: principal_quota_usage; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.principal_quota_usage (id, enterprise_id, request_id, attempt_no, upstream_attempt_id, period_id, grant_id, grant_version, quota_basis, estimate, actual, status, usage_quality, created_at, settled_at) FROM stdin;
d6500540-cb63-4ab8-a033-2829d9fec8a9	f01d5faa-0d54-449c-8d68-500c4395f923	b5308447-cf8f-4b96-8d53-29e29335ddef	1	0af9c89e-9d9d-4e59-9d0b-a452029c8be5	ddd454c4-c1b4-442f-8c68-80f19d7c7cfc	6210175e-5efa-45f9-9a8b-7f4a0bff6209	1	RAW_TOKEN	1200	1200	SETTLED	PROVIDER_REPORTED	2026-11-04 08:00:01+00	2026-11-04 08:00:01+00
\.


--
-- Data for Name: procurement_review_note; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.procurement_review_note (id, enterprise_id, month, note, version, updated_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: procurement_review_note_idempotency; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.procurement_review_note_idempotency (enterprise_id, month, idempotency_key, request_hash, response_snapshot, created_at) FROM stdin;
\.


--
-- Data for Name: project_accounting_profile_version; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.project_accounting_profile_version (id, enterprise_id, project_principal_id, accounting_started_at, accounting_ended_at, version, is_current, reason, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: project_allocation_dirty; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.project_allocation_dirty (enterprise_id, period_month, generation, dirty, last_marked_at) FROM stdin;
\.


--
-- Data for Name: project_allocation_line; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.project_allocation_line (id, run_id, enterprise_id, ledger_line_id, ai_request_id, upstream_attempt_id, provider_resource_id, unified_model_id, request_started_at, accounted_at, source_principal_id, target_type, target_project_principal_id, allocation_source, weight_bps, policy_id, membership_id, membership_revision_id, segment_from, segment_until, unallocated_reason, source_input_tokens, source_output_tokens, source_cache_tokens, source_reasoning_tokens, share_input_tokens, share_output_tokens, share_cache_tokens, share_reasoning_tokens, source_api_cost, share_api_cost, api_cost_currency, source_package_cost, share_package_cost, package_cost_currency, usage_quality, resource_mode, created_at) FROM stdin;
\.


--
-- Data for Name: project_allocation_period; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.project_allocation_period (enterprise_id, period_month, enabled_by, enabled_at) FROM stdin;
\.


--
-- Data for Name: project_allocation_resource_residual; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.project_allocation_resource_residual (run_id, provider_resource_id, enterprise_id, amount, currency, note, created_at) FROM stdin;
\.


--
-- Data for Name: project_allocation_run; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.project_allocation_run (id, enterprise_id, period_month, schema_version, algorithm_version, status, generation, input_digest, rule_input_digest, membership_input_digest, manual_attribution_input_digest, source_fact_digest, source_snapshot_as_of, input_dirty_generation, actor_type, actor_admin_id, attempt, lease_owner, lease_expires_at, last_error, is_current, source_line_count, employee_count, project_count, conservation, completeness, result_hash, started_at, finished_at, duration_ms, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: project_allocation_scan_watermark; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.project_allocation_scan_watermark (enterprise_id, ledger_line_watermark, updated_at) FROM stdin;
\.


--
-- Data for Name: project_department_assignment; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.project_department_assignment (id, enterprise_id, project_principal_id, organization_unit_id, valid_from, valid_until, source, owner_person_id_at_assignment, version, created_by, reason, created_at) FROM stdin;
\.


--
-- Data for Name: project_membership; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.project_membership (id, enterprise_id, project_principal_id, employee_principal_id, stint_index, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: project_membership_revision; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.project_membership_revision (id, membership_id, enterprise_id, project_principal_id, employee_principal_id, revision, status, joined_at, left_at, idempotency_key, reason, supersedes_id, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: provider; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider (id, enterprise_id, code, name, adapter_type, supported_protocols, capability_set, status, config_schema_version, created_at, updated_at, archived_at) FROM stdin;
059a1676-5e89-4145-b444-f23a8f3d2d06	f01d5faa-0d54-449c-8d68-500c4395f923	deepseek	DeepSeek	OPENAI_COMPATIBLE	\N	\N	ACTIVE	\N	2026-11-05 07:21:11.611924+00	2026-11-05 07:21:11.611924+00	\N
\.


--
-- Data for Name: provider_finance_activation_attempt; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_finance_activation_attempt (id, enterprise_id, candidate_hash, fact_watermark_hash, decision, status, gap_summary, projection_summary, usage_repair_baseline, created_by_admin_user_id, created_at, expires_at, activation_idempotency_key, activation_result, activated_by_admin_user_id, activated_at, candidate_draft) FROM stdin;
\.


--
-- Data for Name: provider_finance_activation_quiescence; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_finance_activation_quiescence (enterprise_id, status, started_by_admin_user_id, started_at, expires_at, released_at, release_reason) FROM stdin;
\.


--
-- Data for Name: provider_finance_duplicate_candidate; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_finance_duplicate_candidate (id, enterprise_id, provider_resource_id, event_type, request_hash, request_payload, confirmation_token_hash, status, expires_at, created_by_admin_user_id, consumed_event_id, created_at, consumed_at) FROM stdin;
\.


--
-- Data for Name: provider_finance_event; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_finance_event (id, enterprise_id, provider_resource_id, event_type, account_amount, account_currency, cash_paid_cny, occurred_at, external_reference, reversal_of_event_id, correction_of_event_id, reconciliation_case_id, description, evidence_ref, source, idempotency_key, created_by_admin_user_id, created_at, legacy_cost_resolution_id) FROM stdin;
\.


--
-- Data for Name: provider_finance_idempotency; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_finance_idempotency (enterprise_id, provider_resource_id, idempotency_key, request_hash, response_snapshot, created_at) FROM stdin;
\.


--
-- Data for Name: provider_finance_legacy_cost_resolution; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_finance_legacy_cost_resolution (id, enterprise_id, provider_resource_id, account_currency, window_start, window_end_inclusive, provider_balance_snapshot_id, provider_confirmed_balance, local_balance_before_adjustment, known_api_cost, missing_api_cost, unknown_line_count, status, adjustment_event_id, evidence_ref, created_by_admin_user_id, created_at, updated_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: provider_finance_reconciliation_case; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_finance_reconciliation_case (id, enterprise_id, provider_resource_id, account_currency, local_balance, provider_confirmed_balance, difference_amount, balance_as_of, fact_watermark, status, decision, evidence_ref, opened_by_admin_user_id, decided_by_admin_user_id, adjustment_event_id, decision_note, decision_idempotency_key, version, created_at, updated_at, decided_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: provider_finance_recorded_cost_policy; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_finance_recorded_cost_policy (enterprise_id, provider_resource_id, enabled, authorized_by_admin_user_id, reason, evidence_ref, created_at) FROM stdin;
\.


--
-- Data for Name: provider_finance_runtime_state; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_finance_runtime_state (enterprise_id, strict_writes_enabled, activated_at, activated_by_admin_user_id, updated_at) FROM stdin;
f01d5faa-0d54-449c-8d68-500c4395f923	t	2026-11-04 00:00:00+00	e7e103dc-d14a-4a79-8e1b-aaa2183aef67	2026-11-05 07:21:13.339526+00
\.


--
-- Data for Name: provider_finance_usage_cost_disposition; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_finance_usage_cost_disposition (id, enterprise_id, provider_resource_id, ledger_line_id, ai_request_id, decision, original_ledger_fact, server_cost_evidence, reason, evidence_ref, decided_by_admin_user_id, idempotency_key, request_hash, created_at) FROM stdin;
\.


--
-- Data for Name: provider_model_discovery; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_model_discovery (id, enterprise_id, provider_resource_id, source, source_version, status, discovered_at, failure_code, created_at, parser_version, source_url, source_etag, source_last_modified, source_content_hash, source_checked_at, stale) FROM stdin;
\.


--
-- Data for Name: provider_model_discovery_item; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_model_discovery_item (id, enterprise_id, discovery_id, provider_resource_id, upstream_model, display_name, model_type, capabilities, source, compatible, unavailable_reason, availability_status, first_discovered_at, last_discovered_at, last_validated_at, created_at, facts) FROM stdin;
\.


--
-- Data for Name: provider_model_onboarding; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_model_onboarding (id, enterprise_id, idempotency_key, request_fingerprint, provider_resource_id, result, created_at) FROM stdin;
\.


--
-- Data for Name: provider_model_probe_item; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_model_probe_item (id, probe_run_id, upstream_model, validation_status, http_status, error_code, error_category, retryable, diagnostic_hash, checked_at) FROM stdin;
\.


--
-- Data for Name: provider_model_probe_run; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_model_probe_run (id, enterprise_id, provider_id, provider_resource_id, provider_code, resource_mode, credential_fingerprint, endpoint_scope, endpoint_host, discovery_source, discovery_source_hash, parser_version, status, idempotency_key, request_hash, started_at, finished_at) FROM stdin;
\.


--
-- Data for Name: provider_model_validation; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_model_validation (id, enterprise_id, provider_resource_id, unified_model_id, upstream_model, idempotency_key, request_fingerprint, status, result, started_at, finished_at, created_at, credential_fingerprint, caller_config_hash) FROM stdin;
\.


--
-- Data for Name: provider_quota_window; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_quota_window (id, enterprise_id, provider_resource_id, window_type, is_current, limit_value, used_value, remaining_value, unit, ratio, reset_at, provider_data_at, collected_at, source, adapter_version, sync_status, sync_error_code, last_success_at, created_at) FROM stdin;
\.


--
-- Data for Name: provider_resource; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_resource (id, enterprise_id, provider_id, name, mode, credential_type, credential_ciphertext, credential_fingerprint, credential_version, upstream_models, concurrency_limit, status, api_fallback_enabled, created_at, updated_at, resource_pool_id, credential_expires_at, credential_refresh_status, last_refresh_at, refresh_error_classification, consecutive_failures, cooldown_until, last_probe_at, version, monthly_budget_amount, monthly_budget_currency, subscription_auto_renew_enabled, auth_failure_id, auth_failure_model, auth_failure_config_hash, archived_at, quota_state_revision, quota_block_state) FROM stdin;
f6b15893-9207-4899-8950-b48e04e90c60	f01d5faa-0d54-449c-8d68-500c4395f923	059a1676-5e89-4145-b444-f23a8f3d2d06	R7 无期初 API 资源	API	API_KEY	\N	\N	\N	\N	\N	ACTIVE	f	2026-11-05 07:21:11.611924+00	2026-11-05 07:21:11.611924+00	\N	\N	OK	\N	\N	0	\N	\N	1	\N	\N	t	\N	\N	\N	\N	0	\N
c5729763-f60f-41eb-ae08-1762bb590d76	f01d5faa-0d54-449c-8d68-500c4395f923	059a1676-5e89-4145-b444-f23a8f3d2d06	R7 存量 PENDING 留档资源	API	API_KEY	\N	\N	\N	\N	\N	ACTIVE	f	2026-11-05 07:21:11.611924+00	2026-11-05 07:21:11.611924+00	\N	\N	OK	\N	\N	0	\N	\N	1	\N	\N	t	\N	\N	\N	\N	0	\N
\.


--
-- Data for Name: provider_resource_balance_refresh; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_resource_balance_refresh (id, enterprise_id, provider_resource_id, actor_admin_id, idempotency_key, status, error_code, started_at, finished_at, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: provider_resource_finance_state; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_resource_finance_state (provider_resource_id, enterprise_id, state, required_currencies, ready_at, ready_by_admin_user_id, version, created_at, updated_at) FROM stdin;
c5729763-f60f-41eb-ae08-1762bb590d76	f01d5faa-0d54-449c-8d68-500c4395f923	PENDING	[]	\N	\N	1	2026-11-05 07:21:13.349407+00	2026-11-05 07:21:13.349407+00
\.


--
-- Data for Name: provider_resource_monthly_budget; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_resource_monthly_budget (id, enterprise_id, provider_resource_id, month, version, status, amount, currency, is_current, created_by, created_at, idempotency_key, request_hash, response_snapshot) FROM stdin;
\.


--
-- Data for Name: provider_resource_operating_snapshot; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_resource_operating_snapshot (id, enterprise_id, provider_resource_id, version, source, collected_at, currency, recharge_amount, current_balance, cumulative_cost, current_period_cost, cost_period_start, cost_period_end, balance_updated_at, package_name, package_cost, total_quota, quota_unit, used_quota, remaining_quota, effective_from, effective_until, reset_cycle, next_reset_at, created_at, reset_anchor_at, reset_timezone, usage_calculation, granted_balance, topped_up_balance, provider_balance_available, balance_source, cost_source, subscription_period_id) FROM stdin;
\.


--
-- Data for Name: provider_resource_operating_sync_attempt; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_resource_operating_sync_attempt (id, enterprise_id, provider_resource_id, sync_day, balance_status, cost_status, snapshot_id, provider_data_at, started_at, completed_at, next_sync_at, error_code, failure_reason, adapter_version, created_at) FROM stdin;
\.


--
-- Data for Name: provider_subscription_period; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.provider_subscription_period (id, enterprise_id, provider_resource_id, finance_event_id, product_name, period_start, period_end_exclusive, source, migration_source_record_id, reversed_by_event_id, created_by_admin_user_id, created_at) FROM stdin;
\.


--
-- Data for Name: quota_counter; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.quota_counter (id, grant_id, used_value, overage_value, period_anchor, next_reset_at, reset_marker, updated_at) FROM stdin;
\.


--
-- Data for Name: reconciliation_discrepancy; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.reconciliation_discrepancy (id, enterprise_id, reconciliation_run_id, discrepancy_type, ai_request_id, usage_event_id, ledger_line_id, ledger_transaction_id, detail, severity, status, resolution_note, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: reconciliation_run; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.reconciliation_run (id, enterprise_id, range_from, range_to, requests_scanned, usage_events_scanned, ledger_lines_scanned, transactions_scanned, duplicate_count, missing_count, mismatch_count, total_discrepancies, result, duplicate_rate, missing_rate, summary, algorithm_version, started_at, finished_at) FROM stdin;
\.


--
-- Data for Name: report_delivery_action; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.report_delivery_action (id, enterprise_id, bundle_id, message_id, action, reason, previous_status, previous_version, created_at) FROM stdin;
\.


--
-- Data for Name: report_delivery_attempt; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.report_delivery_attempt (id, enterprise_id, message_id, version, started_at, finished_at, status, provider_message_id, error_code, classification, token_requests, media_requests, preparation_requests, message_requests) FROM stdin;
\.


--
-- Data for Name: report_delivery_bundle; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.report_delivery_bundle (id, enterprise_id, report_type, period_key, recipient_ref, target_user_id, endpoint_id, period_start, period_end, window_start, window_end, snapshot, content_hash, created_at) FROM stdin;
\.


--
-- Data for Name: report_delivery_claim; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.report_delivery_claim (enterprise_id, scope, bundle_id) FROM stdin;
\.


--
-- Data for Name: report_delivery_message; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.report_delivery_message (id, enterprise_id, bundle_id, kind, status, attempt_count, version, lease_until, next_attempt_at, last_attempt_at, provider_message_id, error_code, classification) FROM stdin;
\.


--
-- Data for Name: report_delivery_schedule; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.report_delivery_schedule (enterprise_id, report_type, schedule_date, status, classification, updated_at) FROM stdin;
\.


--
-- Data for Name: request_attribution_snapshot; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.request_attribution_snapshot (id, enterprise_id, ai_request_id, source_principal_id, employee_person_id, project_principal_id, organization_unit_id, cost_category, attribution_source, request_occurred_at, version, supersedes_id, snapshot_origin, reason_code, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: resource_purchase_idempotency; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.resource_purchase_idempotency (enterprise_id, provider_resource_id, idempotency_key, request_hash, response_snapshot, created_at) FROM stdin;
\.


--
-- Data for Name: resource_purchase_record; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.resource_purchase_record (id, enterprise_id, provider_resource_id, purchase_type, description, amount, currency, purchased_at, service_period_start, service_period_end, source, evidence_ref, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: resource_status_event; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.resource_status_event (id, enterprise_id, provider_resource_id, from_status, to_status, reason, error_classification, consecutive_failures, cooldown_until, actor, created_at, time_reliable) FROM stdin;
\.


--
-- Data for Name: route_candidate; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.route_candidate (id, ai_request_id, enterprise_id, provider_resource_id, upstream_model, priority, weight, selected, score_factors, total_score, reason_code, created_at) FROM stdin;
\.


--
-- Data for Name: runtime_notification_recipient; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.runtime_notification_recipient (id, category, person_id, created_at) FROM stdin;
\.


--
-- Data for Name: supply_forecast; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.supply_forecast (id, enterprise_id, provider_resource_id, rate_1h, rate_24h, rate_7d, forecast_exhaust_at, next_recover_at, coverage_hours, remaining_quota, confidence, data_points, not_calculable_reason, algorithm_version, snapshot_at, consumption_unit, forecast_key) FROM stdin;
\.


--
-- Data for Name: unified_model; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.unified_model (id, enterprise_id, alias, display_name, required_capabilities, status, created_at, updated_at, version, archived_at, archived_by_admin_id) FROM stdin;
\.


--
-- Data for Name: upstream_attempt; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.upstream_attempt (id, ai_request_id, enterprise_id, attempt_no, provider_resource_id, upstream_model, started_at, first_byte_at, finished_at, http_status, error_classification, error_code, response_committed, switch_reason, failure_layer, upstream_error_evidence, request_shape_summary, dispatch_check) FROM stdin;
0af9c89e-9d9d-4e59-9d0b-a452029c8be5	b5308447-cf8f-4b96-8d53-29e29335ddef	f01d5faa-0d54-449c-8d68-500c4395f923	1	f6b15893-9207-4899-8950-b48e04e90c60	deepseek-chat	2026-11-05 07:21:11.611924+00	\N	2026-11-04 08:00:01+00	200	\N	\N	t	\N	\N	\N	\N	\N
\.


--
-- Data for Name: usage_aggregate_bucket_state; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.usage_aggregate_bucket_state (enterprise_id, bucket_granularity, bucket_start, timezone, fact_watermark, max_fact_at, generated_at) FROM stdin;
\.


--
-- Data for Name: usage_aggregate_dirty_bucket; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.usage_aggregate_dirty_bucket (enterprise_id, bucket_granularity, bucket_start, timezone, marked_at) FROM stdin;
\.


--
-- Data for Name: usage_bucket_aggregate; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.usage_bucket_aggregate (id, enterprise_id, bucket_granularity, bucket_start, timezone, source_principal_id, project_principal_id, provider_resource_id, unified_model_id, request_count, input_tokens, output_tokens, cache_tokens, reasoning_tokens, deducted_quota, api_cost, fact_watermark, max_fact_at, dirty, generated_at, provider_reported_count, estimated_count, account_aggregated_count, mixed_count, unknown_count, api_cost_status) FROM stdin;
\.


--
-- Data for Name: usage_event; Type: TABLE DATA; Schema: public; Owner: wp6_r7
--

COPY public.usage_event (id, ai_request_id, enterprise_id, upstream_attempt_id, provider_resource_id, input_tokens, output_tokens, cache_tokens, usage_quality, upstream_usage_id, dedup_key, created_at, reasoning_tokens) FROM stdin;
99a4fdca-e1e3-4971-a2a8-11ab6dcdc8fa	b5308447-cf8f-4b96-8d53-29e29335ddef	f01d5faa-0d54-449c-8d68-500c4395f923	0af9c89e-9d9d-4e59-9d0b-a452029c8be5	f6b15893-9207-4899-8950-b48e04e90c60	1000	200	0	PROVIDER_REPORTED	\N	b5308447-cf8f-4b96-8d53-29e29335ddef	2026-11-04 08:00:01+00	0
\.


--
-- Name: _w01_baseline_probe_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wp6_r7
--

SELECT pg_catalog.setval('public._w01_baseline_probe_id_seq', 1, false);


--
-- Name: _migration_0045_pool046_backup _migration_0045_pool046_backup_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public._migration_0045_pool046_backup
    ADD CONSTRAINT _migration_0045_pool046_backup_pkey PRIMARY KEY (row_type, row_id);


--
-- Name: _w01_baseline_probe _w01_baseline_probe_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public._w01_baseline_probe
    ADD CONSTRAINT _w01_baseline_probe_pkey PRIMARY KEY (id);


--
-- Name: admin_role admin_role_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.admin_role
    ADD CONSTRAINT admin_role_pkey PRIMARY KEY (enterprise_id);


--
-- Name: admin_session admin_session_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.admin_session
    ADD CONSTRAINT admin_session_pkey PRIMARY KEY (id);


--
-- Name: admin_user admin_user_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.admin_user
    ADD CONSTRAINT admin_user_pkey PRIMARY KEY (id);


--
-- Name: ai_request ai_request_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ai_request
    ADD CONSTRAINT ai_request_pkey PRIMARY KEY (id);


--
-- Name: alert_event alert_event_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.alert_event
    ADD CONSTRAINT alert_event_pkey PRIMARY KEY (id);


--
-- Name: availability_event availability_event_event_number_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_event
    ADD CONSTRAINT availability_event_event_number_key UNIQUE (event_number);


--
-- Name: availability_event availability_event_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_event
    ADD CONSTRAINT availability_event_pkey PRIMARY KEY (id);


--
-- Name: availability_rule availability_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_rule
    ADD CONSTRAINT availability_rule_pkey PRIMARY KEY (id);


--
-- Name: availability_rule_version availability_rule_version_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_rule_version
    ADD CONSTRAINT availability_rule_version_pkey PRIMARY KEY (id);


--
-- Name: billing_rule billing_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.billing_rule
    ADD CONSTRAINT billing_rule_pkey PRIMARY KEY (id);


--
-- Name: concurrency_lease concurrency_lease_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.concurrency_lease
    ADD CONSTRAINT concurrency_lease_pkey PRIMARY KEY (id);


--
-- Name: credential_chat_probe credential_chat_probe_enterprise_id_provider_resource_id_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.credential_chat_probe
    ADD CONSTRAINT credential_chat_probe_enterprise_id_provider_resource_id_id_key UNIQUE (enterprise_id, provider_resource_id, idempotency_key);


--
-- Name: credential_chat_probe credential_chat_probe_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.credential_chat_probe
    ADD CONSTRAINT credential_chat_probe_pkey PRIMARY KEY (id);


--
-- Name: department_budget_idempotency department_budget_idempotency_pk; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.department_budget_idempotency
    ADD CONSTRAINT department_budget_idempotency_pk PRIMARY KEY (enterprise_id, organization_unit_id, month, idempotency_key);


--
-- Name: department_budget department_budget_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.department_budget
    ADD CONSTRAINT department_budget_pkey PRIMARY KEY (id);


--
-- Name: deployment_log deployment_log_enterprise_deployment_unique; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.deployment_log
    ADD CONSTRAINT deployment_log_enterprise_deployment_unique UNIQUE (enterprise_id, deployment_id);


--
-- Name: deployment_log_event deployment_log_event_key_unique; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.deployment_log_event
    ADD CONSTRAINT deployment_log_event_key_unique UNIQUE (deployment_log_id, event_key);


--
-- Name: deployment_log_event deployment_log_event_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.deployment_log_event
    ADD CONSTRAINT deployment_log_event_pkey PRIMARY KEY (id);


--
-- Name: deployment_log deployment_log_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.deployment_log
    ADD CONSTRAINT deployment_log_pkey PRIMARY KEY (id);


--
-- Name: directory_import_item directory_import_item_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_item
    ADD CONSTRAINT directory_import_item_pkey PRIMARY KEY (id);


--
-- Name: directory_import_item directory_import_item_run_row_uq; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_item
    ADD CONSTRAINT directory_import_item_run_row_uq UNIQUE (run_id, row_number);


--
-- Name: directory_import_run directory_import_run_idempotency_uq; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_run
    ADD CONSTRAINT directory_import_run_idempotency_uq UNIQUE (enterprise_id, idempotency_key);


--
-- Name: directory_import_run directory_import_run_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_run
    ADD CONSTRAINT directory_import_run_pkey PRIMARY KEY (id);


--
-- Name: directory_source directory_source_enterprise_type_uq; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_source
    ADD CONSTRAINT directory_source_enterprise_type_uq UNIQUE (enterprise_id, type);


--
-- Name: directory_source directory_source_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_source
    ADD CONSTRAINT directory_source_pkey PRIMARY KEY (id);


--
-- Name: dispatch_decision dispatch_decision_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.dispatch_decision
    ADD CONSTRAINT dispatch_decision_pkey PRIMARY KEY (id);


--
-- Name: dispatch_policy dispatch_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.dispatch_policy
    ADD CONSTRAINT dispatch_policy_pkey PRIMARY KEY (id);


--
-- Name: employee_model_rule_assignment employee_model_rule_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_assignment
    ADD CONSTRAINT employee_model_rule_assignment_pkey PRIMARY KEY (id);


--
-- Name: employee_model_rule_assignment employee_model_rule_assignment_unique; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_assignment
    ADD CONSTRAINT employee_model_rule_assignment_unique UNIQUE (rule_version_id, principal_id, unified_model_id, provider_resource_id);


--
-- Name: employee_model_rule_version employee_model_rule_version_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_version
    ADD CONSTRAINT employee_model_rule_version_pkey PRIMARY KEY (id);


--
-- Name: employee_model_rule_version employee_model_rule_version_unique; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_version
    ADD CONSTRAINT employee_model_rule_version_unique UNIQUE (enterprise_id, rule_id, version);


--
-- Name: employee_project_allocation_policy employee_project_allocation_p_enterprise_id_employee_princi_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_project_allocation_policy
    ADD CONSTRAINT employee_project_allocation_p_enterprise_id_employee_princi_key UNIQUE (enterprise_id, employee_principal_id, version);


--
-- Name: employee_project_allocation_policy employee_project_allocation_policy_enterprise_id_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_project_allocation_policy
    ADD CONSTRAINT employee_project_allocation_policy_enterprise_id_id_key UNIQUE (enterprise_id, id);


--
-- Name: employee_project_allocation_policy employee_project_allocation_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_project_allocation_policy
    ADD CONSTRAINT employee_project_allocation_policy_pkey PRIMARY KEY (id);


--
-- Name: employee_project_allocation_rule employee_project_allocation_rule_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_project_allocation_rule
    ADD CONSTRAINT employee_project_allocation_rule_pkey PRIMARY KEY (id);


--
-- Name: enterprise enterprise_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.enterprise
    ADD CONSTRAINT enterprise_pkey PRIMARY KEY (id);


--
-- Name: historical_import_run_item historical_import_run_item_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.historical_import_run_item
    ADD CONSTRAINT historical_import_run_item_pkey PRIMARY KEY (id);


--
-- Name: historical_import_run historical_import_run_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.historical_import_run
    ADD CONSTRAINT historical_import_run_pkey PRIMARY KEY (id);


--
-- Name: kysely_migration_lock kysely_migration_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.kysely_migration_lock
    ADD CONSTRAINT kysely_migration_lock_pkey PRIMARY KEY (id);


--
-- Name: kysely_migration kysely_migration_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.kysely_migration
    ADD CONSTRAINT kysely_migration_pkey PRIMARY KEY (name);


--
-- Name: ledger_line ledger_line_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_line
    ADD CONSTRAINT ledger_line_pkey PRIMARY KEY (id);


--
-- Name: ledger_transaction ledger_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_transaction
    ADD CONSTRAINT ledger_transaction_pkey PRIMARY KEY (id);


--
-- Name: ledger_transaction ledger_transaction_unique_request; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_transaction
    ADD CONSTRAINT ledger_transaction_unique_request UNIQUE (ai_request_id);


--
-- Name: model_route model_route_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.model_route
    ADD CONSTRAINT model_route_pkey PRIMARY KEY (id);


--
-- Name: notification_delivery notification_delivery_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.notification_delivery
    ADD CONSTRAINT notification_delivery_idempotency_key_key UNIQUE (idempotency_key);


--
-- Name: notification_delivery notification_delivery_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.notification_delivery
    ADD CONSTRAINT notification_delivery_pkey PRIMARY KEY (id);


--
-- Name: notification_endpoint notification_endpoint_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.notification_endpoint
    ADD CONSTRAINT notification_endpoint_pkey PRIMARY KEY (id);


--
-- Name: operating_bill_event operating_bill_event_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_event
    ADD CONSTRAINT operating_bill_event_pkey PRIMARY KEY (id);


--
-- Name: operating_bill_opening_balance operating_bill_opening_balance_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_opening_balance
    ADD CONSTRAINT operating_bill_opening_balance_pkey PRIMARY KEY (id);


--
-- Name: operating_bill_period operating_bill_period_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_period
    ADD CONSTRAINT operating_bill_period_pkey PRIMARY KEY (id);


--
-- Name: operating_bill_project_allocation_ref operating_bill_project_allocation_ref_bill_version_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_project_allocation_ref
    ADD CONSTRAINT operating_bill_project_allocation_ref_bill_version_id_key UNIQUE (bill_version_id);


--
-- Name: operating_bill_project_allocation_ref operating_bill_project_allocation_ref_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_project_allocation_ref
    ADD CONSTRAINT operating_bill_project_allocation_ref_pkey PRIMARY KEY (id);


--
-- Name: operating_bill_request_project_assignment operating_bill_request_project_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_request_project_assignment
    ADD CONSTRAINT operating_bill_request_project_assignment_pkey PRIMARY KEY (id);


--
-- Name: operating_bill_resource_confirmation operating_bill_resource_confirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_resource_confirmation
    ADD CONSTRAINT operating_bill_resource_confirmation_pkey PRIMARY KEY (id);


--
-- Name: operating_bill_value_item operating_bill_value_item_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_value_item
    ADD CONSTRAINT operating_bill_value_item_pkey PRIMARY KEY (id);


--
-- Name: operating_bill_version operating_bill_version_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_version
    ADD CONSTRAINT operating_bill_version_pkey PRIMARY KEY (id);


--
-- Name: operation_log operation_log_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operation_log
    ADD CONSTRAINT operation_log_pkey PRIMARY KEY (id);


--
-- Name: organization_membership organization_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.organization_membership
    ADD CONSTRAINT organization_membership_pkey PRIMARY KEY (id);


--
-- Name: organization_unit organization_unit_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.organization_unit
    ADD CONSTRAINT organization_unit_pkey PRIMARY KEY (id);


--
-- Name: person_external_identity person_external_identity_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.person_external_identity
    ADD CONSTRAINT person_external_identity_pkey PRIMARY KEY (id);


--
-- Name: person person_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (id);


--
-- Name: principal_access_config_state principal_access_config_state_pk; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_access_config_state
    ADD CONSTRAINT principal_access_config_state_pk PRIMARY KEY (enterprise_id, principal_id);


--
-- Name: principal_access_idempotency principal_access_idempotency_pk; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_access_idempotency
    ADD CONSTRAINT principal_access_idempotency_pk PRIMARY KEY (enterprise_id, principal_id, idempotency_key);


--
-- Name: principal_accounting_assignment principal_accounting_assignme_enterprise_id_principal_id_ve_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_accounting_assignment
    ADD CONSTRAINT principal_accounting_assignme_enterprise_id_principal_id_ve_key UNIQUE (enterprise_id, principal_id, version);


--
-- Name: principal_accounting_assignment principal_accounting_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_accounting_assignment
    ADD CONSTRAINT principal_accounting_assignment_pkey PRIMARY KEY (id);


--
-- Name: principal_agent_expectation principal_agent_expectation_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_agent_expectation
    ADD CONSTRAINT principal_agent_expectation_pkey PRIMARY KEY (id);


--
-- Name: principal_agent_expectation principal_agent_expectation_unique; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_agent_expectation
    ADD CONSTRAINT principal_agent_expectation_unique UNIQUE (enterprise_id, principal_id, agent_family);


--
-- Name: principal_grant principal_grant_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_grant
    ADD CONSTRAINT principal_grant_pkey PRIMARY KEY (id);


--
-- Name: principal_key principal_key_key_digest_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_key
    ADD CONSTRAINT principal_key_key_digest_key UNIQUE (key_digest);


--
-- Name: principal_key principal_key_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_key
    ADD CONSTRAINT principal_key_pkey PRIMARY KEY (id);


--
-- Name: principal_model_manual_authorization principal_model_manual_authorization_pk; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_model_manual_authorization
    ADD CONSTRAINT principal_model_manual_authorization_pk PRIMARY KEY (enterprise_id, principal_id, unified_model_id);


--
-- Name: principal principal_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal
    ADD CONSTRAINT principal_pkey PRIMARY KEY (id);


--
-- Name: principal_provider_disabled_model principal_provider_disabled_model_pk; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_provider_disabled_model
    ADD CONSTRAINT principal_provider_disabled_model_pk PRIMARY KEY (enterprise_id, principal_id, provider, unified_model_id);


--
-- Name: principal_quota_period principal_quota_period_enterprise_id_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_quota_period
    ADD CONSTRAINT principal_quota_period_enterprise_id_id_key UNIQUE (enterprise_id, id);


--
-- Name: principal_quota_period principal_quota_period_enterprise_id_principal_id_provider__key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_quota_period
    ADD CONSTRAINT principal_quota_period_enterprise_id_principal_id_provider__key UNIQUE (enterprise_id, principal_id, provider, period_key);


--
-- Name: principal_quota_period principal_quota_period_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_quota_period
    ADD CONSTRAINT principal_quota_period_pkey PRIMARY KEY (id);


--
-- Name: principal_quota_usage principal_quota_usage_enterprise_id_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_quota_usage
    ADD CONSTRAINT principal_quota_usage_enterprise_id_id_key UNIQUE (enterprise_id, id);


--
-- Name: principal_quota_usage principal_quota_usage_enterprise_id_request_id_attempt_no_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_quota_usage
    ADD CONSTRAINT principal_quota_usage_enterprise_id_request_id_attempt_no_key UNIQUE (enterprise_id, request_id, attempt_no);


--
-- Name: principal_quota_usage principal_quota_usage_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_quota_usage
    ADD CONSTRAINT principal_quota_usage_pkey PRIMARY KEY (id);


--
-- Name: principal_quota_usage principal_quota_usage_upstream_attempt_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_quota_usage
    ADD CONSTRAINT principal_quota_usage_upstream_attempt_id_key UNIQUE (upstream_attempt_id);


--
-- Name: procurement_review_note_idempotency procurement_review_note_idempotency_pk; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.procurement_review_note_idempotency
    ADD CONSTRAINT procurement_review_note_idempotency_pk PRIMARY KEY (enterprise_id, month, idempotency_key);


--
-- Name: procurement_review_note procurement_review_note_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.procurement_review_note
    ADD CONSTRAINT procurement_review_note_pkey PRIMARY KEY (id);


--
-- Name: project_accounting_profile_version project_accounting_profile_ve_enterprise_id_project_princip_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_accounting_profile_version
    ADD CONSTRAINT project_accounting_profile_ve_enterprise_id_project_princip_key UNIQUE (enterprise_id, project_principal_id, version);


--
-- Name: project_accounting_profile_version project_accounting_profile_version_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_accounting_profile_version
    ADD CONSTRAINT project_accounting_profile_version_pkey PRIMARY KEY (id);


--
-- Name: project_allocation_dirty project_allocation_dirty_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_dirty
    ADD CONSTRAINT project_allocation_dirty_pkey PRIMARY KEY (enterprise_id, period_month);


--
-- Name: project_allocation_line project_allocation_line_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_line
    ADD CONSTRAINT project_allocation_line_pkey PRIMARY KEY (id);


--
-- Name: project_allocation_line project_allocation_line_run_id_ledger_line_id_target_type_t_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_line
    ADD CONSTRAINT project_allocation_line_run_id_ledger_line_id_target_type_t_key UNIQUE (run_id, ledger_line_id, target_type, target_project_principal_id);


--
-- Name: project_allocation_period project_allocation_period_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_period
    ADD CONSTRAINT project_allocation_period_pkey PRIMARY KEY (enterprise_id, period_month);


--
-- Name: project_allocation_resource_residual project_allocation_resource_residual_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_resource_residual
    ADD CONSTRAINT project_allocation_resource_residual_pkey PRIMARY KEY (run_id, provider_resource_id);


--
-- Name: project_allocation_run project_allocation_run_enterprise_id_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_run
    ADD CONSTRAINT project_allocation_run_enterprise_id_id_key UNIQUE (enterprise_id, id);


--
-- Name: project_allocation_run project_allocation_run_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_run
    ADD CONSTRAINT project_allocation_run_pkey PRIMARY KEY (id);


--
-- Name: project_allocation_scan_watermark project_allocation_scan_watermark_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_scan_watermark
    ADD CONSTRAINT project_allocation_scan_watermark_pkey PRIMARY KEY (enterprise_id);


--
-- Name: project_department_assignment project_department_assignment_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_department_assignment
    ADD CONSTRAINT project_department_assignment_pkey PRIMARY KEY (id);


--
-- Name: project_membership project_membership_enterprise_id_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership
    ADD CONSTRAINT project_membership_enterprise_id_id_key UNIQUE (enterprise_id, id);


--
-- Name: project_membership project_membership_enterprise_id_project_principal_id_emplo_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership
    ADD CONSTRAINT project_membership_enterprise_id_project_principal_id_emplo_key UNIQUE (enterprise_id, project_principal_id, employee_principal_id, stint_index);


--
-- Name: project_membership project_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership
    ADD CONSTRAINT project_membership_pkey PRIMARY KEY (id);


--
-- Name: project_membership_revision project_membership_revision_active_interval_excl; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership_revision
    ADD CONSTRAINT project_membership_revision_active_interval_excl EXCLUDE USING gist (project_principal_id WITH =, employee_principal_id WITH =, tstzrange(joined_at, COALESCE(left_at, 'infinity'::timestamp with time zone)) WITH &&) WHERE ((status = 'ACTIVE'::text));


--
-- Name: project_membership_revision project_membership_revision_enterprise_id_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership_revision
    ADD CONSTRAINT project_membership_revision_enterprise_id_id_key UNIQUE (enterprise_id, id);


--
-- Name: project_membership_revision project_membership_revision_membership_id_revision_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership_revision
    ADD CONSTRAINT project_membership_revision_membership_id_revision_key UNIQUE (membership_id, revision);


--
-- Name: project_membership_revision project_membership_revision_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership_revision
    ADD CONSTRAINT project_membership_revision_pkey PRIMARY KEY (id);


--
-- Name: provider_finance_activation_attempt provider_finance_activation_attempt_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_activation_attempt
    ADD CONSTRAINT provider_finance_activation_attempt_pkey PRIMARY KEY (id);


--
-- Name: provider_finance_activation_quiescence provider_finance_activation_quiescence_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_activation_quiescence
    ADD CONSTRAINT provider_finance_activation_quiescence_pkey PRIMARY KEY (enterprise_id);


--
-- Name: provider_finance_duplicate_candidate provider_finance_duplicate_candidate_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_duplicate_candidate
    ADD CONSTRAINT provider_finance_duplicate_candidate_pkey PRIMARY KEY (id);


--
-- Name: provider_finance_event provider_finance_event_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_event
    ADD CONSTRAINT provider_finance_event_pkey PRIMARY KEY (id);


--
-- Name: provider_finance_idempotency provider_finance_idempotency_pk; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_idempotency
    ADD CONSTRAINT provider_finance_idempotency_pk PRIMARY KEY (enterprise_id, provider_resource_id, idempotency_key);


--
-- Name: provider_finance_legacy_cost_resolution provider_finance_legacy_cost_resolution_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_legacy_cost_resolution
    ADD CONSTRAINT provider_finance_legacy_cost_resolution_pkey PRIMARY KEY (id);


--
-- Name: provider_finance_reconciliation_case provider_finance_reconciliation_case_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_reconciliation_case
    ADD CONSTRAINT provider_finance_reconciliation_case_pkey PRIMARY KEY (id);


--
-- Name: provider_finance_recorded_cost_policy provider_finance_recorded_cost_policy_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_recorded_cost_policy
    ADD CONSTRAINT provider_finance_recorded_cost_policy_pkey PRIMARY KEY (enterprise_id, provider_resource_id);


--
-- Name: provider_finance_runtime_state provider_finance_runtime_state_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_runtime_state
    ADD CONSTRAINT provider_finance_runtime_state_pkey PRIMARY KEY (enterprise_id);


--
-- Name: provider_finance_usage_cost_disposition provider_finance_usage_cost_d_enterprise_id_idempotency_key_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_usage_cost_disposition
    ADD CONSTRAINT provider_finance_usage_cost_d_enterprise_id_idempotency_key_key UNIQUE (enterprise_id, idempotency_key);


--
-- Name: provider_finance_usage_cost_disposition provider_finance_usage_cost_di_enterprise_id_ledger_line_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_usage_cost_disposition
    ADD CONSTRAINT provider_finance_usage_cost_di_enterprise_id_ledger_line_id_key UNIQUE (enterprise_id, ledger_line_id);


--
-- Name: provider_finance_usage_cost_disposition provider_finance_usage_cost_disposition_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_usage_cost_disposition
    ADD CONSTRAINT provider_finance_usage_cost_disposition_pkey PRIMARY KEY (id);


--
-- Name: provider_model_discovery_item provider_model_discovery_item_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_discovery_item
    ADD CONSTRAINT provider_model_discovery_item_pkey PRIMARY KEY (id);


--
-- Name: provider_model_discovery_item provider_model_discovery_item_unique; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_discovery_item
    ADD CONSTRAINT provider_model_discovery_item_unique UNIQUE (discovery_id, upstream_model);


--
-- Name: provider_model_discovery provider_model_discovery_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_discovery
    ADD CONSTRAINT provider_model_discovery_pkey PRIMARY KEY (id);


--
-- Name: provider_model_onboarding provider_model_onboarding_idempotent; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_onboarding
    ADD CONSTRAINT provider_model_onboarding_idempotent UNIQUE (enterprise_id, idempotency_key);


--
-- Name: provider_model_onboarding provider_model_onboarding_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_onboarding
    ADD CONSTRAINT provider_model_onboarding_pkey PRIMARY KEY (id);


--
-- Name: provider_model_probe_item provider_model_probe_item_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_probe_item
    ADD CONSTRAINT provider_model_probe_item_pkey PRIMARY KEY (id);


--
-- Name: provider_model_probe_run provider_model_probe_run_idem_uniq; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_probe_run
    ADD CONSTRAINT provider_model_probe_run_idem_uniq UNIQUE (enterprise_id, idempotency_key);


--
-- Name: provider_model_probe_run provider_model_probe_run_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_probe_run
    ADD CONSTRAINT provider_model_probe_run_pkey PRIMARY KEY (id);


--
-- Name: provider_model_validation provider_model_validation_idempotent; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_validation
    ADD CONSTRAINT provider_model_validation_idempotent UNIQUE (enterprise_id, idempotency_key);


--
-- Name: provider_model_validation provider_model_validation_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_validation
    ADD CONSTRAINT provider_model_validation_pkey PRIMARY KEY (id);


--
-- Name: provider provider_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider
    ADD CONSTRAINT provider_pkey PRIMARY KEY (id);


--
-- Name: provider_quota_window provider_quota_window_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_quota_window
    ADD CONSTRAINT provider_quota_window_pkey PRIMARY KEY (id);


--
-- Name: provider_resource_balance_refresh provider_resource_balance_refresh_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_balance_refresh
    ADD CONSTRAINT provider_resource_balance_refresh_pkey PRIMARY KEY (id);


--
-- Name: provider_resource_finance_state provider_resource_finance_state_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_finance_state
    ADD CONSTRAINT provider_resource_finance_state_pkey PRIMARY KEY (provider_resource_id);


--
-- Name: provider_resource_monthly_budget provider_resource_monthly_budget_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_monthly_budget
    ADD CONSTRAINT provider_resource_monthly_budget_pkey PRIMARY KEY (id);


--
-- Name: provider_resource_operating_snapshot provider_resource_operating_snapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_operating_snapshot
    ADD CONSTRAINT provider_resource_operating_snapshot_pkey PRIMARY KEY (id);


--
-- Name: provider_resource_operating_sync_attempt provider_resource_operating_sync_attempt_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_operating_sync_attempt
    ADD CONSTRAINT provider_resource_operating_sync_attempt_pkey PRIMARY KEY (id);


--
-- Name: provider_resource provider_resource_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource
    ADD CONSTRAINT provider_resource_pkey PRIMARY KEY (id);


--
-- Name: provider_subscription_period provider_subscription_period_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_subscription_period
    ADD CONSTRAINT provider_subscription_period_pkey PRIMARY KEY (id);


--
-- Name: quota_counter quota_counter_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.quota_counter
    ADD CONSTRAINT quota_counter_pkey PRIMARY KEY (id);


--
-- Name: reconciliation_discrepancy reconciliation_discrepancy_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.reconciliation_discrepancy
    ADD CONSTRAINT reconciliation_discrepancy_pkey PRIMARY KEY (id);


--
-- Name: reconciliation_run reconciliation_run_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.reconciliation_run
    ADD CONSTRAINT reconciliation_run_pkey PRIMARY KEY (id);


--
-- Name: report_delivery_action report_delivery_action_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_action
    ADD CONSTRAINT report_delivery_action_pkey PRIMARY KEY (id);


--
-- Name: report_delivery_attempt report_delivery_attempt_message_id_version_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_attempt
    ADD CONSTRAINT report_delivery_attempt_message_id_version_key UNIQUE (message_id, version);


--
-- Name: report_delivery_attempt report_delivery_attempt_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_attempt
    ADD CONSTRAINT report_delivery_attempt_pkey PRIMARY KEY (id);


--
-- Name: report_delivery_bundle report_delivery_bundle_enterprise_id_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_bundle
    ADD CONSTRAINT report_delivery_bundle_enterprise_id_id_key UNIQUE (enterprise_id, id);


--
-- Name: report_delivery_bundle report_delivery_bundle_enterprise_id_report_type_period_key_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_bundle
    ADD CONSTRAINT report_delivery_bundle_enterprise_id_report_type_period_key_key UNIQUE (enterprise_id, report_type, period_key, recipient_ref);


--
-- Name: report_delivery_bundle report_delivery_bundle_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_bundle
    ADD CONSTRAINT report_delivery_bundle_pkey PRIMARY KEY (id);


--
-- Name: report_delivery_claim report_delivery_claim_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_claim
    ADD CONSTRAINT report_delivery_claim_pkey PRIMARY KEY (enterprise_id, scope);


--
-- Name: report_delivery_message report_delivery_message_bundle_id_kind_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_message
    ADD CONSTRAINT report_delivery_message_bundle_id_kind_key UNIQUE (bundle_id, kind);


--
-- Name: report_delivery_message report_delivery_message_enterprise_id_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_message
    ADD CONSTRAINT report_delivery_message_enterprise_id_id_key UNIQUE (enterprise_id, id);


--
-- Name: report_delivery_message report_delivery_message_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_message
    ADD CONSTRAINT report_delivery_message_pkey PRIMARY KEY (id);


--
-- Name: report_delivery_schedule report_delivery_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_schedule
    ADD CONSTRAINT report_delivery_schedule_pkey PRIMARY KEY (enterprise_id, report_type, schedule_date);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_pkey PRIMARY KEY (id);


--
-- Name: resource_purchase_idempotency resource_purchase_idempotency_pk; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.resource_purchase_idempotency
    ADD CONSTRAINT resource_purchase_idempotency_pk PRIMARY KEY (enterprise_id, provider_resource_id, idempotency_key);


--
-- Name: resource_purchase_record resource_purchase_record_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.resource_purchase_record
    ADD CONSTRAINT resource_purchase_record_pkey PRIMARY KEY (id);


--
-- Name: resource_status_event resource_status_event_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.resource_status_event
    ADD CONSTRAINT resource_status_event_pkey PRIMARY KEY (id);


--
-- Name: route_candidate route_candidate_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.route_candidate
    ADD CONSTRAINT route_candidate_pkey PRIMARY KEY (id);


--
-- Name: runtime_notification_recipient runtime_notification_recipient_category_person_id_key; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.runtime_notification_recipient
    ADD CONSTRAINT runtime_notification_recipient_category_person_id_key UNIQUE (category, person_id);


--
-- Name: runtime_notification_recipient runtime_notification_recipient_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.runtime_notification_recipient
    ADD CONSTRAINT runtime_notification_recipient_pkey PRIMARY KEY (id);


--
-- Name: supply_forecast supply_forecast_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.supply_forecast
    ADD CONSTRAINT supply_forecast_pkey PRIMARY KEY (id);


--
-- Name: unified_model unified_model_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.unified_model
    ADD CONSTRAINT unified_model_pkey PRIMARY KEY (id);


--
-- Name: upstream_attempt upstream_attempt_diagnostic_pair_check; Type: CHECK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE public.upstream_attempt
    ADD CONSTRAINT upstream_attempt_diagnostic_pair_check CHECK (((upstream_error_evidence IS NULL) = (request_shape_summary IS NULL))) NOT VALID;


--
-- Name: upstream_attempt upstream_attempt_diagnostic_status_check; Type: CHECK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE public.upstream_attempt
    ADD CONSTRAINT upstream_attempt_diagnostic_status_check CHECK (((upstream_error_evidence IS NULL) OR ((upstream_error_evidence ->> 'httpStatus'::text) = ANY (ARRAY['400'::text, '401'::text, '403'::text])))) NOT VALID;


--
-- Name: upstream_attempt upstream_attempt_error_evidence_object_check; Type: CHECK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE public.upstream_attempt
    ADD CONSTRAINT upstream_attempt_error_evidence_object_check CHECK (((upstream_error_evidence IS NULL) OR ((jsonb_typeof(upstream_error_evidence) = 'object'::text) AND (pg_column_size(upstream_error_evidence) <= 4096)))) NOT VALID;


--
-- Name: upstream_attempt upstream_attempt_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.upstream_attempt
    ADD CONSTRAINT upstream_attempt_pkey PRIMARY KEY (id);


--
-- Name: upstream_attempt upstream_attempt_request_shape_object_check; Type: CHECK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE public.upstream_attempt
    ADD CONSTRAINT upstream_attempt_request_shape_object_check CHECK (((request_shape_summary IS NULL) OR ((jsonb_typeof(request_shape_summary) = 'object'::text) AND (pg_column_size(request_shape_summary) <= 4096)))) NOT VALID;


--
-- Name: historical_import_run uq_historical_import_run_identity; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.historical_import_run
    ADD CONSTRAINT uq_historical_import_run_identity UNIQUE (enterprise_id, manifest_hash, source_package_hash);


--
-- Name: historical_import_run_item uq_run_item_entity; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.historical_import_run_item
    ADD CONSTRAINT uq_run_item_entity UNIQUE (entity_type, entity_id);


--
-- Name: usage_aggregate_bucket_state usage_aggregate_bucket_state_pk; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_aggregate_bucket_state
    ADD CONSTRAINT usage_aggregate_bucket_state_pk PRIMARY KEY (enterprise_id, bucket_granularity, bucket_start, timezone);


--
-- Name: usage_aggregate_dirty_bucket usage_aggregate_dirty_bucket_pk; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_aggregate_dirty_bucket
    ADD CONSTRAINT usage_aggregate_dirty_bucket_pk PRIMARY KEY (enterprise_id, bucket_granularity, bucket_start, timezone);


--
-- Name: usage_bucket_aggregate usage_bucket_aggregate_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_bucket_aggregate
    ADD CONSTRAINT usage_bucket_aggregate_pkey PRIMARY KEY (id);


--
-- Name: usage_event usage_event_pkey; Type: CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_event
    ADD CONSTRAINT usage_event_pkey PRIMARY KEY (id);


--
-- Name: usage_event usage_event_quality_check; Type: CHECK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE public.usage_event
    ADD CONSTRAINT usage_event_quality_check CHECK (((usage_quality)::text = ANY ((ARRAY['PROVIDER_REPORTED'::character varying, 'ESTIMATED'::character varying, 'ACCOUNT_AGGREGATED'::character varying, 'MIXED'::character varying, 'UNKNOWN'::character varying])::text[]))) NOT VALID;


--
-- Name: admin_session_token_hash_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX admin_session_token_hash_idx ON public.admin_session USING btree (token_hash);


--
-- Name: admin_user_enterprise_archived_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX admin_user_enterprise_archived_idx ON public.admin_user USING btree (enterprise_id, archived_at);


--
-- Name: admin_user_enterprise_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX admin_user_enterprise_id_uq ON public.admin_user USING btree (enterprise_id, id);


--
-- Name: admin_user_enterprise_username_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX admin_user_enterprise_username_idx ON public.admin_user USING btree (enterprise_id, username);


--
-- Name: ai_request_client_request_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ai_request_client_request_idx ON public.ai_request USING btree (enterprise_id, client_request_id, started_at);


--
-- Name: ai_request_enterprise_agent_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ai_request_enterprise_agent_idx ON public.ai_request USING btree (enterprise_id, agent_family, started_at);


--
-- Name: ai_request_enterprise_client_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ai_request_enterprise_client_idx ON public.ai_request USING btree (enterprise_id, client_id);


--
-- Name: ai_request_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX ai_request_enterprise_id_id_uq ON public.ai_request USING btree (enterprise_id, id);


--
-- Name: ai_request_enterprise_model_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ai_request_enterprise_model_idx ON public.ai_request USING btree (enterprise_id, unified_model);


--
-- Name: ai_request_enterprise_principal_model_started_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ai_request_enterprise_principal_model_started_idx ON public.ai_request USING btree (enterprise_id, principal_id, unified_model_id, started_at);


--
-- Name: ai_request_enterprise_status_started_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ai_request_enterprise_status_started_idx ON public.ai_request USING btree (enterprise_id, status, started_at DESC);


--
-- Name: ai_request_import_run_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ai_request_import_run_idx ON public.ai_request USING btree (import_run_id) WHERE (import_run_id IS NOT NULL);


--
-- Name: ai_request_import_source_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ai_request_import_source_idx ON public.ai_request USING btree (import_source) WHERE (import_source IS NOT NULL);


--
-- Name: ai_request_in_flight_by_key_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ai_request_in_flight_by_key_idx ON public.ai_request USING btree (principal_key_id) WHERE ((status)::text = 'IN_PROGRESS'::text);


--
-- Name: ai_request_principal_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ai_request_principal_idx ON public.ai_request USING btree (principal_id, started_at);


--
-- Name: ai_request_principal_key_idempotency_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX ai_request_principal_key_idempotency_uq ON public.ai_request USING btree (principal_key_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: alert_event_availability_event_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX alert_event_availability_event_idx ON public.alert_event USING btree (availability_event_id);


--
-- Name: alert_event_domain_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX alert_event_domain_idx ON public.alert_event USING btree (enterprise_id, domain, status);


--
-- Name: alert_event_open_key; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX alert_event_open_key ON public.alert_event USING btree (enterprise_id, alert_key) WHERE ((status)::text = 'OPEN'::text);


--
-- Name: availability_event_open_dedup_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX availability_event_open_dedup_uq ON public.availability_event USING btree (dedup_key) WHERE ((status)::text = 'OPEN'::text);


--
-- Name: availability_event_quota_incident_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX availability_event_quota_incident_idx ON public.availability_event USING btree (provider_resource_id, quota_block_incident_id) WHERE ((quota_block_incident_id IS NOT NULL) AND ((status)::text = 'OPEN'::text));


--
-- Name: availability_event_resource_status_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX availability_event_resource_status_idx ON public.availability_event USING btree (provider_resource_id, status, recover_at);


--
-- Name: availability_rule_version_event_ref_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX availability_rule_version_event_ref_uq ON public.availability_rule_version USING btree (id, availability_rule_id, rule_version);


--
-- Name: availability_rule_version_match_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX availability_rule_version_match_idx ON public.availability_rule_version USING btree (status, effective_from, effective_to, priority);


--
-- Name: availability_rule_version_number_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX availability_rule_version_number_uq ON public.availability_rule_version USING btree (availability_rule_id, rule_version);


--
-- Name: availability_rule_version_one_draft_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX availability_rule_version_one_draft_uq ON public.availability_rule_version USING btree (availability_rule_id) WHERE ((status)::text = 'DRAFT'::text);


--
-- Name: billing_rule_archive_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX billing_rule_archive_idx ON public.billing_rule USING btree (enterprise_id, archived_at);


--
-- Name: billing_rule_match_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX billing_rule_match_idx ON public.billing_rule USING btree (enterprise_id, provider_resource_id, upstream_model, enabled, priority);


--
-- Name: concurrency_lease_active_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX concurrency_lease_active_idx ON public.concurrency_lease USING btree (provider_resource_id, released_at);


--
-- Name: concurrency_lease_expired_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX concurrency_lease_expired_idx ON public.concurrency_lease USING btree (expires_at) WHERE (released_at IS NULL);


--
-- Name: credential_chat_probe_running; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX credential_chat_probe_running ON public.credential_chat_probe USING btree (provider_resource_id) WHERE (status = 'RUNNING'::text);


--
-- Name: department_budget_enterprise_department_month_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX department_budget_enterprise_department_month_uq ON public.department_budget USING btree (enterprise_id, organization_unit_id, month);


--
-- Name: department_budget_enterprise_month_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX department_budget_enterprise_month_idx ON public.department_budget USING btree (enterprise_id, month);


--
-- Name: deployment_log_query_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX deployment_log_query_idx ON public.deployment_log USING btree (enterprise_id, started_at, status);


--
-- Name: directory_import_item_claim_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX directory_import_item_claim_idx ON public.directory_import_item USING btree (run_id, status, lease_until, row_number);


--
-- Name: directory_import_item_result_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX directory_import_item_result_idx ON public.directory_import_item USING btree (enterprise_id, principal_id, status);


--
-- Name: directory_import_run_claim_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX directory_import_run_claim_idx ON public.directory_import_run USING btree (status, next_attempt_at, lease_until, created_at);


--
-- Name: directory_import_run_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX directory_import_run_enterprise_id_id_uq ON public.directory_import_run USING btree (enterprise_id, id);


--
-- Name: directory_import_run_excel_content_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX directory_import_run_excel_content_idx ON public.directory_import_run USING btree (enterprise_id, content_sha256, template_version) WHERE ((mode)::text = 'EXCEL'::text);


--
-- Name: directory_import_run_sync_snapshot_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX directory_import_run_sync_snapshot_idx ON public.directory_import_run USING btree (enterprise_id, directory_source_id, source_snapshot_id, connector_version) WHERE (((mode)::text = 'SYNC'::text) AND (source_snapshot_id IS NOT NULL));


--
-- Name: directory_source_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX directory_source_enterprise_id_id_uq ON public.directory_source USING btree (enterprise_id, id);


--
-- Name: dispatch_decision_request_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX dispatch_decision_request_idx ON public.dispatch_decision USING btree (ai_request_id);


--
-- Name: dispatch_policy_active_restore_unique_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX dispatch_policy_active_restore_unique_idx ON public.dispatch_policy USING btree (enterprise_id, restore_source_policy_id) WHERE ((restore_source_policy_id IS NOT NULL) AND ((status)::text = 'PUBLISHED'::text));


--
-- Name: dispatch_policy_enterprise_published_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX dispatch_policy_enterprise_published_idx ON public.dispatch_policy USING btree (enterprise_id, status, priority);


--
-- Name: dispatch_policy_timeline_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX dispatch_policy_timeline_idx ON public.dispatch_policy USING btree (enterprise_id, created_at);


--
-- Name: employee_login_username_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX employee_login_username_idx ON public.employee_login USING btree (username);


--
-- Name: employee_model_rule_assignment_current_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX employee_model_rule_assignment_current_idx ON public.employee_model_rule_assignment USING btree (enterprise_id, principal_id, status);


--
-- Name: employee_model_rule_one_published_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX employee_model_rule_one_published_uq ON public.employee_model_rule_version USING btree (enterprise_id, rule_id) WHERE ((status)::text = 'PUBLISHED'::text);


--
-- Name: employee_model_rule_publish_idempotency_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX employee_model_rule_publish_idempotency_uq ON public.employee_model_rule_version USING btree (enterprise_id, publish_idempotency_key) WHERE (publish_idempotency_key IS NOT NULL);


--
-- Name: employee_model_rule_single_owner_editable_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX employee_model_rule_single_owner_editable_uq ON public.employee_model_rule_version USING btree (enterprise_id, owner_principal_id) WHERE ((owner_principal_id IS NOT NULL) AND ((status)::text = ANY ((ARRAY['DRAFT'::character varying, 'VALIDATED'::character varying])::text[])));


--
-- Name: employee_model_rule_single_owner_published_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX employee_model_rule_single_owner_published_uq ON public.employee_model_rule_version USING btree (enterprise_id, owner_principal_id) WHERE ((owner_principal_id IS NOT NULL) AND ((status)::text = 'PUBLISHED'::text));


--
-- Name: employee_project_allocation_policy_current_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX employee_project_allocation_policy_current_uq ON public.employee_project_allocation_policy USING btree (enterprise_id, employee_principal_id) WHERE is_current;


--
-- Name: employee_project_allocation_policy_idem_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX employee_project_allocation_policy_idem_uq ON public.employee_project_allocation_policy USING btree (enterprise_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: employee_project_allocation_rule_by_employee_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX employee_project_allocation_rule_by_employee_idx ON public.employee_project_allocation_rule USING btree (enterprise_id, employee_principal_id, valid_from);


--
-- Name: employee_project_allocation_rule_by_policy_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX employee_project_allocation_rule_by_policy_idx ON public.employee_project_allocation_rule USING btree (policy_id);


--
-- Name: employee_project_allocation_rule_by_project_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX employee_project_allocation_rule_by_project_idx ON public.employee_project_allocation_rule USING btree (enterprise_id, project_principal_id, valid_from);


--
-- Name: historical_import_run_ent_status_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX historical_import_run_ent_status_idx ON public.historical_import_run USING btree (enterprise_id, status);


--
-- Name: historical_import_run_item_run_type_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX historical_import_run_item_run_type_idx ON public.historical_import_run_item USING btree (run_id, entity_type);


--
-- Name: ledger_line_enterprise_created_request_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ledger_line_enterprise_created_request_idx ON public.ledger_line USING btree (enterprise_id, created_at, ai_request_id);


--
-- Name: ledger_line_enterprise_resource_created_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ledger_line_enterprise_resource_created_idx ON public.ledger_line USING btree (enterprise_id, provider_resource_id, created_at DESC);


--
-- Name: ledger_line_enterprise_resource_request_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ledger_line_enterprise_resource_request_idx ON public.ledger_line USING btree (enterprise_id, provider_resource_id, ai_request_id);


--
-- Name: ledger_line_principal_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ledger_line_principal_idx ON public.ledger_line USING btree (principal_id, created_at);


--
-- Name: ledger_line_request_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ledger_line_request_idx ON public.ledger_line USING btree (ai_request_id);


--
-- Name: ledger_line_resource_month_cover_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ledger_line_resource_month_cover_idx ON public.ledger_line USING btree (enterprise_id, provider_resource_id, created_at) INCLUDE (ai_request_id, raw_input_tokens, raw_output_tokens, api_cost, deducted_quota);


--
-- Name: ledger_line_resource_settled_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ledger_line_resource_settled_idx ON public.ledger_line USING btree (enterprise_id, provider_resource_id, COALESCE(settled_at, created_at) DESC, created_at DESC, id DESC);


--
-- Name: ledger_line_unique_usage_event_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX ledger_line_unique_usage_event_idx ON public.ledger_line USING btree (usage_event_id);


--
-- Name: ledger_transaction_enterprise_created_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ledger_transaction_enterprise_created_idx ON public.ledger_transaction USING btree (enterprise_id, created_at DESC, ai_request_id);


--
-- Name: ledger_transaction_request_text_trgm_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX ledger_transaction_request_text_trgm_idx ON public.ledger_transaction USING gin (((ai_request_id)::text) public.gin_trgm_ops);


--
-- Name: model_route_archive_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX model_route_archive_idx ON public.model_route USING btree (enterprise_id, archived_at);


--
-- Name: model_route_model_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX model_route_model_idx ON public.model_route USING btree (unified_model_id, enabled);


--
-- Name: model_route_resource_upstream_unique; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX model_route_resource_upstream_unique ON public.model_route USING btree (enterprise_id, unified_model_id, provider_resource_id, upstream_model);


--
-- Name: notification_delivery_claim_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX notification_delivery_claim_idx ON public.notification_delivery USING btree (status, next_attempt_at, created_at);


--
-- Name: notification_endpoint_one_active_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX notification_endpoint_one_active_uq ON public.notification_endpoint USING btree (provider) WHERE ((status)::text = 'ACTIVE'::text);


--
-- Name: operating_bill_event_period_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX operating_bill_event_period_idx ON public.operating_bill_event USING btree (enterprise_id, period_id, created_at);


--
-- Name: operating_bill_opening_balance_version_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX operating_bill_opening_balance_version_uq ON public.operating_bill_opening_balance USING btree (enterprise_id, period_id, provider_resource_id, version);


--
-- Name: operating_bill_period_enterprise_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX operating_bill_period_enterprise_id_uq ON public.operating_bill_period USING btree (enterprise_id, id);


--
-- Name: operating_bill_period_enterprise_month_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX operating_bill_period_enterprise_month_uq ON public.operating_bill_period USING btree (enterprise_id, period_month);


--
-- Name: operating_bill_project_allocation_ref_run_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX operating_bill_project_allocation_ref_run_idx ON public.operating_bill_project_allocation_ref USING btree (run_id);


--
-- Name: operating_bill_request_project_assignment_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX operating_bill_request_project_assignment_uq ON public.operating_bill_request_project_assignment USING btree (enterprise_id, ai_request_id);


--
-- Name: operating_bill_request_project_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX operating_bill_request_project_idx ON public.operating_bill_request_project_assignment USING btree (enterprise_id, project_principal_id);


--
-- Name: operating_bill_resource_confirmation_current_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX operating_bill_resource_confirmation_current_uq ON public.operating_bill_resource_confirmation USING btree (enterprise_id, period_id, provider_resource_id);


--
-- Name: operating_bill_value_period_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX operating_bill_value_period_idx ON public.operating_bill_value_item USING btree (enterprise_id, period_id, created_at);


--
-- Name: operating_bill_version_enterprise_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX operating_bill_version_enterprise_id_uq ON public.operating_bill_version USING btree (enterprise_id, id);


--
-- Name: operating_bill_version_period_version_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX operating_bill_version_period_version_uq ON public.operating_bill_version USING btree (period_id, version);


--
-- Name: operating_snapshot_subscription_period_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX operating_snapshot_subscription_period_idx ON public.provider_resource_operating_snapshot USING btree (enterprise_id, provider_resource_id, subscription_period_id, version) WHERE (subscription_period_id IS NOT NULL);


--
-- Name: operation_log_enterprise_created_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX operation_log_enterprise_created_idx ON public.operation_log USING btree (enterprise_id, created_at);


--
-- Name: operation_log_target_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX operation_log_target_idx ON public.operation_log USING btree (target_type, target_id);


--
-- Name: organization_membership_current_primary_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX organization_membership_current_primary_uq ON public.organization_membership USING btree (enterprise_id, person_id) WHERE (is_primary AND (valid_until IS NULL));


--
-- Name: organization_membership_unit_current_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX organization_membership_unit_current_idx ON public.organization_membership USING btree (enterprise_id, organization_unit_id, valid_until);


--
-- Name: organization_unit_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX organization_unit_enterprise_id_id_uq ON public.organization_unit USING btree (enterprise_id, id);


--
-- Name: organization_unit_excel_path_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX organization_unit_excel_path_uq ON public.organization_unit USING btree (enterprise_id, external_unit_id) WHERE ((external_source_id IS NULL) AND (external_unit_id IS NOT NULL));


--
-- Name: organization_unit_source_external_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX organization_unit_source_external_uq ON public.organization_unit USING btree (enterprise_id, external_source_id, external_unit_id) WHERE ((external_source_id IS NOT NULL) AND (external_unit_id IS NOT NULL));


--
-- Name: person_employee_number_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX person_employee_number_uq ON public.person USING btree (enterprise_id, lower((employee_number)::text)) WHERE (employee_number IS NOT NULL);


--
-- Name: person_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX person_enterprise_id_id_uq ON public.person USING btree (enterprise_id, id);


--
-- Name: person_external_identity_legacy_member_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX person_external_identity_legacy_member_uq ON public.person_external_identity USING btree (enterprise_id, provider, provider_user_id) WHERE (((status)::text = 'ACTIVE'::text) AND (directory_source_id IS NULL));


--
-- Name: person_external_identity_person_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX person_external_identity_person_idx ON public.person_external_identity USING btree (person_id, status);


--
-- Name: person_external_identity_source_member_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX person_external_identity_source_member_uq ON public.person_external_identity USING btree (enterprise_id, directory_source_id, provider_user_id) WHERE (((status)::text = 'ACTIVE'::text) AND (directory_source_id IS NOT NULL));


--
-- Name: person_external_identity_source_person_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX person_external_identity_source_person_uq ON public.person_external_identity USING btree (enterprise_id, directory_source_id, person_id) WHERE (((status)::text = 'ACTIVE'::text) AND (directory_source_id IS NOT NULL));


--
-- Name: principal_accounting_assignment_current; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX principal_accounting_assignment_current ON public.principal_accounting_assignment USING btree (enterprise_id, principal_id) WHERE (valid_until IS NULL);


--
-- Name: principal_accounting_assignment_history; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX principal_accounting_assignment_history ON public.principal_accounting_assignment USING btree (enterprise_id, principal_id, valid_from, valid_until);


--
-- Name: principal_employee_person_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX principal_employee_person_uq ON public.principal USING btree (enterprise_id, person_id) WHERE (((type)::text = 'EMPLOYEE'::text) AND (person_id IS NOT NULL));


--
-- Name: principal_enterprise_archived_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX principal_enterprise_archived_idx ON public.principal USING btree (enterprise_id, archived_at);


--
-- Name: principal_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX principal_enterprise_id_id_uq ON public.principal USING btree (enterprise_id, id);


--
-- Name: principal_enterprise_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX principal_enterprise_id_uq ON public.principal USING btree (enterprise_id, id);


--
-- Name: principal_enterprise_name_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX principal_enterprise_name_idx ON public.principal USING btree (enterprise_id, name);


--
-- Name: principal_grant_enterprise_id_id_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX principal_grant_enterprise_id_id_idx ON public.principal_grant USING btree (enterprise_id, id);


--
-- Name: principal_grant_pool_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX principal_grant_pool_uq ON public.principal_grant USING btree (enterprise_id, principal_id, provider) WHERE (((pool_model_alias)::text = '*'::text) AND ((status)::text = 'ACTIVE'::text));


--
-- Name: principal_grant_principal_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX principal_grant_principal_idx ON public.principal_grant USING btree (principal_id, provider, model_alias);


--
-- Name: principal_key_digest_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX principal_key_digest_idx ON public.principal_key USING btree (key_digest);


--
-- Name: principal_key_one_active_per_principal_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX principal_key_one_active_per_principal_uq ON public.principal_key USING btree (enterprise_id, principal_id) WHERE ((status)::text = 'ACTIVE'::text);


--
-- Name: principal_key_principal_status_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX principal_key_principal_status_idx ON public.principal_key USING btree (principal_id, status);


--
-- Name: principal_name_trgm_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX principal_name_trgm_idx ON public.principal USING gin (name public.gin_trgm_ops);


--
-- Name: principal_owner_person_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX principal_owner_person_idx ON public.principal USING btree (owner_person_id);


--
-- Name: principal_person_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX principal_person_idx ON public.principal USING btree (person_id);


--
-- Name: principal_provider_disabled_model_lookup_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX principal_provider_disabled_model_lookup_idx ON public.principal_provider_disabled_model USING btree (enterprise_id, principal_id, provider, unified_model_id);


--
-- Name: principal_quota_usage_period_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX principal_quota_usage_period_idx ON public.principal_quota_usage USING btree (enterprise_id, period_id, created_at);


--
-- Name: procurement_review_note_enterprise_month_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX procurement_review_note_enterprise_month_uq ON public.procurement_review_note USING btree (enterprise_id, month);


--
-- Name: project_accounting_profile_current_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX project_accounting_profile_current_uq ON public.project_accounting_profile_version USING btree (enterprise_id, project_principal_id) WHERE is_current;


--
-- Name: project_accounting_profile_history_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX project_accounting_profile_history_idx ON public.project_accounting_profile_version USING btree (enterprise_id, project_principal_id, version DESC);


--
-- Name: project_allocation_line_by_project_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX project_allocation_line_by_project_idx ON public.project_allocation_line USING btree (run_id, target_project_principal_id);


--
-- Name: project_allocation_line_by_source_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX project_allocation_line_by_source_idx ON public.project_allocation_line USING btree (run_id, source_principal_id);


--
-- Name: project_allocation_line_unallocated_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX project_allocation_line_unallocated_idx ON public.project_allocation_line USING btree (run_id, target_type, unallocated_reason);


--
-- Name: project_allocation_run_active_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX project_allocation_run_active_uq ON public.project_allocation_run USING btree (enterprise_id, period_month) WHERE (status = ANY (ARRAY['QUEUED'::text, 'RUNNING'::text]));


--
-- Name: project_allocation_run_current_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX project_allocation_run_current_uq ON public.project_allocation_run USING btree (enterprise_id, period_month) WHERE is_current;


--
-- Name: project_allocation_run_history_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX project_allocation_run_history_idx ON public.project_allocation_run USING btree (enterprise_id, period_month, created_at DESC);


--
-- Name: project_allocation_run_published_idem_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX project_allocation_run_published_idem_uq ON public.project_allocation_run USING btree (enterprise_id, period_month, input_digest, algorithm_version) WHERE ((status = 'SUCCEEDED'::text) AND (input_digest IS NOT NULL) AND is_current);


--
-- Name: project_department_assignment_current_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX project_department_assignment_current_uq ON public.project_department_assignment USING btree (enterprise_id, project_principal_id) WHERE (valid_until IS NULL);


--
-- Name: project_department_assignment_lookup_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX project_department_assignment_lookup_idx ON public.project_department_assignment USING btree (enterprise_id, project_principal_id, valid_from, valid_until);


--
-- Name: project_membership_by_employee_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX project_membership_by_employee_idx ON public.project_membership USING btree (enterprise_id, employee_principal_id);


--
-- Name: project_membership_revision_idem_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX project_membership_revision_idem_uq ON public.project_membership_revision USING btree (enterprise_id, idempotency_key) WHERE (idempotency_key IS NOT NULL);


--
-- Name: project_membership_revision_interval_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX project_membership_revision_interval_idx ON public.project_membership_revision USING btree (enterprise_id, employee_principal_id, joined_at, left_at);


--
-- Name: project_membership_revision_project_interval_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX project_membership_revision_project_interval_idx ON public.project_membership_revision USING btree (enterprise_id, project_principal_id, joined_at, left_at);


--
-- Name: provider_archive_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_archive_idx ON public.provider USING btree (enterprise_id, archived_at);


--
-- Name: provider_enterprise_code_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_enterprise_code_idx ON public.provider USING btree (enterprise_id, code);


--
-- Name: provider_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_enterprise_id_id_uq ON public.provider USING btree (enterprise_id, id);


--
-- Name: provider_finance_activation_attempt_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_activation_attempt_enterprise_id_id_uq ON public.provider_finance_activation_attempt USING btree (enterprise_id, id);


--
-- Name: provider_finance_activation_attempt_recent_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_finance_activation_attempt_recent_idx ON public.provider_finance_activation_attempt USING btree (enterprise_id, created_at);


--
-- Name: provider_finance_attempt_activation_idempotency_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_attempt_activation_idempotency_uq ON public.provider_finance_activation_attempt USING btree (enterprise_id, activation_idempotency_key) WHERE (activation_idempotency_key IS NOT NULL);


--
-- Name: provider_finance_case_decision_idempotency_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_case_decision_idempotency_uq ON public.provider_finance_reconciliation_case USING btree (enterprise_id, decision_idempotency_key) WHERE (decision_idempotency_key IS NOT NULL);


--
-- Name: provider_finance_case_open_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_case_open_uq ON public.provider_finance_reconciliation_case USING btree (enterprise_id, provider_resource_id, account_currency) WHERE ((status)::text = 'OPEN'::text);


--
-- Name: provider_finance_duplicate_pending_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_finance_duplicate_pending_idx ON public.provider_finance_duplicate_candidate USING btree (enterprise_id, provider_resource_id, status, expires_at);


--
-- Name: provider_finance_event_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_event_enterprise_id_id_uq ON public.provider_finance_event USING btree (enterprise_id, id);


--
-- Name: provider_finance_event_historical_usage_cost_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_event_historical_usage_cost_uq ON public.provider_finance_event USING btree (enterprise_id, provider_resource_id, account_currency) WHERE ((event_type)::text = 'API_HISTORICAL_USAGE_COST'::text);


--
-- Name: provider_finance_external_reference_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_external_reference_uq ON public.provider_finance_event USING btree (enterprise_id, provider_resource_id, external_reference) WHERE ((external_reference IS NOT NULL) AND ((event_type)::text = ANY ((ARRAY['API_RECHARGE'::character varying, 'CODING_PLAN_PURCHASE'::character varying, 'CODING_PLAN_RENEWAL'::character varying])::text[])));


--
-- Name: provider_finance_idempotency_key_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_idempotency_key_uq ON public.provider_finance_event USING btree (enterprise_id, provider_resource_id, idempotency_key);


--
-- Name: provider_finance_legacy_resolution_account_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_legacy_resolution_account_uq ON public.provider_finance_legacy_cost_resolution USING btree (enterprise_id, provider_resource_id, account_currency);


--
-- Name: provider_finance_legacy_resolution_enterprise_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_legacy_resolution_enterprise_id_uq ON public.provider_finance_legacy_cost_resolution USING btree (enterprise_id, id);


--
-- Name: provider_finance_legacy_resolution_resource_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_legacy_resolution_resource_id_uq ON public.provider_finance_legacy_cost_resolution USING btree (enterprise_id, provider_resource_id, id);


--
-- Name: provider_finance_legacy_resolution_window_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_legacy_resolution_window_uq ON public.provider_finance_legacy_cost_resolution USING btree (enterprise_id, provider_resource_id, account_currency, window_start, window_end_inclusive);


--
-- Name: provider_finance_opening_balance_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_opening_balance_uq ON public.provider_finance_event USING btree (enterprise_id, provider_resource_id, account_currency) WHERE ((event_type)::text = 'API_OPENING_BALANCE'::text);


--
-- Name: provider_finance_reconciliation_case_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_reconciliation_case_enterprise_id_id_uq ON public.provider_finance_reconciliation_case USING btree (enterprise_id, id);


--
-- Name: provider_finance_reversal_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_finance_reversal_uq ON public.provider_finance_event USING btree (reversal_of_event_id) WHERE (reversal_of_event_id IS NOT NULL);


--
-- Name: provider_finance_usage_disposition_request_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_finance_usage_disposition_request_idx ON public.provider_finance_usage_cost_disposition USING btree (enterprise_id, ai_request_id);


--
-- Name: provider_model_discovery_latest_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_model_discovery_latest_idx ON public.provider_model_discovery USING btree (enterprise_id, provider_resource_id, discovered_at);


--
-- Name: provider_model_probe_item_run_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_model_probe_item_run_idx ON public.provider_model_probe_item USING btree (probe_run_id, upstream_model);


--
-- Name: provider_model_probe_run_request_hash_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_model_probe_run_request_hash_idx ON public.provider_model_probe_run USING btree (enterprise_id, request_hash);


--
-- Name: provider_model_probe_run_resource_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_model_probe_run_resource_idx ON public.provider_model_probe_run USING btree (enterprise_id, provider_resource_id, started_at);


--
-- Name: provider_model_validation_in_progress_unique; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_model_validation_in_progress_unique ON public.provider_model_validation USING btree (enterprise_id, provider_resource_id, upstream_model) WHERE ((status)::text = 'IN_PROGRESS'::text);


--
-- Name: provider_model_validation_latest_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_model_validation_latest_idx ON public.provider_model_validation USING btree (enterprise_id, provider_resource_id, upstream_model, created_at);


--
-- Name: provider_quota_window_current_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_quota_window_current_uq ON public.provider_quota_window USING btree (provider_resource_id, window_type) WHERE (is_current = true);


--
-- Name: provider_quota_window_enterprise_history_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_quota_window_enterprise_history_idx ON public.provider_quota_window USING btree (enterprise_id, created_at);


--
-- Name: provider_resource_archive_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_resource_archive_idx ON public.provider_resource USING btree (enterprise_id, archived_at);


--
-- Name: provider_resource_balance_refresh_idempotency_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_resource_balance_refresh_idempotency_uq ON public.provider_resource_balance_refresh USING btree (enterprise_id, provider_resource_id, idempotency_key);


--
-- Name: provider_resource_balance_refresh_latest_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_resource_balance_refresh_latest_idx ON public.provider_resource_balance_refresh USING btree (provider_resource_id, started_at);


--
-- Name: provider_resource_balance_refresh_running_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_resource_balance_refresh_running_uq ON public.provider_resource_balance_refresh USING btree (provider_resource_id) WHERE ((status)::text = 'RUNNING'::text);


--
-- Name: provider_resource_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_resource_enterprise_id_id_uq ON public.provider_resource USING btree (enterprise_id, id);


--
-- Name: provider_resource_enterprise_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_resource_enterprise_id_uq ON public.provider_resource USING btree (enterprise_id, id);


--
-- Name: provider_resource_finance_state_enterprise_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_resource_finance_state_enterprise_idx ON public.provider_resource_finance_state USING btree (enterprise_id, state);


--
-- Name: provider_resource_monthly_budget_current_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_resource_monthly_budget_current_uq ON public.provider_resource_monthly_budget USING btree (enterprise_id, provider_resource_id, month) WHERE is_current;


--
-- Name: provider_resource_monthly_budget_idempotency_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_resource_monthly_budget_idempotency_uq ON public.provider_resource_monthly_budget USING btree (enterprise_id, provider_resource_id, month, idempotency_key);


--
-- Name: provider_resource_monthly_budget_version_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_resource_monthly_budget_version_uq ON public.provider_resource_monthly_budget USING btree (enterprise_id, provider_resource_id, month, version);


--
-- Name: provider_resource_operating_snapshot_latest_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_resource_operating_snapshot_latest_idx ON public.provider_resource_operating_snapshot USING btree (enterprise_id, provider_resource_id, collected_at);


--
-- Name: provider_resource_operating_snapshot_resource_version_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_resource_operating_snapshot_resource_version_uq ON public.provider_resource_operating_snapshot USING btree (provider_resource_id, version);


--
-- Name: provider_resource_operating_sync_attempt_latest_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_resource_operating_sync_attempt_latest_idx ON public.provider_resource_operating_sync_attempt USING btree (enterprise_id, provider_resource_id, completed_at);


--
-- Name: provider_resource_pool_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_resource_pool_idx ON public.provider_resource USING btree (enterprise_id, resource_pool_id, status);


--
-- Name: provider_subscription_period_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_subscription_period_enterprise_id_id_uq ON public.provider_subscription_period USING btree (enterprise_id, id);


--
-- Name: provider_subscription_period_event_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_subscription_period_event_uq ON public.provider_subscription_period USING btree (finance_event_id) WHERE (finance_event_id IS NOT NULL);


--
-- Name: provider_subscription_period_lookup_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX provider_subscription_period_lookup_idx ON public.provider_subscription_period USING btree (enterprise_id, provider_resource_id, period_start DESC, period_end_exclusive);


--
-- Name: provider_subscription_period_migration_source_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_subscription_period_migration_source_uq ON public.provider_subscription_period USING btree (enterprise_id, migration_source_record_id) WHERE (migration_source_record_id IS NOT NULL);


--
-- Name: provider_subscription_period_resource_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_subscription_period_resource_id_uq ON public.provider_subscription_period USING btree (enterprise_id, provider_resource_id, id);


--
-- Name: provider_subscription_period_reversal_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX provider_subscription_period_reversal_uq ON public.provider_subscription_period USING btree (reversed_by_event_id) WHERE (reversed_by_event_id IS NOT NULL);


--
-- Name: quota_counter_grant_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX quota_counter_grant_idx ON public.quota_counter USING btree (grant_id);


--
-- Name: reconciliation_discrepancy_enterprise_status_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX reconciliation_discrepancy_enterprise_status_idx ON public.reconciliation_discrepancy USING btree (enterprise_id, status, severity);


--
-- Name: reconciliation_discrepancy_run_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX reconciliation_discrepancy_run_idx ON public.reconciliation_discrepancy USING btree (reconciliation_run_id);


--
-- Name: report_delivery_due; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX report_delivery_due ON public.report_delivery_message USING btree (enterprise_id, status, next_attempt_at);


--
-- Name: request_attribution_snapshot_current_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX request_attribution_snapshot_current_idx ON public.request_attribution_snapshot USING btree (enterprise_id, ai_request_id, version);


--
-- Name: request_attribution_snapshot_department_month_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX request_attribution_snapshot_department_month_idx ON public.request_attribution_snapshot USING btree (enterprise_id, organization_unit_id, request_occurred_at);


--
-- Name: request_attribution_snapshot_request_version_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX request_attribution_snapshot_request_version_uq ON public.request_attribution_snapshot USING btree (enterprise_id, ai_request_id, version);


--
-- Name: request_attribution_snapshot_supersedes_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX request_attribution_snapshot_supersedes_uq ON public.request_attribution_snapshot USING btree (supersedes_id) WHERE (supersedes_id IS NOT NULL);


--
-- Name: resource_purchase_record_enterprise_resource_time_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX resource_purchase_record_enterprise_resource_time_idx ON public.resource_purchase_record USING btree (enterprise_id, provider_resource_id, purchased_at);


--
-- Name: resource_purchase_record_enterprise_time_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX resource_purchase_record_enterprise_time_idx ON public.resource_purchase_record USING btree (enterprise_id, purchased_at);


--
-- Name: resource_status_event_resource_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX resource_status_event_resource_idx ON public.resource_status_event USING btree (provider_resource_id, created_at);


--
-- Name: route_candidate_request_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX route_candidate_request_idx ON public.route_candidate USING btree (ai_request_id);


--
-- Name: supply_forecast_key_unique; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX supply_forecast_key_unique ON public.supply_forecast USING btree (forecast_key) WHERE (forecast_key IS NOT NULL);


--
-- Name: supply_forecast_resource_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX supply_forecast_resource_idx ON public.supply_forecast USING btree (provider_resource_id, snapshot_at);


--
-- Name: unified_model_archive_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX unified_model_archive_idx ON public.unified_model USING btree (enterprise_id, archived_at);


--
-- Name: unified_model_enterprise_alias_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX unified_model_enterprise_alias_idx ON public.unified_model USING btree (enterprise_id, alias);


--
-- Name: unified_model_enterprise_id_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX unified_model_enterprise_id_id_uq ON public.unified_model USING btree (enterprise_id, id);


--
-- Name: unified_model_enterprise_id_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX unified_model_enterprise_id_uq ON public.unified_model USING btree (enterprise_id, id);


--
-- Name: upstream_attempt_enterprise_id_id_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX upstream_attempt_enterprise_id_id_idx ON public.upstream_attempt USING btree (enterprise_id, id);


--
-- Name: upstream_attempt_request_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX upstream_attempt_request_idx ON public.upstream_attempt USING btree (ai_request_id, attempt_no);


--
-- Name: upstream_attempt_unique_request_no_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX upstream_attempt_unique_request_no_idx ON public.upstream_attempt USING btree (ai_request_id, attempt_no);


--
-- Name: usage_aggregate_dirty_marked_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX usage_aggregate_dirty_marked_idx ON public.usage_aggregate_dirty_bucket USING btree (bucket_granularity, marked_at, enterprise_id);


--
-- Name: usage_aggregate_state_generated_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX usage_aggregate_state_generated_idx ON public.usage_aggregate_bucket_state USING btree (enterprise_id, bucket_granularity, generated_at);


--
-- Name: usage_bucket_aggregate_dimensions_uq; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX usage_bucket_aggregate_dimensions_uq ON public.usage_bucket_aggregate USING btree (enterprise_id, bucket_granularity, bucket_start, timezone, source_principal_id, project_principal_id, provider_resource_id, unified_model_id) NULLS NOT DISTINCT;


--
-- Name: usage_bucket_aggregate_dirty_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX usage_bucket_aggregate_dirty_idx ON public.usage_bucket_aggregate USING btree (enterprise_id, dirty, bucket_start) WHERE (dirty = true);


--
-- Name: usage_bucket_aggregate_range_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE INDEX usage_bucket_aggregate_range_idx ON public.usage_bucket_aggregate USING btree (enterprise_id, bucket_granularity, bucket_start);


--
-- Name: usage_event_dedup_idx; Type: INDEX; Schema: public; Owner: wp6_r7
--

CREATE UNIQUE INDEX usage_event_dedup_idx ON public.usage_event USING btree (dedup_key);


--
-- Name: employee_project_allocation_policy employee_project_allocation_policy_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER employee_project_allocation_policy_contract BEFORE INSERT OR DELETE OR UPDATE ON public.employee_project_allocation_policy FOR EACH ROW EXECUTE FUNCTION public.validate_employee_allocation_policy();


--
-- Name: employee_project_allocation_rule employee_project_allocation_rule_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER employee_project_allocation_rule_contract BEFORE INSERT OR DELETE OR UPDATE ON public.employee_project_allocation_rule FOR EACH ROW EXECUTE FUNCTION public.validate_employee_allocation_rule();


--
-- Name: historical_import_run_item historical_import_run_item_immutable_trg; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER historical_import_run_item_immutable_trg BEFORE DELETE OR UPDATE ON public.historical_import_run_item FOR EACH ROW EXECUTE FUNCTION public.historical_import_run_item_immutable();


--
-- Name: historical_import_run historical_import_run_state_guard_trg; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER historical_import_run_state_guard_trg BEFORE DELETE OR UPDATE ON public.historical_import_run FOR EACH ROW EXECUTE FUNCTION public.historical_import_run_state_guard();


--
-- Name: ledger_line ledger_line_legacy_resolution_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER ledger_line_legacy_resolution_contract BEFORE INSERT OR UPDATE OF legacy_cost_resolution_id ON public.ledger_line FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_legacy_line_link();


--
-- Name: ledger_line ledger_line_provider_finance_strict_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER ledger_line_provider_finance_strict_contract BEFORE INSERT OR UPDATE OF api_cost_status, subscription_period_id, settled_at, provider_resource_id, enterprise_id, resource_mode ON public.ledger_line FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_strict_ledger_fact();


--
-- Name: ledger_line ledger_line_subscription_period_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER ledger_line_subscription_period_contract BEFORE INSERT OR UPDATE OF subscription_period_id, settled_at, provider_resource_id, enterprise_id, resource_mode ON public.ledger_line FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_ledger_period_link();


--
-- Name: operating_bill_opening_balance operating_bill_opening_balance_immutable; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER operating_bill_opening_balance_immutable BEFORE DELETE OR UPDATE ON public.operating_bill_opening_balance FOR EACH ROW EXECUTE FUNCTION public.w20_reject_immutable_mutation();


--
-- Name: operating_bill_project_allocation_ref operating_bill_project_allocation_ref_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER operating_bill_project_allocation_ref_contract BEFORE INSERT OR DELETE OR UPDATE ON public.operating_bill_project_allocation_ref FOR EACH ROW EXECUTE FUNCTION public.validate_bill_allocation_ref();


--
-- Name: person person_enterprise_default_trigger; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER person_enterprise_default_trigger BEFORE INSERT ON public.person FOR EACH ROW EXECUTE FUNCTION public.qianliu_person_enterprise_default();


--
-- Name: person_external_identity person_external_identity_enterprise_trigger; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER person_external_identity_enterprise_trigger BEFORE INSERT OR UPDATE OF person_id, enterprise_id ON public.person_external_identity FOR EACH ROW EXECUTE FUNCTION public.qianliu_identity_enterprise_guard();


--
-- Name: principal_accounting_assignment principal_accounting_assignment_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER principal_accounting_assignment_contract BEFORE INSERT OR DELETE OR UPDATE ON public.principal_accounting_assignment FOR EACH ROW EXECUTE FUNCTION public.validate_principal_accounting_assignment();


--
-- Name: project_accounting_profile_version project_accounting_profile_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER project_accounting_profile_contract BEFORE INSERT OR DELETE OR UPDATE ON public.project_accounting_profile_version FOR EACH ROW EXECUTE FUNCTION public.validate_project_accounting_profile();


--
-- Name: project_allocation_line project_allocation_line_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER project_allocation_line_contract BEFORE INSERT OR DELETE OR UPDATE ON public.project_allocation_line FOR EACH ROW EXECUTE FUNCTION public.validate_project_allocation_line();


--
-- Name: project_allocation_resource_residual project_allocation_resource_residual_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER project_allocation_resource_residual_contract BEFORE INSERT OR DELETE OR UPDATE ON public.project_allocation_resource_residual FOR EACH ROW EXECUTE FUNCTION public.validate_project_allocation_resource_residual();


--
-- Name: project_allocation_run project_allocation_run_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER project_allocation_run_contract BEFORE DELETE OR UPDATE ON public.project_allocation_run FOR EACH ROW EXECUTE FUNCTION public.validate_project_allocation_run();


--
-- Name: project_membership project_membership_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER project_membership_contract BEFORE INSERT OR DELETE OR UPDATE ON public.project_membership FOR EACH ROW EXECUTE FUNCTION public.validate_project_membership();


--
-- Name: project_membership_revision project_membership_revision_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER project_membership_revision_contract BEFORE INSERT OR DELETE OR UPDATE ON public.project_membership_revision FOR EACH ROW EXECUTE FUNCTION public.validate_project_membership_revision();


--
-- Name: provider_finance_activation_attempt provider_finance_activation_attempt_guard; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_finance_activation_attempt_guard BEFORE DELETE OR UPDATE ON public.provider_finance_activation_attempt FOR EACH ROW EXECUTE FUNCTION public.provider_finance_protect_activation_attempt();


--
-- Name: provider_finance_event provider_finance_adjustment_closure; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE CONSTRAINT TRIGGER provider_finance_adjustment_closure AFTER INSERT ON public.provider_finance_event DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_adjustment_closure();


--
-- Name: provider_finance_reconciliation_case provider_finance_case_closure; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE CONSTRAINT TRIGGER provider_finance_case_closure AFTER INSERT OR UPDATE ON public.provider_finance_reconciliation_case DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_case_closure();


--
-- Name: provider_finance_reconciliation_case provider_finance_case_no_delete; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_finance_case_no_delete BEFORE DELETE ON public.provider_finance_reconciliation_case FOR EACH ROW EXECUTE FUNCTION public.provider_finance_reject_event_mutation();


--
-- Name: provider_finance_reconciliation_case provider_finance_case_terminal_immutable; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_finance_case_terminal_immutable BEFORE UPDATE ON public.provider_finance_reconciliation_case FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_case_terminal_mutation();


--
-- Name: provider_finance_duplicate_candidate provider_finance_duplicate_terminal_immutable; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_finance_duplicate_terminal_immutable BEFORE DELETE OR UPDATE ON public.provider_finance_duplicate_candidate FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_duplicate_mutation();


--
-- Name: provider_finance_event provider_finance_event_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_finance_event_contract BEFORE INSERT ON public.provider_finance_event FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_event_contract();


--
-- Name: provider_finance_event provider_finance_event_immutable; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_finance_event_immutable BEFORE DELETE OR UPDATE ON public.provider_finance_event FOR EACH ROW EXECUTE FUNCTION public.provider_finance_reject_event_mutation();


--
-- Name: provider_finance_idempotency provider_finance_idempotency_immutable; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_finance_idempotency_immutable BEFORE DELETE OR UPDATE ON public.provider_finance_idempotency FOR EACH ROW EXECUTE FUNCTION public.provider_finance_reject_event_mutation();


--
-- Name: provider_finance_event provider_finance_legacy_cost_event_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_finance_legacy_cost_event_contract BEFORE INSERT ON public.provider_finance_event FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_legacy_cost_event();


--
-- Name: provider_finance_event provider_finance_legacy_event_closure; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE CONSTRAINT TRIGGER provider_finance_legacy_event_closure AFTER INSERT ON public.provider_finance_event DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_legacy_event_closure();


--
-- Name: provider_finance_legacy_cost_resolution provider_finance_legacy_resolution_closure; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE CONSTRAINT TRIGGER provider_finance_legacy_resolution_closure AFTER INSERT OR UPDATE ON public.provider_finance_legacy_cost_resolution DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_legacy_resolution_closure();


--
-- Name: provider_finance_legacy_cost_resolution provider_finance_legacy_resolution_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_finance_legacy_resolution_contract BEFORE INSERT OR UPDATE ON public.provider_finance_legacy_cost_resolution FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_legacy_cost_resolution();


--
-- Name: provider_resource_operating_snapshot provider_finance_resolution_snapshot_immutable; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_finance_resolution_snapshot_immutable BEFORE DELETE OR UPDATE ON public.provider_resource_operating_snapshot FOR EACH ROW EXECUTE FUNCTION public.provider_finance_protect_resolution_snapshot();


--
-- Name: provider_finance_runtime_state provider_finance_runtime_activation_immutable; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_finance_runtime_activation_immutable BEFORE DELETE OR UPDATE ON public.provider_finance_runtime_state FOR EACH ROW EXECUTE FUNCTION public.provider_finance_protect_runtime_activation();


--
-- Name: provider_finance_usage_cost_disposition provider_finance_usage_disposition_guard_trg; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_finance_usage_disposition_guard_trg BEFORE INSERT OR DELETE OR UPDATE ON public.provider_finance_usage_cost_disposition FOR EACH ROW EXECUTE FUNCTION public.provider_finance_usage_disposition_guard();


--
-- Name: provider_resource_operating_sync_attempt provider_resource_operating_sync_attempt_immutable; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_resource_operating_sync_attempt_immutable BEFORE DELETE OR UPDATE ON public.provider_resource_operating_sync_attempt FOR EACH ROW EXECUTE FUNCTION public.w20_reject_immutable_mutation();


--
-- Name: provider_finance_event provider_subscription_period_closure; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE CONSTRAINT TRIGGER provider_subscription_period_closure AFTER INSERT ON public.provider_finance_event DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_period_closure();


--
-- Name: provider_subscription_period provider_subscription_period_contract; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_subscription_period_contract BEFORE INSERT OR UPDATE ON public.provider_subscription_period FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_period_contract();


--
-- Name: provider_subscription_period provider_subscription_period_immutable_identity; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_subscription_period_immutable_identity BEFORE UPDATE ON public.provider_subscription_period FOR EACH ROW EXECUTE FUNCTION public.provider_finance_validate_period_mutation();


--
-- Name: provider_subscription_period provider_subscription_period_no_delete; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER provider_subscription_period_no_delete BEFORE DELETE ON public.provider_subscription_period FOR EACH ROW EXECUTE FUNCTION public.provider_finance_reject_event_mutation();


--
-- Name: request_attribution_snapshot request_attribution_snapshot_immutable; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER request_attribution_snapshot_immutable BEFORE DELETE OR UPDATE ON public.request_attribution_snapshot FOR EACH ROW EXECUTE FUNCTION public.w20_reject_immutable_mutation();


--
-- Name: resource_purchase_record resource_purchase_record_immutable; Type: TRIGGER; Schema: public; Owner: wp6_r7
--

CREATE TRIGGER resource_purchase_record_immutable BEFORE DELETE OR UPDATE ON public.resource_purchase_record FOR EACH ROW EXECUTE FUNCTION public.w20_reject_immutable_mutation();


--
-- Name: admin_role admin_role_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.admin_role
    ADD CONSTRAINT admin_role_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: admin_session admin_session_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.admin_session
    ADD CONSTRAINT admin_session_admin_user_id_fkey FOREIGN KEY (admin_user_id) REFERENCES public.admin_user(id);


--
-- Name: admin_user admin_user_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.admin_user
    ADD CONSTRAINT admin_user_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: ai_request ai_request_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ai_request
    ADD CONSTRAINT ai_request_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: ai_request ai_request_enterprise_model_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ai_request
    ADD CONSTRAINT ai_request_enterprise_model_fk FOREIGN KEY (enterprise_id, unified_model_id) REFERENCES public.unified_model(enterprise_id, id);


--
-- Name: ai_request ai_request_import_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ai_request
    ADD CONSTRAINT ai_request_import_run_id_fkey FOREIGN KEY (import_run_id) REFERENCES public.historical_import_run(id);


--
-- Name: ai_request ai_request_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ai_request
    ADD CONSTRAINT ai_request_principal_id_fkey FOREIGN KEY (principal_id) REFERENCES public.principal(id);


--
-- Name: ai_request ai_request_principal_key_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ai_request
    ADD CONSTRAINT ai_request_principal_key_id_fkey FOREIGN KEY (principal_key_id) REFERENCES public.principal_key(id);


--
-- Name: alert_event alert_event_availability_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.alert_event
    ADD CONSTRAINT alert_event_availability_event_id_fkey FOREIGN KEY (availability_event_id) REFERENCES public.availability_event(id);


--
-- Name: alert_event alert_event_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.alert_event
    ADD CONSTRAINT alert_event_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: availability_event availability_event_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_event
    ADD CONSTRAINT availability_event_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.provider(id);


--
-- Name: availability_event availability_event_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_event
    ADD CONSTRAINT availability_event_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: availability_event availability_event_rule_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_event
    ADD CONSTRAINT availability_event_rule_version_fk FOREIGN KEY (rule_version_id, availability_rule_id, rule_version) REFERENCES public.availability_rule_version(id, availability_rule_id, rule_version);


--
-- Name: availability_event availability_event_trigger_ai_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_event
    ADD CONSTRAINT availability_event_trigger_ai_request_id_fkey FOREIGN KEY (trigger_ai_request_id) REFERENCES public.ai_request(id);


--
-- Name: availability_event availability_event_trigger_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_event
    ADD CONSTRAINT availability_event_trigger_principal_id_fkey FOREIGN KEY (trigger_principal_id) REFERENCES public.principal(id);


--
-- Name: availability_event availability_event_unified_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_event
    ADD CONSTRAINT availability_event_unified_model_id_fkey FOREIGN KEY (unified_model_id) REFERENCES public.unified_model(id);


--
-- Name: availability_rule availability_rule_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_rule
    ADD CONSTRAINT availability_rule_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.admin_user(id);


--
-- Name: availability_rule_version availability_rule_version_availability_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_rule_version
    ADD CONSTRAINT availability_rule_version_availability_rule_id_fkey FOREIGN KEY (availability_rule_id) REFERENCES public.availability_rule(id);


--
-- Name: availability_rule_version availability_rule_version_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_rule_version
    ADD CONSTRAINT availability_rule_version_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.admin_user(id);


--
-- Name: availability_rule_version availability_rule_version_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_rule_version
    ADD CONSTRAINT availability_rule_version_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.provider(id);


--
-- Name: availability_rule_version availability_rule_version_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_rule_version
    ADD CONSTRAINT availability_rule_version_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: availability_rule_version availability_rule_version_published_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_rule_version
    ADD CONSTRAINT availability_rule_version_published_by_fkey FOREIGN KEY (published_by) REFERENCES public.admin_user(id);


--
-- Name: availability_rule_version availability_rule_version_unified_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.availability_rule_version
    ADD CONSTRAINT availability_rule_version_unified_model_id_fkey FOREIGN KEY (unified_model_id) REFERENCES public.unified_model(id);


--
-- Name: billing_rule billing_rule_archived_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.billing_rule
    ADD CONSTRAINT billing_rule_archived_by_admin_id_fkey FOREIGN KEY (archived_by_admin_id) REFERENCES public.admin_user(id);


--
-- Name: billing_rule billing_rule_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.billing_rule
    ADD CONSTRAINT billing_rule_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: billing_rule billing_rule_enterprise_resource_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.billing_rule
    ADD CONSTRAINT billing_rule_enterprise_resource_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: billing_rule billing_rule_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.billing_rule
    ADD CONSTRAINT billing_rule_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: concurrency_lease concurrency_lease_ai_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.concurrency_lease
    ADD CONSTRAINT concurrency_lease_ai_request_id_fkey FOREIGN KEY (ai_request_id) REFERENCES public.ai_request(id);


--
-- Name: concurrency_lease concurrency_lease_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.concurrency_lease
    ADD CONSTRAINT concurrency_lease_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: concurrency_lease concurrency_lease_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.concurrency_lease
    ADD CONSTRAINT concurrency_lease_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: credential_chat_probe credential_chat_probe_actor_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.credential_chat_probe
    ADD CONSTRAINT credential_chat_probe_actor_admin_id_fkey FOREIGN KEY (actor_admin_id) REFERENCES public.admin_user(id);


--
-- Name: credential_chat_probe credential_chat_probe_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.credential_chat_probe
    ADD CONSTRAINT credential_chat_probe_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: credential_chat_probe credential_chat_probe_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.credential_chat_probe
    ADD CONSTRAINT credential_chat_probe_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: department_budget department_budget_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.department_budget
    ADD CONSTRAINT department_budget_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: department_budget_idempotency department_budget_idempotency_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.department_budget_idempotency
    ADD CONSTRAINT department_budget_idempotency_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: department_budget_idempotency department_budget_idempotency_organization_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.department_budget_idempotency
    ADD CONSTRAINT department_budget_idempotency_organization_unit_id_fkey FOREIGN KEY (organization_unit_id) REFERENCES public.organization_unit(id);


--
-- Name: department_budget_idempotency department_budget_idempotency_unit_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.department_budget_idempotency
    ADD CONSTRAINT department_budget_idempotency_unit_tenant_fk FOREIGN KEY (enterprise_id, organization_unit_id) REFERENCES public.organization_unit(enterprise_id, id);


--
-- Name: department_budget department_budget_organization_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.department_budget
    ADD CONSTRAINT department_budget_organization_unit_id_fkey FOREIGN KEY (organization_unit_id) REFERENCES public.organization_unit(id);


--
-- Name: department_budget department_budget_unit_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.department_budget
    ADD CONSTRAINT department_budget_unit_tenant_fk FOREIGN KEY (enterprise_id, organization_unit_id) REFERENCES public.organization_unit(enterprise_id, id);


--
-- Name: department_budget department_budget_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.department_budget
    ADD CONSTRAINT department_budget_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.admin_user(id);


--
-- Name: deployment_log deployment_log_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.deployment_log
    ADD CONSTRAINT deployment_log_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: deployment_log_event deployment_log_event_deployment_log_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.deployment_log_event
    ADD CONSTRAINT deployment_log_event_deployment_log_id_fkey FOREIGN KEY (deployment_log_id) REFERENCES public.deployment_log(id);


--
-- Name: deployment_log_event deployment_log_event_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.deployment_log_event
    ADD CONSTRAINT deployment_log_event_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: directory_import_item directory_import_item_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_item
    ADD CONSTRAINT directory_import_item_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: directory_import_item directory_import_item_existing_principal_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_item
    ADD CONSTRAINT directory_import_item_existing_principal_fk FOREIGN KEY (enterprise_id, existing_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: directory_import_item directory_import_item_person_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_item
    ADD CONSTRAINT directory_import_item_person_fk FOREIGN KEY (enterprise_id, person_id) REFERENCES public.person(enterprise_id, id);


--
-- Name: directory_import_item directory_import_item_principal_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_item
    ADD CONSTRAINT directory_import_item_principal_fk FOREIGN KEY (enterprise_id, principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: directory_import_item directory_import_item_run_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_item
    ADD CONSTRAINT directory_import_item_run_fk FOREIGN KEY (enterprise_id, run_id) REFERENCES public.directory_import_run(enterprise_id, id);


--
-- Name: directory_import_item directory_import_item_unit_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_item
    ADD CONSTRAINT directory_import_item_unit_fk FOREIGN KEY (enterprise_id, organization_unit_id) REFERENCES public.organization_unit(enterprise_id, id);


--
-- Name: directory_import_run directory_import_run_created_by_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_run
    ADD CONSTRAINT directory_import_run_created_by_admin_user_id_fkey FOREIGN KEY (created_by_admin_user_id) REFERENCES public.admin_user(id);


--
-- Name: directory_import_run directory_import_run_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_run
    ADD CONSTRAINT directory_import_run_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: directory_import_run directory_import_run_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_import_run
    ADD CONSTRAINT directory_import_run_source_fk FOREIGN KEY (enterprise_id, directory_source_id) REFERENCES public.directory_source(enterprise_id, id);


--
-- Name: directory_source directory_source_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.directory_source
    ADD CONSTRAINT directory_source_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: dispatch_decision dispatch_decision_ai_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.dispatch_decision
    ADD CONSTRAINT dispatch_decision_ai_request_id_fkey FOREIGN KEY (ai_request_id) REFERENCES public.ai_request(id);


--
-- Name: dispatch_decision dispatch_decision_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.dispatch_decision
    ADD CONSTRAINT dispatch_decision_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: dispatch_policy dispatch_policy_copied_from_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.dispatch_policy
    ADD CONSTRAINT dispatch_policy_copied_from_policy_id_fkey FOREIGN KEY (copied_from_policy_id) REFERENCES public.dispatch_policy(id);


--
-- Name: dispatch_policy dispatch_policy_created_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.dispatch_policy
    ADD CONSTRAINT dispatch_policy_created_by_admin_id_fkey FOREIGN KEY (created_by_admin_id) REFERENCES public.admin_user(id);


--
-- Name: dispatch_policy dispatch_policy_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.dispatch_policy
    ADD CONSTRAINT dispatch_policy_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: dispatch_policy dispatch_policy_published_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.dispatch_policy
    ADD CONSTRAINT dispatch_policy_published_by_admin_id_fkey FOREIGN KEY (published_by_admin_id) REFERENCES public.admin_user(id);


--
-- Name: dispatch_policy dispatch_policy_restore_source_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.dispatch_policy
    ADD CONSTRAINT dispatch_policy_restore_source_policy_id_fkey FOREIGN KEY (restore_source_policy_id) REFERENCES public.dispatch_policy(id);


--
-- Name: dispatch_policy dispatch_policy_retired_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.dispatch_policy
    ADD CONSTRAINT dispatch_policy_retired_by_admin_id_fkey FOREIGN KEY (retired_by_admin_id) REFERENCES public.admin_user(id);


--
-- Name: dispatch_policy dispatch_policy_validated_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.dispatch_policy
    ADD CONSTRAINT dispatch_policy_validated_by_admin_id_fkey FOREIGN KEY (validated_by_admin_id) REFERENCES public.admin_user(id);


--
-- Name: employee_login employee_login_principal_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_login
    ADD CONSTRAINT employee_login_principal_fk FOREIGN KEY (principal_id) REFERENCES public.principal(id);


--
-- Name: employee_model_rule_assignment employee_model_rule_assignment_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_assignment
    ADD CONSTRAINT employee_model_rule_assignment_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: employee_model_rule_assignment employee_model_rule_assignment_grant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_assignment
    ADD CONSTRAINT employee_model_rule_assignment_grant_id_fkey FOREIGN KEY (grant_id) REFERENCES public.principal_grant(id);


--
-- Name: employee_model_rule_assignment employee_model_rule_assignment_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_assignment
    ADD CONSTRAINT employee_model_rule_assignment_principal_id_fkey FOREIGN KEY (principal_id) REFERENCES public.principal(id);


--
-- Name: employee_model_rule_assignment employee_model_rule_assignment_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_assignment
    ADD CONSTRAINT employee_model_rule_assignment_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: employee_model_rule_assignment employee_model_rule_assignment_rule_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_assignment
    ADD CONSTRAINT employee_model_rule_assignment_rule_version_id_fkey FOREIGN KEY (rule_version_id) REFERENCES public.employee_model_rule_version(id);


--
-- Name: employee_model_rule_assignment employee_model_rule_assignment_unified_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_assignment
    ADD CONSTRAINT employee_model_rule_assignment_unified_model_id_fkey FOREIGN KEY (unified_model_id) REFERENCES public.unified_model(id);


--
-- Name: employee_model_rule_version employee_model_rule_version_created_by_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_version
    ADD CONSTRAINT employee_model_rule_version_created_by_admin_user_id_fkey FOREIGN KEY (created_by_admin_user_id) REFERENCES public.admin_user(id);


--
-- Name: employee_model_rule_version employee_model_rule_version_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_version
    ADD CONSTRAINT employee_model_rule_version_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: employee_model_rule_version employee_model_rule_version_owner_principal_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_model_rule_version
    ADD CONSTRAINT employee_model_rule_version_owner_principal_fk FOREIGN KEY (owner_principal_id) REFERENCES public.principal(id);


--
-- Name: employee_project_allocation_policy employee_project_allocation_p_enterprise_id_employee_princ_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_project_allocation_policy
    ADD CONSTRAINT employee_project_allocation_p_enterprise_id_employee_princ_fkey FOREIGN KEY (enterprise_id, employee_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: employee_project_allocation_policy employee_project_allocation_pol_enterprise_id_published_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_project_allocation_policy
    ADD CONSTRAINT employee_project_allocation_pol_enterprise_id_published_by_fkey FOREIGN KEY (enterprise_id, published_by) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: employee_project_allocation_rule employee_project_allocation_r_enterprise_id_membership_rev_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_project_allocation_rule
    ADD CONSTRAINT employee_project_allocation_r_enterprise_id_membership_rev_fkey FOREIGN KEY (enterprise_id, membership_revision_id) REFERENCES public.project_membership_revision(enterprise_id, id);


--
-- Name: employee_project_allocation_rule employee_project_allocation_r_enterprise_id_project_princi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_project_allocation_rule
    ADD CONSTRAINT employee_project_allocation_r_enterprise_id_project_princi_fkey FOREIGN KEY (enterprise_id, project_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: employee_project_allocation_rule employee_project_allocation_ru_enterprise_id_membership_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_project_allocation_rule
    ADD CONSTRAINT employee_project_allocation_ru_enterprise_id_membership_id_fkey FOREIGN KEY (enterprise_id, membership_id) REFERENCES public.project_membership(enterprise_id, id);


--
-- Name: employee_project_allocation_rule employee_project_allocation_rule_enterprise_id_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.employee_project_allocation_rule
    ADD CONSTRAINT employee_project_allocation_rule_enterprise_id_policy_id_fkey FOREIGN KEY (enterprise_id, policy_id) REFERENCES public.employee_project_allocation_policy(enterprise_id, id);


--
-- Name: historical_import_run historical_import_run_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.historical_import_run
    ADD CONSTRAINT historical_import_run_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: historical_import_run_item historical_import_run_item_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.historical_import_run_item
    ADD CONSTRAINT historical_import_run_item_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: historical_import_run_item historical_import_run_item_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.historical_import_run_item
    ADD CONSTRAINT historical_import_run_item_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.historical_import_run(id);


--
-- Name: ledger_line ledger_line_ai_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_line
    ADD CONSTRAINT ledger_line_ai_request_id_fkey FOREIGN KEY (ai_request_id) REFERENCES public.ai_request(id);


--
-- Name: ledger_line ledger_line_billing_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_line
    ADD CONSTRAINT ledger_line_billing_rule_id_fkey FOREIGN KEY (billing_rule_id) REFERENCES public.billing_rule(id);


--
-- Name: ledger_line ledger_line_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_line
    ADD CONSTRAINT ledger_line_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: ledger_line ledger_line_legacy_resolution_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_line
    ADD CONSTRAINT ledger_line_legacy_resolution_fk FOREIGN KEY (enterprise_id, provider_resource_id, legacy_cost_resolution_id) REFERENCES public.provider_finance_legacy_cost_resolution(enterprise_id, provider_resource_id, id);


--
-- Name: ledger_line ledger_line_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_line
    ADD CONSTRAINT ledger_line_principal_id_fkey FOREIGN KEY (principal_id) REFERENCES public.principal(id);


--
-- Name: ledger_line ledger_line_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_line
    ADD CONSTRAINT ledger_line_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: ledger_line ledger_line_subscription_period_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_line
    ADD CONSTRAINT ledger_line_subscription_period_tenant_fk FOREIGN KEY (enterprise_id, provider_resource_id, subscription_period_id) REFERENCES public.provider_subscription_period(enterprise_id, provider_resource_id, id);


--
-- Name: ledger_line ledger_line_upstream_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_line
    ADD CONSTRAINT ledger_line_upstream_attempt_id_fkey FOREIGN KEY (upstream_attempt_id) REFERENCES public.upstream_attempt(id);


--
-- Name: ledger_line ledger_line_usage_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_line
    ADD CONSTRAINT ledger_line_usage_event_id_fkey FOREIGN KEY (usage_event_id) REFERENCES public.usage_event(id);


--
-- Name: ledger_transaction ledger_transaction_ai_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_transaction
    ADD CONSTRAINT ledger_transaction_ai_request_id_fkey FOREIGN KEY (ai_request_id) REFERENCES public.ai_request(id);


--
-- Name: ledger_transaction ledger_transaction_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_transaction
    ADD CONSTRAINT ledger_transaction_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: ledger_transaction ledger_transaction_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.ledger_transaction
    ADD CONSTRAINT ledger_transaction_principal_id_fkey FOREIGN KEY (principal_id) REFERENCES public.principal(id);


--
-- Name: model_route model_route_archived_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.model_route
    ADD CONSTRAINT model_route_archived_by_admin_id_fkey FOREIGN KEY (archived_by_admin_id) REFERENCES public.admin_user(id);


--
-- Name: model_route model_route_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.model_route
    ADD CONSTRAINT model_route_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: model_route model_route_enterprise_model_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.model_route
    ADD CONSTRAINT model_route_enterprise_model_fk FOREIGN KEY (enterprise_id, unified_model_id) REFERENCES public.unified_model(enterprise_id, id);


--
-- Name: model_route model_route_enterprise_resource_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.model_route
    ADD CONSTRAINT model_route_enterprise_resource_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: model_route model_route_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.model_route
    ADD CONSTRAINT model_route_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: model_route model_route_unified_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.model_route
    ADD CONSTRAINT model_route_unified_model_id_fkey FOREIGN KEY (unified_model_id) REFERENCES public.unified_model(id);


--
-- Name: notification_delivery notification_delivery_availability_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.notification_delivery
    ADD CONSTRAINT notification_delivery_availability_event_id_fkey FOREIGN KEY (availability_event_id) REFERENCES public.availability_event(id);


--
-- Name: notification_delivery notification_delivery_notification_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.notification_delivery
    ADD CONSTRAINT notification_delivery_notification_endpoint_id_fkey FOREIGN KEY (notification_endpoint_id) REFERENCES public.notification_endpoint(id);


--
-- Name: notification_delivery notification_delivery_recipient_identity_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.notification_delivery
    ADD CONSTRAINT notification_delivery_recipient_identity_id_fkey FOREIGN KEY (recipient_identity_id) REFERENCES public.person_external_identity(id);


--
-- Name: notification_delivery notification_delivery_recipient_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.notification_delivery
    ADD CONSTRAINT notification_delivery_recipient_person_id_fkey FOREIGN KEY (recipient_person_id) REFERENCES public.person(id);


--
-- Name: operating_bill_event operating_bill_event_actor_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_event
    ADD CONSTRAINT operating_bill_event_actor_admin_id_fkey FOREIGN KEY (actor_admin_id) REFERENCES public.admin_user(id);


--
-- Name: operating_bill_event operating_bill_event_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_event
    ADD CONSTRAINT operating_bill_event_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: operating_bill_event operating_bill_event_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_event
    ADD CONSTRAINT operating_bill_event_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.operating_bill_period(id) ON DELETE CASCADE;


--
-- Name: operating_bill_opening_balance operating_bill_opening_balance_actor_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_opening_balance
    ADD CONSTRAINT operating_bill_opening_balance_actor_tenant_fk FOREIGN KEY (enterprise_id, created_by) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: operating_bill_opening_balance operating_bill_opening_balance_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_opening_balance
    ADD CONSTRAINT operating_bill_opening_balance_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: operating_bill_opening_balance operating_bill_opening_balance_period_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_opening_balance
    ADD CONSTRAINT operating_bill_opening_balance_period_tenant_fk FOREIGN KEY (enterprise_id, period_id) REFERENCES public.operating_bill_period(enterprise_id, id);


--
-- Name: operating_bill_opening_balance operating_bill_opening_balance_resource_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_opening_balance
    ADD CONSTRAINT operating_bill_opening_balance_resource_tenant_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: operating_bill_period operating_bill_period_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_period
    ADD CONSTRAINT operating_bill_period_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.admin_user(id);


--
-- Name: operating_bill_period operating_bill_period_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_period
    ADD CONSTRAINT operating_bill_period_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: operating_bill_project_allocation_ref operating_bill_project_alloca_enterprise_id_bill_version_i_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_project_allocation_ref
    ADD CONSTRAINT operating_bill_project_alloca_enterprise_id_bill_version_i_fkey FOREIGN KEY (enterprise_id, bill_version_id) REFERENCES public.operating_bill_version(enterprise_id, id) ON DELETE CASCADE;


--
-- Name: operating_bill_project_allocation_ref operating_bill_project_allocation_ref_enterprise_id_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_project_allocation_ref
    ADD CONSTRAINT operating_bill_project_allocation_ref_enterprise_id_run_id_fkey FOREIGN KEY (enterprise_id, run_id) REFERENCES public.project_allocation_run(enterprise_id, id) ON DELETE RESTRICT;


--
-- Name: operating_bill_request_project_assignment operating_bill_request_project_assign_project_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_request_project_assignment
    ADD CONSTRAINT operating_bill_request_project_assign_project_principal_id_fkey FOREIGN KEY (project_principal_id) REFERENCES public.principal(id);


--
-- Name: operating_bill_request_project_assignment operating_bill_request_project_assignment_ai_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_request_project_assignment
    ADD CONSTRAINT operating_bill_request_project_assignment_ai_request_id_fkey FOREIGN KEY (ai_request_id) REFERENCES public.ai_request(id) ON DELETE CASCADE;


--
-- Name: operating_bill_request_project_assignment operating_bill_request_project_assignment_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_request_project_assignment
    ADD CONSTRAINT operating_bill_request_project_assignment_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.admin_user(id);


--
-- Name: operating_bill_request_project_assignment operating_bill_request_project_assignment_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_request_project_assignment
    ADD CONSTRAINT operating_bill_request_project_assignment_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: operating_bill_resource_confirmation operating_bill_resource_confirmation_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_resource_confirmation
    ADD CONSTRAINT operating_bill_resource_confirmation_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.admin_user(id);


--
-- Name: operating_bill_resource_confirmation operating_bill_resource_confirmation_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_resource_confirmation
    ADD CONSTRAINT operating_bill_resource_confirmation_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: operating_bill_resource_confirmation operating_bill_resource_confirmation_operating_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_resource_confirmation
    ADD CONSTRAINT operating_bill_resource_confirmation_operating_snapshot_id_fkey FOREIGN KEY (operating_snapshot_id) REFERENCES public.provider_resource_operating_snapshot(id);


--
-- Name: operating_bill_resource_confirmation operating_bill_resource_confirmation_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_resource_confirmation
    ADD CONSTRAINT operating_bill_resource_confirmation_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.operating_bill_period(id);


--
-- Name: operating_bill_resource_confirmation operating_bill_resource_confirmation_resource_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_resource_confirmation
    ADD CONSTRAINT operating_bill_resource_confirmation_resource_tenant_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: operating_bill_value_item operating_bill_value_item_confirmed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_value_item
    ADD CONSTRAINT operating_bill_value_item_confirmed_by_fkey FOREIGN KEY (confirmed_by) REFERENCES public.admin_user(id);


--
-- Name: operating_bill_value_item operating_bill_value_item_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_value_item
    ADD CONSTRAINT operating_bill_value_item_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: operating_bill_value_item operating_bill_value_item_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_value_item
    ADD CONSTRAINT operating_bill_value_item_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.operating_bill_period(id) ON DELETE CASCADE;


--
-- Name: operating_bill_value_item operating_bill_value_item_related_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_value_item
    ADD CONSTRAINT operating_bill_value_item_related_principal_id_fkey FOREIGN KEY (related_principal_id) REFERENCES public.principal(id);


--
-- Name: operating_bill_value_item operating_bill_value_item_submitted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_value_item
    ADD CONSTRAINT operating_bill_value_item_submitted_by_fkey FOREIGN KEY (submitted_by) REFERENCES public.admin_user(id);


--
-- Name: operating_bill_version operating_bill_version_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_version
    ADD CONSTRAINT operating_bill_version_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.admin_user(id);


--
-- Name: operating_bill_version operating_bill_version_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_version
    ADD CONSTRAINT operating_bill_version_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: operating_bill_version operating_bill_version_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operating_bill_version
    ADD CONSTRAINT operating_bill_version_period_id_fkey FOREIGN KEY (period_id) REFERENCES public.operating_bill_period(id) ON DELETE CASCADE;


--
-- Name: provider_resource_operating_snapshot operating_snapshot_enterprise_resource_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_operating_snapshot
    ADD CONSTRAINT operating_snapshot_enterprise_resource_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: provider_resource_operating_snapshot operating_snapshot_subscription_period_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_operating_snapshot
    ADD CONSTRAINT operating_snapshot_subscription_period_tenant_fk FOREIGN KEY (enterprise_id, provider_resource_id, subscription_period_id) REFERENCES public.provider_subscription_period(enterprise_id, provider_resource_id, id);


--
-- Name: operation_log operation_log_admin_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operation_log
    ADD CONSTRAINT operation_log_admin_user_id_fkey FOREIGN KEY (admin_user_id) REFERENCES public.admin_user(id);


--
-- Name: operation_log operation_log_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.operation_log
    ADD CONSTRAINT operation_log_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: organization_membership organization_membership_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.organization_membership
    ADD CONSTRAINT organization_membership_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: organization_membership organization_membership_person_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.organization_membership
    ADD CONSTRAINT organization_membership_person_fk FOREIGN KEY (enterprise_id, person_id) REFERENCES public.person(enterprise_id, id);


--
-- Name: organization_membership organization_membership_unit_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.organization_membership
    ADD CONSTRAINT organization_membership_unit_fk FOREIGN KEY (enterprise_id, organization_unit_id) REFERENCES public.organization_unit(enterprise_id, id);


--
-- Name: organization_unit organization_unit_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.organization_unit
    ADD CONSTRAINT organization_unit_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: organization_unit organization_unit_parent_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.organization_unit
    ADD CONSTRAINT organization_unit_parent_fk FOREIGN KEY (enterprise_id, parent_id) REFERENCES public.organization_unit(enterprise_id, id);


--
-- Name: organization_unit organization_unit_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.organization_unit
    ADD CONSTRAINT organization_unit_source_fk FOREIGN KEY (enterprise_id, external_source_id) REFERENCES public.directory_source(enterprise_id, id);


--
-- Name: person person_enterprise_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.person
    ADD CONSTRAINT person_enterprise_fk FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: person_external_identity person_external_identity_enterprise_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.person_external_identity
    ADD CONSTRAINT person_external_identity_enterprise_fk FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: person_external_identity person_external_identity_person_enterprise_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.person_external_identity
    ADD CONSTRAINT person_external_identity_person_enterprise_fk FOREIGN KEY (enterprise_id, person_id) REFERENCES public.person(enterprise_id, id);


--
-- Name: person_external_identity person_external_identity_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.person_external_identity
    ADD CONSTRAINT person_external_identity_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.person(id);


--
-- Name: person_external_identity person_external_identity_source_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.person_external_identity
    ADD CONSTRAINT person_external_identity_source_fk FOREIGN KEY (enterprise_id, directory_source_id) REFERENCES public.directory_source(enterprise_id, id);


--
-- Name: principal_access_config_state principal_access_config_state_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_access_config_state
    ADD CONSTRAINT principal_access_config_state_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: principal_access_config_state principal_access_config_state_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_access_config_state
    ADD CONSTRAINT principal_access_config_state_principal_id_fkey FOREIGN KEY (principal_id) REFERENCES public.principal(id);


--
-- Name: principal_access_idempotency principal_access_idempotency_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_access_idempotency
    ADD CONSTRAINT principal_access_idempotency_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: principal_access_idempotency principal_access_idempotency_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_access_idempotency
    ADD CONSTRAINT principal_access_idempotency_principal_id_fkey FOREIGN KEY (principal_id) REFERENCES public.principal(id);


--
-- Name: principal_accounting_assignment principal_accounting_assignme_enterprise_id_owner_principa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_accounting_assignment
    ADD CONSTRAINT principal_accounting_assignme_enterprise_id_owner_principa_fkey FOREIGN KEY (enterprise_id, owner_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: principal_accounting_assignment principal_accounting_assignmen_enterprise_id_department_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_accounting_assignment
    ADD CONSTRAINT principal_accounting_assignmen_enterprise_id_department_id_fkey FOREIGN KEY (enterprise_id, department_id) REFERENCES public.organization_unit(enterprise_id, id);


--
-- Name: principal_accounting_assignment principal_accounting_assignment_enterprise_id_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_accounting_assignment
    ADD CONSTRAINT principal_accounting_assignment_enterprise_id_created_by_fkey FOREIGN KEY (enterprise_id, created_by) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: principal_accounting_assignment principal_accounting_assignment_enterprise_id_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_accounting_assignment
    ADD CONSTRAINT principal_accounting_assignment_enterprise_id_principal_id_fkey FOREIGN KEY (enterprise_id, principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: principal_agent_expectation principal_agent_expectation_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_agent_expectation
    ADD CONSTRAINT principal_agent_expectation_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: principal_agent_expectation principal_agent_expectation_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_agent_expectation
    ADD CONSTRAINT principal_agent_expectation_principal_id_fkey FOREIGN KEY (principal_id) REFERENCES public.principal(id);


--
-- Name: principal principal_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal
    ADD CONSTRAINT principal_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: principal_grant principal_grant_authorization_rule_version_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_grant
    ADD CONSTRAINT principal_grant_authorization_rule_version_fk FOREIGN KEY (authorization_rule_version_id) REFERENCES public.employee_model_rule_version(id);


--
-- Name: principal_grant principal_grant_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_grant
    ADD CONSTRAINT principal_grant_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: principal_grant principal_grant_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_grant
    ADD CONSTRAINT principal_grant_principal_id_fkey FOREIGN KEY (principal_id) REFERENCES public.principal(id);


--
-- Name: principal_key principal_key_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_key
    ADD CONSTRAINT principal_key_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: principal_key principal_key_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_key
    ADD CONSTRAINT principal_key_principal_id_fkey FOREIGN KEY (principal_id) REFERENCES public.principal(id);


--
-- Name: principal_model_manual_authorization principal_model_manual_authorization_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_model_manual_authorization
    ADD CONSTRAINT principal_model_manual_authorization_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: principal_model_manual_authorization principal_model_manual_authorization_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_model_manual_authorization
    ADD CONSTRAINT principal_model_manual_authorization_principal_id_fkey FOREIGN KEY (principal_id) REFERENCES public.principal(id);


--
-- Name: principal_model_manual_authorization principal_model_manual_authorization_unified_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_model_manual_authorization
    ADD CONSTRAINT principal_model_manual_authorization_unified_model_id_fkey FOREIGN KEY (unified_model_id) REFERENCES public.unified_model(id);


--
-- Name: principal principal_owner_enterprise_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal
    ADD CONSTRAINT principal_owner_enterprise_fk FOREIGN KEY (enterprise_id, owner_person_id) REFERENCES public.person(enterprise_id, id);


--
-- Name: principal principal_owner_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal
    ADD CONSTRAINT principal_owner_person_id_fkey FOREIGN KEY (owner_person_id) REFERENCES public.person(id);


--
-- Name: principal principal_person_enterprise_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal
    ADD CONSTRAINT principal_person_enterprise_fk FOREIGN KEY (enterprise_id, person_id) REFERENCES public.person(enterprise_id, id);


--
-- Name: principal principal_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal
    ADD CONSTRAINT principal_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.person(id);


--
-- Name: principal_provider_disabled_model principal_provider_disabled_model_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_provider_disabled_model
    ADD CONSTRAINT principal_provider_disabled_model_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: principal_provider_disabled_model principal_provider_disabled_model_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_provider_disabled_model
    ADD CONSTRAINT principal_provider_disabled_model_principal_id_fkey FOREIGN KEY (principal_id) REFERENCES public.principal(id);


--
-- Name: principal_provider_disabled_model principal_provider_disabled_model_rule_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_provider_disabled_model
    ADD CONSTRAINT principal_provider_disabled_model_rule_fk FOREIGN KEY (disable_rule_version_id) REFERENCES public.employee_model_rule_version(id);


--
-- Name: principal_provider_disabled_model principal_provider_disabled_model_unified_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_provider_disabled_model
    ADD CONSTRAINT principal_provider_disabled_model_unified_model_id_fkey FOREIGN KEY (unified_model_id) REFERENCES public.unified_model(id);


--
-- Name: principal_quota_period principal_quota_period_enterprise_id_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_quota_period
    ADD CONSTRAINT principal_quota_period_enterprise_id_principal_id_fkey FOREIGN KEY (enterprise_id, principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: principal_quota_usage principal_quota_usage_enterprise_id_grant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_quota_usage
    ADD CONSTRAINT principal_quota_usage_enterprise_id_grant_id_fkey FOREIGN KEY (enterprise_id, grant_id) REFERENCES public.principal_grant(enterprise_id, id);


--
-- Name: principal_quota_usage principal_quota_usage_enterprise_id_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_quota_usage
    ADD CONSTRAINT principal_quota_usage_enterprise_id_period_id_fkey FOREIGN KEY (enterprise_id, period_id) REFERENCES public.principal_quota_period(enterprise_id, id);


--
-- Name: principal_quota_usage principal_quota_usage_enterprise_id_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_quota_usage
    ADD CONSTRAINT principal_quota_usage_enterprise_id_request_id_fkey FOREIGN KEY (enterprise_id, request_id) REFERENCES public.ai_request(enterprise_id, id);


--
-- Name: principal_quota_usage principal_quota_usage_enterprise_id_upstream_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.principal_quota_usage
    ADD CONSTRAINT principal_quota_usage_enterprise_id_upstream_attempt_id_fkey FOREIGN KEY (enterprise_id, upstream_attempt_id) REFERENCES public.upstream_attempt(enterprise_id, id);


--
-- Name: procurement_review_note procurement_review_note_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.procurement_review_note
    ADD CONSTRAINT procurement_review_note_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: procurement_review_note_idempotency procurement_review_note_idempotency_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.procurement_review_note_idempotency
    ADD CONSTRAINT procurement_review_note_idempotency_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: procurement_review_note procurement_review_note_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.procurement_review_note
    ADD CONSTRAINT procurement_review_note_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.admin_user(id);


--
-- Name: project_accounting_profile_version project_accounting_profile_ve_enterprise_id_project_princi_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_accounting_profile_version
    ADD CONSTRAINT project_accounting_profile_ve_enterprise_id_project_princi_fkey FOREIGN KEY (enterprise_id, project_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: project_accounting_profile_version project_accounting_profile_versio_enterprise_id_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_accounting_profile_version
    ADD CONSTRAINT project_accounting_profile_versio_enterprise_id_created_by_fkey FOREIGN KEY (enterprise_id, created_by) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: project_allocation_line project_allocation_line_enterprise_id_membership_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_line
    ADD CONSTRAINT project_allocation_line_enterprise_id_membership_id_fkey FOREIGN KEY (enterprise_id, membership_id) REFERENCES public.project_membership(enterprise_id, id);


--
-- Name: project_allocation_line project_allocation_line_enterprise_id_membership_revision__fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_line
    ADD CONSTRAINT project_allocation_line_enterprise_id_membership_revision__fkey FOREIGN KEY (enterprise_id, membership_revision_id) REFERENCES public.project_membership_revision(enterprise_id, id);


--
-- Name: project_allocation_line project_allocation_line_enterprise_id_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_line
    ADD CONSTRAINT project_allocation_line_enterprise_id_policy_id_fkey FOREIGN KEY (enterprise_id, policy_id) REFERENCES public.employee_project_allocation_policy(enterprise_id, id);


--
-- Name: project_allocation_line project_allocation_line_enterprise_id_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_line
    ADD CONSTRAINT project_allocation_line_enterprise_id_provider_resource_id_fkey FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: project_allocation_line project_allocation_line_enterprise_id_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_line
    ADD CONSTRAINT project_allocation_line_enterprise_id_run_id_fkey FOREIGN KEY (enterprise_id, run_id) REFERENCES public.project_allocation_run(enterprise_id, id);


--
-- Name: project_allocation_line project_allocation_line_enterprise_id_source_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_line
    ADD CONSTRAINT project_allocation_line_enterprise_id_source_principal_id_fkey FOREIGN KEY (enterprise_id, source_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: project_allocation_line project_allocation_line_enterprise_id_unified_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_line
    ADD CONSTRAINT project_allocation_line_enterprise_id_unified_model_id_fkey FOREIGN KEY (enterprise_id, unified_model_id) REFERENCES public.unified_model(enterprise_id, id);


--
-- Name: project_allocation_period project_allocation_period_enterprise_id_enabled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_period
    ADD CONSTRAINT project_allocation_period_enterprise_id_enabled_by_fkey FOREIGN KEY (enterprise_id, enabled_by) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: project_allocation_resource_residual project_allocation_resource_r_enterprise_id_provider_resou_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_resource_residual
    ADD CONSTRAINT project_allocation_resource_r_enterprise_id_provider_resou_fkey FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: project_allocation_resource_residual project_allocation_resource_residual_enterprise_id_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_resource_residual
    ADD CONSTRAINT project_allocation_resource_residual_enterprise_id_run_id_fkey FOREIGN KEY (enterprise_id, run_id) REFERENCES public.project_allocation_run(enterprise_id, id);


--
-- Name: project_allocation_run project_allocation_run_enterprise_id_actor_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_allocation_run
    ADD CONSTRAINT project_allocation_run_enterprise_id_actor_admin_id_fkey FOREIGN KEY (enterprise_id, actor_admin_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: project_department_assignment project_department_assignment_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_department_assignment
    ADD CONSTRAINT project_department_assignment_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.admin_user(id);


--
-- Name: project_department_assignment project_department_assignment_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_department_assignment
    ADD CONSTRAINT project_department_assignment_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: project_department_assignment project_department_assignment_organization_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_department_assignment
    ADD CONSTRAINT project_department_assignment_organization_unit_id_fkey FOREIGN KEY (organization_unit_id) REFERENCES public.organization_unit(id);


--
-- Name: project_department_assignment project_department_assignment_owner_person_id_at_assignmen_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_department_assignment
    ADD CONSTRAINT project_department_assignment_owner_person_id_at_assignmen_fkey FOREIGN KEY (owner_person_id_at_assignment) REFERENCES public.person(id);


--
-- Name: project_department_assignment project_department_assignment_owner_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_department_assignment
    ADD CONSTRAINT project_department_assignment_owner_tenant_fk FOREIGN KEY (enterprise_id, owner_person_id_at_assignment) REFERENCES public.person(enterprise_id, id);


--
-- Name: project_department_assignment project_department_assignment_project_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_department_assignment
    ADD CONSTRAINT project_department_assignment_project_principal_id_fkey FOREIGN KEY (project_principal_id) REFERENCES public.principal(id);


--
-- Name: project_department_assignment project_department_assignment_project_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_department_assignment
    ADD CONSTRAINT project_department_assignment_project_tenant_fk FOREIGN KEY (enterprise_id, project_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: project_department_assignment project_department_assignment_unit_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_department_assignment
    ADD CONSTRAINT project_department_assignment_unit_tenant_fk FOREIGN KEY (enterprise_id, organization_unit_id) REFERENCES public.organization_unit(enterprise_id, id);


--
-- Name: project_membership project_membership_enterprise_id_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership
    ADD CONSTRAINT project_membership_enterprise_id_created_by_fkey FOREIGN KEY (enterprise_id, created_by) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: project_membership project_membership_enterprise_id_employee_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership
    ADD CONSTRAINT project_membership_enterprise_id_employee_principal_id_fkey FOREIGN KEY (enterprise_id, employee_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: project_membership project_membership_enterprise_id_project_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership
    ADD CONSTRAINT project_membership_enterprise_id_project_principal_id_fkey FOREIGN KEY (enterprise_id, project_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: project_membership_revision project_membership_revision_enterprise_id_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership_revision
    ADD CONSTRAINT project_membership_revision_enterprise_id_created_by_fkey FOREIGN KEY (enterprise_id, created_by) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: project_membership_revision project_membership_revision_enterprise_id_membership_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership_revision
    ADD CONSTRAINT project_membership_revision_enterprise_id_membership_id_fkey FOREIGN KEY (enterprise_id, membership_id) REFERENCES public.project_membership(enterprise_id, id);


--
-- Name: project_membership_revision project_membership_revision_enterprise_id_supersedes_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.project_membership_revision
    ADD CONSTRAINT project_membership_revision_enterprise_id_supersedes_id_fkey FOREIGN KEY (enterprise_id, supersedes_id) REFERENCES public.project_membership_revision(enterprise_id, id);


--
-- Name: provider provider_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider
    ADD CONSTRAINT provider_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_finance_activation_attempt provider_finance_activation_attempt_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_activation_attempt
    ADD CONSTRAINT provider_finance_activation_attempt_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_finance_activation_quiescence provider_finance_activation_quiescence_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_activation_quiescence
    ADD CONSTRAINT provider_finance_activation_quiescence_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_finance_activation_attempt provider_finance_attempt_activator_admin_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_activation_attempt
    ADD CONSTRAINT provider_finance_attempt_activator_admin_tenant_fk FOREIGN KEY (enterprise_id, activated_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_finance_activation_attempt provider_finance_attempt_creator_admin_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_activation_attempt
    ADD CONSTRAINT provider_finance_attempt_creator_admin_tenant_fk FOREIGN KEY (enterprise_id, created_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_finance_reconciliation_case provider_finance_case_adjustment_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_reconciliation_case
    ADD CONSTRAINT provider_finance_case_adjustment_tenant_fk FOREIGN KEY (enterprise_id, adjustment_event_id) REFERENCES public.provider_finance_event(enterprise_id, id);


--
-- Name: provider_finance_reconciliation_case provider_finance_case_decided_admin_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_reconciliation_case
    ADD CONSTRAINT provider_finance_case_decided_admin_tenant_fk FOREIGN KEY (enterprise_id, decided_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_finance_reconciliation_case provider_finance_case_opened_admin_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_reconciliation_case
    ADD CONSTRAINT provider_finance_case_opened_admin_tenant_fk FOREIGN KEY (enterprise_id, opened_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_finance_reconciliation_case provider_finance_case_resource_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_reconciliation_case
    ADD CONSTRAINT provider_finance_case_resource_tenant_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: provider_finance_duplicate_candidate provider_finance_duplicate_admin_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_duplicate_candidate
    ADD CONSTRAINT provider_finance_duplicate_admin_tenant_fk FOREIGN KEY (enterprise_id, created_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_finance_duplicate_candidate provider_finance_duplicate_candidate_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_duplicate_candidate
    ADD CONSTRAINT provider_finance_duplicate_candidate_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_finance_duplicate_candidate provider_finance_duplicate_event_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_duplicate_candidate
    ADD CONSTRAINT provider_finance_duplicate_event_tenant_fk FOREIGN KEY (enterprise_id, consumed_event_id) REFERENCES public.provider_finance_event(enterprise_id, id);


--
-- Name: provider_finance_duplicate_candidate provider_finance_duplicate_resource_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_duplicate_candidate
    ADD CONSTRAINT provider_finance_duplicate_resource_tenant_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: provider_finance_event provider_finance_event_admin_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_event
    ADD CONSTRAINT provider_finance_event_admin_tenant_fk FOREIGN KEY (enterprise_id, created_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_finance_event provider_finance_event_case_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_event
    ADD CONSTRAINT provider_finance_event_case_tenant_fk FOREIGN KEY (enterprise_id, reconciliation_case_id) REFERENCES public.provider_finance_reconciliation_case(enterprise_id, id);


--
-- Name: provider_finance_event provider_finance_event_correction_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_event
    ADD CONSTRAINT provider_finance_event_correction_tenant_fk FOREIGN KEY (enterprise_id, correction_of_event_id) REFERENCES public.provider_finance_event(enterprise_id, id);


--
-- Name: provider_finance_event provider_finance_event_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_event
    ADD CONSTRAINT provider_finance_event_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_finance_event provider_finance_event_legacy_resolution_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_event
    ADD CONSTRAINT provider_finance_event_legacy_resolution_fk FOREIGN KEY (enterprise_id, provider_resource_id, legacy_cost_resolution_id) REFERENCES public.provider_finance_legacy_cost_resolution(enterprise_id, provider_resource_id, id);


--
-- Name: provider_finance_event provider_finance_event_resource_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_event
    ADD CONSTRAINT provider_finance_event_resource_tenant_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: provider_finance_event provider_finance_event_reversal_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_event
    ADD CONSTRAINT provider_finance_event_reversal_tenant_fk FOREIGN KEY (enterprise_id, reversal_of_event_id) REFERENCES public.provider_finance_event(enterprise_id, id);


--
-- Name: provider_finance_idempotency provider_finance_idempotency_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_idempotency
    ADD CONSTRAINT provider_finance_idempotency_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_finance_idempotency provider_finance_idempotency_resource_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_idempotency
    ADD CONSTRAINT provider_finance_idempotency_resource_tenant_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: provider_finance_legacy_cost_resolution provider_finance_legacy_cost_resolution_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_legacy_cost_resolution
    ADD CONSTRAINT provider_finance_legacy_cost_resolution_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_finance_legacy_cost_resolution provider_finance_legacy_resolution_admin_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_legacy_cost_resolution
    ADD CONSTRAINT provider_finance_legacy_resolution_admin_fk FOREIGN KEY (enterprise_id, created_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_finance_legacy_cost_resolution provider_finance_legacy_resolution_event_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_legacy_cost_resolution
    ADD CONSTRAINT provider_finance_legacy_resolution_event_fk FOREIGN KEY (enterprise_id, adjustment_event_id) REFERENCES public.provider_finance_event(enterprise_id, id);


--
-- Name: provider_finance_legacy_cost_resolution provider_finance_legacy_resolution_resource_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_legacy_cost_resolution
    ADD CONSTRAINT provider_finance_legacy_resolution_resource_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: provider_finance_legacy_cost_resolution provider_finance_legacy_resolution_snapshot_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_legacy_cost_resolution
    ADD CONSTRAINT provider_finance_legacy_resolution_snapshot_fk FOREIGN KEY (provider_balance_snapshot_id) REFERENCES public.provider_resource_operating_snapshot(id) ON DELETE RESTRICT;


--
-- Name: provider_finance_activation_quiescence provider_finance_quiescence_admin_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_activation_quiescence
    ADD CONSTRAINT provider_finance_quiescence_admin_tenant_fk FOREIGN KEY (enterprise_id, started_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_finance_reconciliation_case provider_finance_reconciliation_case_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_reconciliation_case
    ADD CONSTRAINT provider_finance_reconciliation_case_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_finance_recorded_cost_policy provider_finance_recorded_cos_enterprise_id_authorized_by__fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_recorded_cost_policy
    ADD CONSTRAINT provider_finance_recorded_cos_enterprise_id_authorized_by__fkey FOREIGN KEY (enterprise_id, authorized_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_finance_recorded_cost_policy provider_finance_recorded_cos_enterprise_id_provider_resou_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_recorded_cost_policy
    ADD CONSTRAINT provider_finance_recorded_cos_enterprise_id_provider_resou_fkey FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: provider_finance_runtime_state provider_finance_runtime_state_admin_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_runtime_state
    ADD CONSTRAINT provider_finance_runtime_state_admin_fk FOREIGN KEY (enterprise_id, activated_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_finance_runtime_state provider_finance_runtime_state_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_runtime_state
    ADD CONSTRAINT provider_finance_runtime_state_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_finance_usage_cost_disposition provider_finance_usage_cost_d_enterprise_id_decided_by_adm_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_usage_cost_disposition
    ADD CONSTRAINT provider_finance_usage_cost_d_enterprise_id_decided_by_adm_fkey FOREIGN KEY (enterprise_id, decided_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_finance_usage_cost_disposition provider_finance_usage_cost_d_enterprise_id_provider_resou_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_usage_cost_disposition
    ADD CONSTRAINT provider_finance_usage_cost_d_enterprise_id_provider_resou_fkey FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: provider_finance_usage_cost_disposition provider_finance_usage_cost_disposition_ai_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_usage_cost_disposition
    ADD CONSTRAINT provider_finance_usage_cost_disposition_ai_request_id_fkey FOREIGN KEY (ai_request_id) REFERENCES public.ai_request(id);


--
-- Name: provider_finance_usage_cost_disposition provider_finance_usage_cost_disposition_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_usage_cost_disposition
    ADD CONSTRAINT provider_finance_usage_cost_disposition_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_finance_usage_cost_disposition provider_finance_usage_cost_disposition_ledger_line_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_finance_usage_cost_disposition
    ADD CONSTRAINT provider_finance_usage_cost_disposition_ledger_line_id_fkey FOREIGN KEY (ledger_line_id) REFERENCES public.ledger_line(id);


--
-- Name: provider_model_discovery provider_model_discovery_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_discovery
    ADD CONSTRAINT provider_model_discovery_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_model_discovery_item provider_model_discovery_item_discovery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_discovery_item
    ADD CONSTRAINT provider_model_discovery_item_discovery_id_fkey FOREIGN KEY (discovery_id) REFERENCES public.provider_model_discovery(id);


--
-- Name: provider_model_discovery_item provider_model_discovery_item_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_discovery_item
    ADD CONSTRAINT provider_model_discovery_item_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_model_discovery_item provider_model_discovery_item_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_discovery_item
    ADD CONSTRAINT provider_model_discovery_item_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: provider_model_discovery provider_model_discovery_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_discovery
    ADD CONSTRAINT provider_model_discovery_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: provider_model_onboarding provider_model_onboarding_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_onboarding
    ADD CONSTRAINT provider_model_onboarding_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_model_onboarding provider_model_onboarding_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_onboarding
    ADD CONSTRAINT provider_model_onboarding_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: provider_model_probe_item provider_model_probe_item_probe_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_probe_item
    ADD CONSTRAINT provider_model_probe_item_probe_run_id_fkey FOREIGN KEY (probe_run_id) REFERENCES public.provider_model_probe_run(id) ON DELETE CASCADE;


--
-- Name: provider_model_probe_run provider_model_probe_run_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_probe_run
    ADD CONSTRAINT provider_model_probe_run_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_model_probe_run provider_model_probe_run_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_probe_run
    ADD CONSTRAINT provider_model_probe_run_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.provider(id);


--
-- Name: provider_model_probe_run provider_model_probe_run_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_probe_run
    ADD CONSTRAINT provider_model_probe_run_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: provider_model_validation provider_model_validation_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_validation
    ADD CONSTRAINT provider_model_validation_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_model_validation provider_model_validation_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_validation
    ADD CONSTRAINT provider_model_validation_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: provider_model_validation provider_model_validation_unified_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_model_validation
    ADD CONSTRAINT provider_model_validation_unified_model_id_fkey FOREIGN KEY (unified_model_id) REFERENCES public.unified_model(id);


--
-- Name: provider_quota_window provider_quota_window_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_quota_window
    ADD CONSTRAINT provider_quota_window_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_quota_window provider_quota_window_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_quota_window
    ADD CONSTRAINT provider_quota_window_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: provider_resource_balance_refresh provider_resource_balance_refresh_actor_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_balance_refresh
    ADD CONSTRAINT provider_resource_balance_refresh_actor_admin_id_fkey FOREIGN KEY (actor_admin_id) REFERENCES public.admin_user(id);


--
-- Name: provider_resource_balance_refresh provider_resource_balance_refresh_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_balance_refresh
    ADD CONSTRAINT provider_resource_balance_refresh_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_resource_balance_refresh provider_resource_balance_refresh_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_balance_refresh
    ADD CONSTRAINT provider_resource_balance_refresh_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: provider_resource provider_resource_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource
    ADD CONSTRAINT provider_resource_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_resource provider_resource_enterprise_provider_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource
    ADD CONSTRAINT provider_resource_enterprise_provider_fk FOREIGN KEY (enterprise_id, provider_id) REFERENCES public.provider(enterprise_id, id);


--
-- Name: provider_resource_finance_state provider_resource_finance_state_admin_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_finance_state
    ADD CONSTRAINT provider_resource_finance_state_admin_tenant_fk FOREIGN KEY (enterprise_id, ready_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_resource_finance_state provider_resource_finance_state_resource_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_finance_state
    ADD CONSTRAINT provider_resource_finance_state_resource_tenant_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: provider_resource_monthly_budget provider_resource_monthly_budget_actor_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_monthly_budget
    ADD CONSTRAINT provider_resource_monthly_budget_actor_tenant_fk FOREIGN KEY (enterprise_id, created_by) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_resource_monthly_budget provider_resource_monthly_budget_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_monthly_budget
    ADD CONSTRAINT provider_resource_monthly_budget_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_resource_monthly_budget provider_resource_monthly_budget_resource_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_monthly_budget
    ADD CONSTRAINT provider_resource_monthly_budget_resource_tenant_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: provider_resource_operating_snapshot provider_resource_operating_snapshot_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_operating_snapshot
    ADD CONSTRAINT provider_resource_operating_snapshot_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_resource_operating_snapshot provider_resource_operating_snapshot_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_operating_snapshot
    ADD CONSTRAINT provider_resource_operating_snapshot_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: provider_resource_operating_sync_attempt provider_resource_operating_sync_attempt_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_operating_sync_attempt
    ADD CONSTRAINT provider_resource_operating_sync_attempt_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_resource_operating_sync_attempt provider_resource_operating_sync_attempt_resource_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_operating_sync_attempt
    ADD CONSTRAINT provider_resource_operating_sync_attempt_resource_tenant_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: provider_resource_operating_sync_attempt provider_resource_operating_sync_attempt_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource_operating_sync_attempt
    ADD CONSTRAINT provider_resource_operating_sync_attempt_snapshot_id_fkey FOREIGN KEY (snapshot_id) REFERENCES public.provider_resource_operating_snapshot(id);


--
-- Name: provider_resource provider_resource_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_resource
    ADD CONSTRAINT provider_resource_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.provider(id);


--
-- Name: provider_subscription_period provider_subscription_period_admin_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_subscription_period
    ADD CONSTRAINT provider_subscription_period_admin_tenant_fk FOREIGN KEY (enterprise_id, created_by_admin_user_id) REFERENCES public.admin_user(enterprise_id, id);


--
-- Name: provider_subscription_period provider_subscription_period_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_subscription_period
    ADD CONSTRAINT provider_subscription_period_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: provider_subscription_period provider_subscription_period_event_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_subscription_period
    ADD CONSTRAINT provider_subscription_period_event_tenant_fk FOREIGN KEY (enterprise_id, finance_event_id) REFERENCES public.provider_finance_event(enterprise_id, id);


--
-- Name: provider_subscription_period provider_subscription_period_resource_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_subscription_period
    ADD CONSTRAINT provider_subscription_period_resource_tenant_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: provider_subscription_period provider_subscription_period_reversal_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.provider_subscription_period
    ADD CONSTRAINT provider_subscription_period_reversal_tenant_fk FOREIGN KEY (enterprise_id, reversed_by_event_id) REFERENCES public.provider_finance_event(enterprise_id, id);


--
-- Name: quota_counter quota_counter_grant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.quota_counter
    ADD CONSTRAINT quota_counter_grant_id_fkey FOREIGN KEY (grant_id) REFERENCES public.principal_grant(id);


--
-- Name: reconciliation_discrepancy reconciliation_discrepancy_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.reconciliation_discrepancy
    ADD CONSTRAINT reconciliation_discrepancy_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: reconciliation_discrepancy reconciliation_discrepancy_reconciliation_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.reconciliation_discrepancy
    ADD CONSTRAINT reconciliation_discrepancy_reconciliation_run_id_fkey FOREIGN KEY (reconciliation_run_id) REFERENCES public.reconciliation_run(id);


--
-- Name: reconciliation_run reconciliation_run_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.reconciliation_run
    ADD CONSTRAINT reconciliation_run_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: report_delivery_action report_delivery_action_enterprise_id_bundle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_action
    ADD CONSTRAINT report_delivery_action_enterprise_id_bundle_id_fkey FOREIGN KEY (enterprise_id, bundle_id) REFERENCES public.report_delivery_bundle(enterprise_id, id);


--
-- Name: report_delivery_action report_delivery_action_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_action
    ADD CONSTRAINT report_delivery_action_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: report_delivery_action report_delivery_action_enterprise_id_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_action
    ADD CONSTRAINT report_delivery_action_enterprise_id_message_id_fkey FOREIGN KEY (enterprise_id, message_id) REFERENCES public.report_delivery_message(enterprise_id, id);


--
-- Name: report_delivery_attempt report_delivery_attempt_enterprise_id_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_attempt
    ADD CONSTRAINT report_delivery_attempt_enterprise_id_message_id_fkey FOREIGN KEY (enterprise_id, message_id) REFERENCES public.report_delivery_message(enterprise_id, id);


--
-- Name: report_delivery_bundle report_delivery_bundle_endpoint_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_bundle
    ADD CONSTRAINT report_delivery_bundle_endpoint_id_fkey FOREIGN KEY (endpoint_id) REFERENCES public.notification_endpoint(id);


--
-- Name: report_delivery_bundle report_delivery_bundle_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_bundle
    ADD CONSTRAINT report_delivery_bundle_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: report_delivery_claim report_delivery_claim_enterprise_id_bundle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_claim
    ADD CONSTRAINT report_delivery_claim_enterprise_id_bundle_id_fkey FOREIGN KEY (enterprise_id, bundle_id) REFERENCES public.report_delivery_bundle(enterprise_id, id);


--
-- Name: report_delivery_claim report_delivery_claim_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_claim
    ADD CONSTRAINT report_delivery_claim_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: report_delivery_message report_delivery_message_enterprise_id_bundle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_message
    ADD CONSTRAINT report_delivery_message_enterprise_id_bundle_id_fkey FOREIGN KEY (enterprise_id, bundle_id) REFERENCES public.report_delivery_bundle(enterprise_id, id);


--
-- Name: report_delivery_schedule report_delivery_schedule_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.report_delivery_schedule
    ADD CONSTRAINT report_delivery_schedule_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_ai_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_ai_request_id_fkey FOREIGN KEY (ai_request_id) REFERENCES public.ai_request(id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.admin_user(id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_employee_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_employee_person_id_fkey FOREIGN KEY (employee_person_id) REFERENCES public.person(id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_employee_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_employee_tenant_fk FOREIGN KEY (enterprise_id, employee_person_id) REFERENCES public.person(enterprise_id, id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_organization_unit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_organization_unit_id_fkey FOREIGN KEY (organization_unit_id) REFERENCES public.organization_unit(id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_project_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_project_principal_id_fkey FOREIGN KEY (project_principal_id) REFERENCES public.principal(id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_project_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_project_tenant_fk FOREIGN KEY (enterprise_id, project_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_request_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_request_tenant_fk FOREIGN KEY (enterprise_id, ai_request_id) REFERENCES public.ai_request(enterprise_id, id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_source_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_source_principal_id_fkey FOREIGN KEY (source_principal_id) REFERENCES public.principal(id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_source_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_source_tenant_fk FOREIGN KEY (enterprise_id, source_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_supersedes_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_supersedes_id_fkey FOREIGN KEY (supersedes_id) REFERENCES public.request_attribution_snapshot(id);


--
-- Name: request_attribution_snapshot request_attribution_snapshot_unit_tenant_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.request_attribution_snapshot
    ADD CONSTRAINT request_attribution_snapshot_unit_tenant_fk FOREIGN KEY (enterprise_id, organization_unit_id) REFERENCES public.organization_unit(enterprise_id, id);


--
-- Name: resource_purchase_idempotency resource_purchase_idempotency_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.resource_purchase_idempotency
    ADD CONSTRAINT resource_purchase_idempotency_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: resource_purchase_idempotency resource_purchase_idempotency_enterprise_resource_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.resource_purchase_idempotency
    ADD CONSTRAINT resource_purchase_idempotency_enterprise_resource_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: resource_purchase_record resource_purchase_record_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.resource_purchase_record
    ADD CONSTRAINT resource_purchase_record_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.admin_user(id);


--
-- Name: resource_purchase_record resource_purchase_record_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.resource_purchase_record
    ADD CONSTRAINT resource_purchase_record_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: resource_purchase_record resource_purchase_record_enterprise_resource_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.resource_purchase_record
    ADD CONSTRAINT resource_purchase_record_enterprise_resource_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: resource_status_event resource_status_event_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.resource_status_event
    ADD CONSTRAINT resource_status_event_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: resource_status_event resource_status_event_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.resource_status_event
    ADD CONSTRAINT resource_status_event_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: route_candidate route_candidate_ai_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.route_candidate
    ADD CONSTRAINT route_candidate_ai_request_id_fkey FOREIGN KEY (ai_request_id) REFERENCES public.ai_request(id);


--
-- Name: route_candidate route_candidate_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.route_candidate
    ADD CONSTRAINT route_candidate_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: route_candidate route_candidate_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.route_candidate
    ADD CONSTRAINT route_candidate_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: runtime_notification_recipient runtime_notification_recipient_person_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.runtime_notification_recipient
    ADD CONSTRAINT runtime_notification_recipient_person_id_fkey FOREIGN KEY (person_id) REFERENCES public.person(id) ON DELETE CASCADE;


--
-- Name: supply_forecast supply_forecast_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.supply_forecast
    ADD CONSTRAINT supply_forecast_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: supply_forecast supply_forecast_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.supply_forecast
    ADD CONSTRAINT supply_forecast_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: unified_model unified_model_archived_by_admin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.unified_model
    ADD CONSTRAINT unified_model_archived_by_admin_id_fkey FOREIGN KEY (archived_by_admin_id) REFERENCES public.admin_user(id);


--
-- Name: unified_model unified_model_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.unified_model
    ADD CONSTRAINT unified_model_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: upstream_attempt upstream_attempt_ai_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.upstream_attempt
    ADD CONSTRAINT upstream_attempt_ai_request_id_fkey FOREIGN KEY (ai_request_id) REFERENCES public.ai_request(id);


--
-- Name: upstream_attempt upstream_attempt_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.upstream_attempt
    ADD CONSTRAINT upstream_attempt_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: upstream_attempt upstream_attempt_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.upstream_attempt
    ADD CONSTRAINT upstream_attempt_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: usage_aggregate_bucket_state usage_aggregate_bucket_state_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_aggregate_bucket_state
    ADD CONSTRAINT usage_aggregate_bucket_state_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: usage_aggregate_dirty_bucket usage_aggregate_dirty_bucket_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_aggregate_dirty_bucket
    ADD CONSTRAINT usage_aggregate_dirty_bucket_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: usage_bucket_aggregate usage_bucket_aggregate_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_bucket_aggregate
    ADD CONSTRAINT usage_bucket_aggregate_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: usage_bucket_aggregate usage_bucket_aggregate_project_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_bucket_aggregate
    ADD CONSTRAINT usage_bucket_aggregate_project_principal_id_fkey FOREIGN KEY (project_principal_id) REFERENCES public.principal(id);


--
-- Name: usage_bucket_aggregate usage_bucket_aggregate_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_bucket_aggregate
    ADD CONSTRAINT usage_bucket_aggregate_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: usage_bucket_aggregate usage_bucket_aggregate_source_principal_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_bucket_aggregate
    ADD CONSTRAINT usage_bucket_aggregate_source_principal_id_fkey FOREIGN KEY (source_principal_id) REFERENCES public.principal(id);


--
-- Name: usage_bucket_aggregate usage_bucket_aggregate_unified_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_bucket_aggregate
    ADD CONSTRAINT usage_bucket_aggregate_unified_model_id_fkey FOREIGN KEY (unified_model_id) REFERENCES public.unified_model(id);


--
-- Name: usage_bucket_aggregate usage_bucket_enterprise_model_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_bucket_aggregate
    ADD CONSTRAINT usage_bucket_enterprise_model_fk FOREIGN KEY (enterprise_id, unified_model_id) REFERENCES public.unified_model(enterprise_id, id);


--
-- Name: usage_bucket_aggregate usage_bucket_enterprise_project_principal_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_bucket_aggregate
    ADD CONSTRAINT usage_bucket_enterprise_project_principal_fk FOREIGN KEY (enterprise_id, project_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: usage_bucket_aggregate usage_bucket_enterprise_resource_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_bucket_aggregate
    ADD CONSTRAINT usage_bucket_enterprise_resource_fk FOREIGN KEY (enterprise_id, provider_resource_id) REFERENCES public.provider_resource(enterprise_id, id);


--
-- Name: usage_bucket_aggregate usage_bucket_enterprise_source_principal_fk; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_bucket_aggregate
    ADD CONSTRAINT usage_bucket_enterprise_source_principal_fk FOREIGN KEY (enterprise_id, source_principal_id) REFERENCES public.principal(enterprise_id, id);


--
-- Name: usage_event usage_event_ai_request_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_event
    ADD CONSTRAINT usage_event_ai_request_id_fkey FOREIGN KEY (ai_request_id) REFERENCES public.ai_request(id);


--
-- Name: usage_event usage_event_enterprise_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_event
    ADD CONSTRAINT usage_event_enterprise_id_fkey FOREIGN KEY (enterprise_id) REFERENCES public.enterprise(id);


--
-- Name: usage_event usage_event_provider_resource_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_event
    ADD CONSTRAINT usage_event_provider_resource_id_fkey FOREIGN KEY (provider_resource_id) REFERENCES public.provider_resource(id);


--
-- Name: usage_event usage_event_upstream_attempt_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: wp6_r7
--

ALTER TABLE ONLY public.usage_event
    ADD CONSTRAINT usage_event_upstream_attempt_id_fkey FOREIGN KEY (upstream_attempt_id) REFERENCES public.upstream_attempt(id);


--
-- PostgreSQL database dump complete
--

\unrestrict lqLStnMpHtrzgNvpG2DZMrtivYpXaPuNuBNUnmkDkuzMbw8TxirQXeRvTabFjmN

